# Shelby Figshare 电网数据审查与本研究补数清单（电网范围）

日期：2026-11-06  
范围说明：按本研究当前口径，**只使用 Shelby 电网数据**；Figshare 中的供水网络节点、供水管线和水泵—供电互依表不作为本研究的网络输入。冷却水过程仍可作为电厂/机组层面的物理约束，但不把 Shelby 市政供水网络建模为第二个网络。

来源：Alireza Rangrazjeddi (2022), *Shelby County Data*, Figshare, v1, DOI: [10.6084/m9.figshare.20060948.v1](https://doi.org/10.6084/m9.figshare.20060948.v1)，CC BY 4.0。Figshare API 元数据中的 Shelby 电网节点表和链路表 MD5 与工作区原 CSV 完全一致，确认了这两份电网数据的直接发布来源。

## 1. 目前可用的电网数据

### 节点表：59 个节点
文件：`data/Shelby/Power Network Node Shelby Data.csv`

字段：`Nodenum, X_Lon, Y_Lat, type, flow, cost`

节点类型计数：
- 8 `gate_stations`
- 17 `23kv_substations`
- 20 `12kv_substations`
- 14 `intersections`

`flow` 汇总：gate stations 合计 +1434；37 个变电站合计 −1003；14 个 intersections 均为 0。所有 gate 值为正、变电站值为负。符号与“电源注入/用户负荷”的角色一致，但表中未给 `flow` 的单位、时间口径、是否为实际发电/负荷或名义供需容量、是否为典型工况，也未提供潮流平衡关系；全网净和为 +431。因此当前可将其解释为正负号明确的节点供给/需求类属性，但不能不经来源核实就称为 MW 的实际机组出力与母线负荷。

### 链路表：146 行
文件：`data/Shelby/Power Network Link Shelby Data.csv`

字段：`fromnode, tonode, direction, length, capacity, cost`
- 146 行形成 73 组端点相反的双向记录；按无向物理线路计为 73 条。
- 所有端点均在 1–59 节点表内，无自环；图连通。
- `length` 为 0.749–15.2；`capacity` 全部为 2000；`cost` 全部为 1000；`direction` 两类值 0/1 均出现。
- CSV 没有说明长度单位、`direction` 编码含义或 capacity/cost 的物理/经济定义。统一容量与成本更像建模用的默认/均一参数，不能视为经验证的线路热限或真实成本。对 DC-OPF 最关键的线路电抗、变压器变比/相移、热稳定额定值和状态均未提供。

两张电网原始 CSV 没有空字段，节点 ID 与线路端点校验通过。

## 2. 派生母线表不是原始实测电网模型

工作区另有 `data/Shelby/derived/shelby_power_buses.csv`，这不是 Figshare 原始文件，而是项目派生/转换文件。它为 59 个节点指定 MATPOWER 母线类型（51 PQ、7 PV、1 slack）、统一 `base_kv=115`、电压目标和上下限；其中 8 个 gate stations 被设置成 7 个 PV 节点和 1 个 slack 节点。

从数据可复核到：
- `pd_mw=max(-flow,0)`，总负荷 1003；
- `qd_mvar=0.35×pd_mw`，总无功负荷 351.05；这是统一功率因数假设，不是 Figshare 实测值；
- 节点表正的 gate `flow` 合计 1434，但派生母线表没有独立的机组参数表来证明这 8 个值是实际发电机出力。

因此 `shelby_power_buses.csv` 可作为一种明确标注的原型映射，不应当作已验证的 Shelby MATPOWER case。李楠团队 HLA 论文确实明确把 8 个 gate stations 作为 Shelby County 的主要电源，并在 OpenDSS 模型中作为 8 台 power generators；这核实了**HLA 模型中的组件角色**。但 HLA 原文没有给出 Figshare CSV 的 `flow` 列与 OpenDSS 发电机 kW 逐项相等的证据。HLA 把门站编号为 37–44；Figshare 节点表中的 gate stations 编号为 1–8，且两版网络节点构成也不同（HLA 为 17 个23kV+19个12kV变电站，Figshare 为17+20个变电站并含14个 intersections），不能直接按节点编号对照。故目前可把 Figshare 的正 gate `flow` 视为与“源端供给/名义供给量”相符的候选解释，但其数值是否就是 HLA/OpenDSS 的实际机组出力、单位是否 kW/MW，仍待原始代码/字段说明或作者确认；负的变电站 `flow` 同理，符号上符合负荷/需求，但是否为实际节点负荷及单位尚未证实。

旧 Shelby 聚合脚本把 8 个 gate `flow` 当作初始机组出力，并令聚合负荷等于 1434；它没有用派生表中的 1003 节点负荷做全网节点平衡，也没有使用电网线路约束。脚本已将 Pmax、机组成本、爬坡率、冷端缩放标为合成假设。故旧脚本结果只能解释为**带显式假设的聚合算法演示**，不能称作 Shelby 电网 DC-OPF 验证结果。

## 3. 对本研究的适用边界

当前数据能支持：
- Shelby 电网拓扑与节点地理分布展示；
- 节点类别/连通性等结构分析；
- 在明确标注假设后，开展方法原型或合成参数敏感性分析。

当前数据不能单独支持：
- 经核验的 Shelby nodal DC-OPF；
- 实际发电机成本、出力上/下限、爬坡、备用和机组调度；
- 实际线路潮流、过载判断或故障后的可靠性结果；
- 仅凭 Figshare `flow` 数值认定 gate station 的实际发电量/单位，或将任一 gate 节点直接认定为本文特定受影响机组的接入母线；（HLA 模型确将 8 个 gate stations 设为发电机，但那不等于 Figshare `flow` 已被核实为实际出力。）
- Shelby 特定的机组冷却水耗用、降额/跳机及预警动态。

本研究若只用电网数据，就不必为 Shelby 市政水网补充管道水力参数；但若仍研究电厂冷却水造成的机组约束，仍须在**电厂/机组层面**补齐冷却端参数，不能由电网 CSV 推出。

## 4. 开展电网约束研究需要补充什么

### 必需的电网运行数据
1. **母线**：确认节点类型、参考母线、额定电压和节点编号映射；每个母线的 MW/Mvar 负荷或有据可查的典型负荷快照/时序，注明时间与单位。
2. **机组**：发电厂/机组清单及接入母线，明确 gate stations 是外部边界还是可调度机组；Pmin/Pmax、初始/基准出力、爬坡上下限、边际成本或分段成本、可用性/备用等。
3. **线路/变压器**：每条线路的端点映射、R/X 或适用于 DC 的 X、tap/phase shift、运行状态、Rate A/热稳定 MVA 上限；确认当前 `length/capacity/cost/direction` 的定义与单位。
4. **目标与边界**：VOLL/负荷削减成本、机组成本口径与货币年份、外部电网交换上限/价格/基准调度，以及故障场景和恢复假设。
5. **验证**：有来源的基准潮流/机组出力或公开 case 文件，用以核验基准功率平衡、线路流及关键节点映射；如果只能构造合成 case，须按“stylized/synthetic Shelby-like network”呈现，不宣称预测 Shelby 实际运行。

### 与冷却水中断研究相关、但应放在机组层面的补数
- 哪些发电机组依赖冷却水、冷却方式与机组/母线映射；
- 机组出力—热耗/排热—冷却水流量关系，冷却泵电耗，进水温度/环境温度影响；
- 可用水量、最低安全水位/流量、降额曲线、保护跳机阈值及响应延迟；
- 若缺少现场数据，用公开机组/冷却系统参数或有界合成假设，标注来源与不确定性，并进行敏感性分析。

## 5. 当前推荐步骤

1. 先向 Figshare 数据发布者/相关网络模型作者追问 `flow`、`length`、`capacity`、`cost`、`direction` 的单位、定义和生成方式，并确认 8 个 gate stations 的物理含义。
2. 查找与该 59 节点拓扑严格匹配的电网 case（bus/gen/branch 参数）。若找不到，不要把本地派生的 `shelby_power_buses.csv` 升格为实测数据。
3. 若补到完整参数，再将 59 节点拓扑转成可核验的 DC-OPF 输入；先做基准潮流/节点平衡和线路流复现，再接入冷却水扰动模型。
4. 若只取得拓扑和类别数据，则将 Shelby 结果限于拓扑/结构或方法原型；当前论文的定量主结论继续基于已经核验的 IEEE30 DC-OPF。

**结论：**这份 Figshare 电网数据直接提供 59 节点与 73 条双向记录所对应的拓扑骨架，以及带未知单位的节点/线路属性；它没有提供建立真实网络约束调度所需的完整 bus-gen-branch 参数。首先要确认 `flow` 和 gate station 的物理含义，并补齐机组与线路工程参数。
## 6. 与李楠团队 HLA 论文的定向核实：gate 身份 vs. `flow` 数值

Wang, Magoua & Li (2022), *Modeling cascading failure of interdependent critical infrastructure systems using HLA-based co-simulation*, Section 4.1.1 明确写明：8 个 gate stations 是 Shelby County 的主要电源；系统有 17 个 23-kV、19 个 12-kV substations；8 个 gate stations 在其案例模型中被建成 8 台 power generators（独立于县外电厂计数）。该文还说 substations 和 transmission lines 将电力从 gates 配送到终端用户；Section 4.1.3 说明泵站电耗作为 substations 上的负荷处理。故**设备角色层面**，用户指出得对：在该 HLA 案例中，gate = 发电机/电源，substation = 配电并承载用户/泵负荷的节点。

但这尚不能验证 Figshare CSV 的数值 `flow`：
1. HLA 论文没有列出 Figshare `flow` 字段，也没有公布与 gate 1–8 或各 substation 逐项对应的 OpenDSS kW 输出/负荷表；没有给出“CSV flow 等于 OpenDSS generator kW/load kW”的等式、单位或时间戳。论文说明其电力系统用 OpenDSS，并提及负荷、电力、线路电阻等输入/输出数据类型，但不是本 CSV 的字段说明。
2. 编号和网络版本不同：HLA 把 substations 编为 1–36、gates 编为 37–44；Figshare 原表则把 gate_stations 标成 ID 1–8，另有 17 个23kV、20个12kV变电站和14个intersections。不能仅靠编号逐行把两份数据对应起来。
3. Figshare 原表呈现出明显供需符号结构：gate `flow` 全正、变电站 `flow` 全负、intersections 为零。因此，**最合理的工作假设**是 gate `flow` 表示源端供给/供应能力，substation `flow` 表示汇端需求/负荷量（至少是节点供需属性）；但字段名及符号模式不能单独证明它们就是实测、指定时刻的发电机出力和母线负荷，更不能证明单位是 kW 或 MW。
4. 两类之和分别为 +1434、−1003，系统节点供需净差 +431；这不构成一个可直接用于潮流分析的平衡基准点。除非该数据语义明确为供给/需求上限或不同口径，否则不能直接把这些数值送入电力平衡方程。
5. Figshare 数据所属的 Rangrazjeddi et al. 2022 PLOS ONE 工作采用基于节点供需/容量的基础设施恢复流模型，并报告 Shelby 电网为 60 nodes、76 links；当前 CSV 是 59 nodes、73 个无向端点对。该背景支持把 `flow` 当作恢复网络中的名义供需属性来进一步查证，但不能将其自动解释为 HLA/OpenDSS 的实际发电量/负荷。

**当前判定（分层置信度）**
- 高置信度：HLA 模型角色——8 gate stations 被当作 8 台电源/发电机；变电站承担配电并可承载负荷。
- 中等置信度：Figshare `flow` 符号及分组与供给/需求属性吻合；正 gate 值可暂称“供给代理”，负 substation 值可暂称“需求代理”。
- 尚未核实：这些具体数值是否来自 HLA 电力模型、是否就是机组出力和各变电站实测/基准负荷、单位、时间口径、是否为容量而非实际功率。

要完成数值语义核实，应优先取得 Rangrazjeddi Figshare 对应的数据生成/导入代码或数据字典，检查 `flow` 是怎样传入恢复模型的（supply/demand/nominal capacity）；然后联系 HLA 论文作者取得 OpenDSS case/source data，按坐标、拓扑和设备标签匹配版本，逐项比较8个 gate 与 substations。若只找到恢复优化代码而没有 OpenDSS 数据，最多能确认“恢复模型供需参数”，不能据此证明“实际 generator output / load”。

主要来源：
- Wang, Magoua & Li (2022), HLA paper PDF: http://en.urbanresilience.cn/Uploads/20220222/621430fd04f8a.pdf
- Rangrazjeddi, González & Barker (2022), PLOS ONE paper: https://doi.org/10.1371/journal.pone.0270407
- 该研究公开数据集: https://doi.org/10.6084/m9.figshare.20060948.v1

## 7. 按本次决定生成的可运行基准 case（2026-11-06）

用户指定本轮基线处理：保留 gate 原始 `flow` 作为8台发电机的基准出力；变电站负荷原值按共同系数放大，以和总发电量平衡；冷却水扰动先作用于单台 G2。依此已生成可运行的 Shelby59 DC-OPF + 冷却水适配：

- `data/Shelby/derived/case_shelby59_dc.m`：59 bus、8 generator、73 branch 的 MATPOWER 格式合成 case；
- `data/Shelby/derived/case_shelby59_dc_assumptions.json`：逐项参数化规则、原始/派生值和边界；
- `脚本/构建Shelby59_DC案例.py`：从归档 CSV 和 IEEE30 重新生成 case；
- `脚本/Shelby59_DC冷却水仿真.py`：调用当前 DC-OPF 与冷端模型的 Shelby 适配入口；
- `结果/Shelby59_DCOPF/shelby59_dc_cooling_results.json`：最近一次 PA/SP/DP 模式测试结果。

### 参数化规则（均属合成校准，不是实测 Shelby 工程参数）
- gate `flow` 原样作 P0：G1–G8 = 101、319、261、162、191、240、51、109；合计 1434。
- 变电站原始负 `flow` 取绝对值后乘 **1.429710867**，总负荷由 1003 调至 1434；保持各站原负荷比例。故变电站负荷不是原始 flow 的原值，必须明确标注。
- Pmax 按发电机 P0 排序，使用 IEEE30 的 6 台机组 P0/Pmax 负载率分位插值扩展到 8 台；对应 Pmax 区间约 173.396–344.865 MW。G2（Figshare gate ID 2，P0=319 MW）Pmax≈344.865 MW。Pmin 沿用 IEEE30 的 0 下限。
- 线路拓扑按无向连接折叠双向行。X 用源 `length` 乘一个校准比例，使 Shelby 长度中位数对应 IEEE30 线路 X 中位数 0.19 pu；X 区间约 0.0338–0.686 pu。
- Shelby 原始线路 capacity 全为2000且物理含义不明，基准 case 不把它当额定值；统一 RateA 取 IEEE30 线路 RateA 中位数 32，按 Shelby/IEEE30 总负荷比 1434/189.2 缩放，约 **242.537 MW**。这是可运行基准，不代表实际线路热额定值。
- 机组相对边际成本按 IEEE30 机组边际成本排序/插值；`rho=0.45`。IEEE30 爬坡栏全为零，因此沿用当前项目既有的 0.7% Pmax/min 合成爬坡假设，不声称来自 IEEE30 实测爬坡数据。
- Q/P 采用 IEEE30 全网总量比 107.2/189.2≈0.566596；DC-OPF 不使用 Qd。节点 baseKV 使用类别标签/占位值，交叉电压等级和 intersection 电压等级仍为假设。
- 选定受影响单元 G2 是此前 Shelby 原型中已有的选择；此处 G2 表示本地 gate ID2，尚未与 HLA 图示编号 G2（其图中编号38）建立坐标级映射。

### 可复现测试
运行：
```bash
python3 脚本/构建Shelby59_DC案例.py
python3 脚本/Shelby59_DC冷却水仿真.py --mode both
```
在 18,000 s、60 s 网格、α=0.12、ρ=0.45 测试中，case 成功通过 59-bus/8-gen/73-branch DC 潮流/优化求解；基准出力与放大后负荷都为 1434 MW。DC 核验残差约为 10⁻¹¹ MW，线路限值违反为 0。该合成设定下被动 ENS=64.558521 MWh，静态主动 ENS=2.942271 MWh，动态主动 ENS=0.887589 MWh。它们仅证明这套补齐参数能让程序运行并通过模型内一致性检查，**不是 Shelby 实际系统的工程预测，也不替换论文当前已核验的 IEEE30 主结果**。

建议至少对负荷倍率、branch X/RateA、Pmax 负载率映射、冷却水受影响机组及成本映射作敏感性分析；在拿到 OpenDSS/原始设备资料前，数值结论应明确称为 synthetic benchmark/算法演示。

## 8. 按 IEEE30 相同网格完成 Shelby59 选参与 PA/SP/DP 复算（2026-11-06）

本轮按用户确认将 Shelby 作为第二算例运行；沿用现有合成校准基准、变电站负荷平衡缩放和 G2 单机冷却水扰动。此前第7节的 ρ=0.45 结果是参数筛选前的冒烟测试，不是本轮筛选后的最终运行结果；本节所列 α*=0.12、ρ*=0.20 才是当前完整候选搜索选定值。α/ρ 选择方法和 IEEE30 相同：T=18,000 s、LP/动态重规划 60 s；α 候选 `{0.04,0.12,0.20,0.28,0.36}`；ρ 候选沿用 IEEE30 selector 网格，决策区间 `0<ρ≤0.5`。没有把 5-s DP 搜索写成已核验结果。

- 离散 Pareto 选择结果：**α*=0.12，ρ*=0.20**。
- 选定参数下 PA/SP/DP ENS：**62.266927 / 0.811486 / 0.103592 MWh**。
- 峰值未供电功率：PA/SP/DP = **319.000 / 25.790793 / 4.143307 MW**。
- 保护跳机时刻：PA/SP/DP = **12900 / 12796 / 14363 s**；预警时刻 11261 s；AET 1535.456 s。
- 相对 PA 的 ENS 减少：SP 约 **98.70%**，DP 约 **99.83%**。
- 最终 59-bus、8-gen、73-branch DC 运行的节点平衡/DC方程残差为约 10⁻¹¹ MW 量级，线路限值违反为 0。上述只是**IEEE30 参数校准合成 case**下的算法结果，不是 Shelby County 的实网预测，暂不写入主稿结论。

复算/输出：
- 参数搜索：`脚本/Shelby59_DC_Pareto选参.py`
- 选定参数 PA/SP/DP 模型：`脚本/Shelby59_DC冷却水仿真.py --mode both --alpha 0.12 --rho 0.2`
- 同风格组图生成：`脚本/Shelby59_DC组图.py`
- 搜索结果：`结果/Shelby59_DCOPF_Pareto/selection_results.json`、工作簿及 Pareto 图。
- 最终 PA/SP/DP：`结果/Shelby59_DCOPF/shelby59_dc_cooling_results.json`、`shelby59_selected_run_summary.json`。
- 组图：`figures/Shelby59/Figure2_Shelby59_topology.png`、`Figure4_Shelby59_cooling_timeline.png`、`Figure5_Shelby59_AET_components.png`、`Figure6_Shelby59_service.png`、`Figure7_Shelby59_grid_sensitivity.png`；Figure6 timeseries CSV 同目录。

按本轮用户在歧义确认中的选择，Shelby 作为第二算例先做探索性复算，**本轮不改 IEEE30 主稿/不将合成 Shelby 结果写入手稿**；待 OpenDSS/发电机/线路原始参数核实后，再决定是否纳入正式稿。

## 2026-11-06 script-entry consolidation
Current Shelby simulation and selection entry: `脚本/Shelby59_DC冷却水仿真.py` (`--action run|select|all`; `--rebuild-case` rebuilds the MATPOWER input). Parameter selection uses shared `脚本/Pareto_Selection_Core.py`; two-case figure assembly uses `脚本/双案例组图.py`. `脚本/_plot_shelby59_style.py` is retained only as the style-preserving internal draw source. The older standalone Shelby builder and selector were removed after integration. Shelby outputs remain synthetic exploratory results; the manuscript remains unchanged.

## Current presentation terminology
The current user-facing case name is **Shelby County**; figures and summaries do not foreground the bus count, and the two cases are presented as equally important. Active paths are now `脚本/Shelby_County_DC冷却水仿真.py`, `figures/Shelby_County/`, `结果/Shelby_County_DCOPF/`, and `结果/Shelby_County_DCOPF_Pareto/`. Historical sections above retain the original filenames and terminology as an audit trail. Current materials still document calibrated assumptions for electrical quantities absent from the dataset; manuscript files are unchanged.
