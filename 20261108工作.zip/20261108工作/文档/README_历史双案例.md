# 历史双案例资料说明

原 `archive/legacy_two_case/` 已删除。未被当前程序调用的旧绘图、旧 Shelby 仿真/选参及制图辅助 Python 脚本也已清除，以免与当前入口混淆。历史数据审查与文献溯源笔记保留在本目录。

当前工作的主稿是 `手稿/Cooling_Water_Resilience_Two_Case_Synchronized.docx`。当前单图入口为 `脚本/Visualization/Figure1.py` 至 `Figure7.py`；共用逻辑见 `脚本/Visualization/Visualization_Core.py`。PNG 图片直接平铺于 `图片/` 根目录。Figures 2/4/5/6/7 直接读取案例运行和选参结果，不另存双案例中间 CSV。

当前 Shelby 原始输入仅保留电网节点与链路 CSV、派生 MATPOWER 输入和校准假设文件。研究范围不包含 Shelby 市政供水网络；源数据未提供的电气参数按文档化校准假设解释，不能称作 Shelby 现场实测参数。

数据来源：Rangrazjeddi (2022), *Shelby County Data*, Figshare, DOI `10.6084/m9.figshare.20060948.v1`。
