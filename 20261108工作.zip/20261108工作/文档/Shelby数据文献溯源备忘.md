# Shelby County 基础设施数据：文献学习与溯源备忘

## 已通读文献
Wang, F., Magoua, J.J., Li, N. (2022). “Modeling cascading failure of interdependent critical infrastructure systems using HLA-based co-simulation.” *Automation in Construction*, 133, 104008. DOI: 10.1016/j.autcon.2021.104008。工作区 PDF：`参考文献/李楠团队Modeling cascading failure of interdependent critical infrastructure systems using HLA-based co-simulation.pdf`。

## 文献研究内容
- 提出以 High Level Architecture (HLA) 进行异质模型协同仿真的框架，整合地震影响模块、EPANET 水系统模型、OpenDSS 电力系统模型和基础设施系统模型，逐时间步交换状态信息。
- 以美国田纳西州 Shelby County（孟菲斯地区）电力—供水系统在假设地震下的级联失效为例，研究地震损伤、系统内故障传播及水电之间的相互依赖。
- 该文定位是仿真架构/异质模型协同与级联失效分析，不是电力调度优化文章，也没有给出可直接等同于现有项目 59 母线数据集的完整可下载网络表。

## 文中 Shelby 数据说明（Section 4）
- 地理与管理背景：Shelby County, Tennessee；电力/水务由 MLGW 与 TVA 相关系统服务。
- 电力系统小模型：8 个 gate stations（作为县内主电源/发电机）+ 17 个 23-kV 与 19 个 12-kV substations（编号 1–36），合计 44 个节点；网络图注明“not to scale, modified from [49]”。文中说依据 [48,49] 的描述构建。
- 供水模型：原系统约 960 个配水节点、1300 条管道；案例使用简化网络：6 个水箱、9 个泵、34 个分布节点、71 条水管。依据 [50,51] 描述。
- 电-水耦合：泵站依赖电力变电站；发电机依赖相连水分配节点的冷却水。表 2 列出 9 个泵站与电力变电站的配对、8 台发电机与水节点的配对。
- 该文实际运行电力模型用 OpenDSS，水模型用 EPANET；灾害数据通过 IN-CORE 获取/计算。方法含地震情景和组件易损性，不应拿来当成现有冷却水中断情景的直接验证。

## 参考文献中与网络/数据相关的来源
Wang et al. 文中编号：
- [48] González, A.D., Dueñas-Osorio, L., Sánchez-Silva, M., Medaglia, A.L. (2016). “The Interdependent Network Design Problem for Optimal Infrastructure System Restoration.” *Computer-Aided Civil and Infrastructure Engineering*, 31(5), 334–350. DOI: 10.1111/mice.12171。Shelby County 多基础设施网络/修复案例。
- [49] Shinozuka, M., Rose, A., Eguchi, R.T. (eds.) (1998). *Engineering and Socioeconomic Impacts of Earthquakes: An Analysis of Electricity Lifeline Disruptions in the New Madrid Area*, MCEER-98-MN02。Wang 文中的电网图注明改编自此报告。
- [50] Chang, S.E., Seligson, H.A., Eguchi, R.T. (1996). *Estimation of the Economic Impact of Multiple Lifeline Disruption: Memphis Light, Gas and Water Division Case Study*, NCEER-96-0011。用于水务系统描述/相关数据依据。
- [51] Adachi, T., Ellingwood, B.R. (2008). “Serviceability of earthquake-damaged water systems: effects of electrical power availability and power backup systems on system vulnerability.” *Reliability Engineering & System Safety*, 93(1), 78–88. DOI: 10.1016/j.ress.2006.10.014。
- 另有 Dueñas-Osorio, Craig & Goodno (2007), “Seismic response of critical interdependent networks,” *Earthquake Engineering & Structural Dynamics*, 36(2), 285–306, DOI: 10.1002/eqe.626。相关后续研究称 Shelby 网络拓扑适配 Chang et al. (1996)、Dueñas-Osorio et al. (2007)；水/电数据采用 Dueñas-Osorio et al. (2007) 数据。

## 与当前工作区 Shelby 文件的比对（重要）
当前项目的 `data/Shelby/Power Network Node Shelby Data.csv` 有 59 行节点、`Power Network Link Shelby Data.csv` 有 146 行链路；节点类型为 8 gate stations、17 个 23-kV substations、20 个 12-kV substations、14 个 intersections。另 `shelby_power_buses.csv` 有 59 个母线（51 PQ_SUBSTATION、7 PV_GATE_STATION、1 SLACK_GENERATOR）。地理经纬度大致落在 Memphis/Shelby County 区域。

这与 Wang et al. (2022) 描述的 44 节点 power-network 版本并不相同：该文为 36 个 substation + 8 gate station，没有将 14 个 intersection 作为节点列入其所述电力系统，12-kV 子站数也为 19 而当前 CSV 是 20。故 Wang et al. 可以作为 Shelby 电力/水基础设施网络的**文献背景及拓扑先例**，却不能未经逐节点逐链路比对就声称它是当前 59 节点 CSV 的确切原始数据源。现有 CSV 的来源需要追查其生成脚本、仓库历史/README、原始地理/utility 数据或作者说明；参数如成本、负荷、发电能力也需分别追溯。

## 对手稿可支持的诚实表述
可引用 Wang et al. 说明 Shelby County 是已有研究采用的真实地理区域案例，并指出该文基于早期研究构建电力/水网络模型。对当前算例则应说明：其网络拓扑/母线处理与 Wang et al. 文中 44-node 版本存在差别；引用只支持网络的文献背景/概念来源，不能当作 59 节点网络及当前负荷、机组、成本参数的直接数据来源。若最终证实 CSV 的逐项映射取自 González et al. 或 Dueñas-Osorio et al. 数据库，再引用相应来源并明确删改、扩展和映射步骤。

## 在线来源链接
- Wang et al. (2022) ScienceDirect: https://www.sciencedirect.com/science/article/abs/pii/S0926580521004593
- González et al. (2016) Wiley: https://onlinelibrary.wiley.com/doi/abs/10.1111/mice.12171
- Dueñas-Osorio research group td-INDP datasets: https://duenas-osorio.rice.edu/sissra/datasets-and-benchmarks
- Chang et al. (1996) NCEER report PDF: https://www.eng.buffalo.edu/mceer-reports/96/96-0011.pdf
- Shinozuka et al. (1998) MCEER-98-MN02 report: https://www.eng.buffalo.edu/mceer-reports/98/98-MN02.pdf

## 节点数进一步溯源（2026-11-06）
Rice University 数据库页面明确称其 td-INDP 数据库包含 Shelby County 水、气、电网络的 stylized versions，并提供 2016 数据库背景说明 PDF 与原始数据库 ZIP。背景说明 PDF 写明：图 1 的网络图取自 González et al. (2016)；电力和水网络改编自 Hernandez-Fajardo & Dueñas-Osorio (2011, 2013)，气网来自 Song & Ok (2010)。电力图按类别区分 12kV/23kV 变电站、intersection points、gate stations，节点编号延伸至 60。

进一步的独立学术来源明确报出：Shelby 电力子传输网络为 **60 nodes、121 links**；对应水网络为 49 nodes、71 links（Paredes, Dueñas-Osorio & Hernandez-Fajardo, “Decomposition algorithms for system reliability estimation with applications to interdependent lifeline networks”）。另一篇综述型/应用论文也说明完整 Shelby 网络有 60 power nodes、49 water nodes、18 gas nodes。结合 Rice 官方数据库背景文档与独立发表文献，Shelby County 原始学术电力网络可核实为 **60 个节点**。

当前工作区项目 CSV 则有 59 个节点（编号 1–59）及 146 条有向边记录；按无向物理线路去重为 73 条。因此它不是 60-node/121-link 原始网络的无修改副本。当前节点类别统计 8 gate + 37 substations +14 intersections=59；图示/文献版本类别和节点号范围表明存在删节点、合并、转化或另版本的可能，尚未确定具体哪一节点/边的变换。Wang et al. (2022) 的 44-node 是又一个简化子版本（8 gate+36 substations，不纳入 intersection nodes），不应与 60-node 原网混称。

注意 links 口径：Rice/论文的 “121 links” 是否按有向弧计数、当前 CSV 是否每物理线正反各记录两行，需通过原始 INDP_data.txt 与生成脚本校准；不能直接拿 146 有向/73 无向与 121 作同口径差值。目前 Rice 官网 ZIP 链接在自动下载时返回 HTTP 406，已成功获取官方说明 PDF，但尚未获得 ZIP 内容文件以进行逐项对照。

新增来源：
- Rice 官方数据库页（含 Documentation 与 DataBase_tdINDP.zip 链接）：https://duenas-osorio.rice.edu/sissra/datasets-and-benchmarks
- Rice 官方数据库 README PDF（2016-08-02）：https://duenas-osorio.rice.edu/sites/g/files/bxs3351/files/2020-02/ReadMe_Resilience_Rice_20161011_v1.pdf
- Paredes et al. 论文 PDF（报告 60 power nodes / 121 links）：https://paredesroger.github.io/Papers/PDH18.pdf
- Hernandez-Fajardo & Dueñas-Osorio (2013), DOI 10.1016/j.ress.2012.10.012：https://doi.org/10.1016/j.ress.2012.10.012
- Hernandez-Fajardo & Dueñas-Osorio (2011), DOI 10.1193/1.3544052：https://doi.org/10.1193/1.3544052

## 新发现：td-INDP 数据存在 75 节点版本（继续溯源）
GitHub 上 `samurodrigonza/tdindp-capacities` 提供一个明确称为 tdINDP Shelby stylized instance 的可读版本及 CSV：PowerNodes.csv=75 nodes，PowerArcs.csv=93 原始有向行；其 loader 补齐反向边后为 184 arcs。类别为 9 Gate Stations、17 个 23kV Substation、25 个 12kV Substation、24 Intersections point。该仓库 README 称其 `pre_fix/data/benchmark_used_for_research_papers.csv` 是此前发表论文使用的 frontier，数据可追溯至 tdINDP/IN-DP 实例代码；但此仓库是第三方再打包/复现，不能未经与 Rice 原 ZIP 对照就当 Rice 原始档案本身。

因此目前发现至少四种不同口径：
- 60-node power subtransmission network / 121 links（相关网络论文明确报告）；
- 75-node / 184 bidirectionalized arcs 的 tdINDP 输入版本（第三方可复现仓库）；
- 44-node power model（Wang et al. 2022 的简化电网，只保留 8 gate +36 substations）；
- 当前项目 59-node / 146 directed records（类别 8 gate +37 substations +14 intersections）。

75-node 数据与当前 59-node 数据的坐标并非逐行一致（最近邻仅为近邻、不是同一坐标），类别计数也不同，不能将这份 75-node CSV直接当作当前 59-node CSV的原始明细。它的价值在于揭示 tdINDP 网络本身另有较大版本，并提供下一步对照素材。若需判定 59 节点的确切渊源，仍应取得 Rice ZIP/项目生成者的源文件或脚本，逐项对照原始 60/75-node 版本。

新增在线材料：
- 第三方 tdINDP 网络/容量数据仓库（含 PowerNodes.csv、PowerArcs.csv、README、原论文使用的 benchmark snapshot）：https://github.com/samurodrigonza/tdindp-capacities
- tdINDP 神经网络论文代码仓库（说明其使用 Shelby County TN testbed）：https://github.com/siavash91/Td-INDP-NN

## 2022 HLA co-simulation 论文的 Shelby 电力数据引文链（核对 PDF）
已下载并检索 Wang, Magoua & Li (2022), “Modeling cascading failure of interdependent critical infrastructure systems using HLA-based co-simulation”, *Automation in Construction* 133 (2022), 104008, DOI: 10.1016/j.autcon.2021.104008。该文 4.1.1 节原文明确写道：Shelby power network “Based on the descriptions provided in [48,49]”，含 8 gate stations、17 个 23 kV 和 19 个 12 kV substations（编号 1–36），gate stations 编为 37–44；Fig. 4 caption 为 “Topology of the power supply system (not to scale, modified from [49])”。因此该文报告的可计数电力对象是 44 个（36 substations + 8 gate stations）；图形拓扑特别说明由 [49] 改绘/修改。

论文参考文献条目核对如下：
- [48] A.D. Gonzalez, L. Duenas-Osorio, M. Sanchez-Silva, A.L. Medaglia, “The interdependent network design problem for optimal infrastructure system restoration,” *Computer-Aided Civil and Infrastructure Engineering* 31(5), 334–350 (2016), DOI 10.1111/mice.12171。它是Shelby interdependent network restoration / INDP 模型来源之一；Rice 该团队数据页另列 td-INDP database，介绍为 Shelby water/gas/power stylized networks。论文正文引用[48,49]来支撑网络描述，不是只引一个数据文件。
- [49] M. Shinozuka, A. Rose, R.T. Eguchi, *Engineering and Socioeconomic Impacts of Earthquakes: An Analysis of Electricity Lifeline Disruptions in the New Madrid Area*, MCEER report PB-99-130635/XAB (1998)，参考条目给出 Buffalo 报告 PDF URL。Wang et al. 的 Fig. 4 明确标注“modified from [49]”。这是该图的图形/历史电力 lifeline 背景来源。

交叉验证的结论与边界：
1. 2022 论文确实核实了“8+17+19=44”的 Shelby 电力网对象数，不是60节点全网的明确节点清单。其图称 not to scale，并由[49]修改；不能把图像或44对象描述当成逐节点 GIS/线路数据文件。
2. 2019 *Scientific Reports* “Competitive percolation strategies for network recovery” 报告 Shelby County transmission grid 为 N=60、E=76，并把网络溯源至 2016 González 等恢复工作；其他引文也转述 Shinozuka 历史电网有60 power nodes。这证明 60-node 抽象亦在文献中使用，但不是 2022 HLA 文所列 44 个节点同一口径。
3. 当前项目 CSV 是59节点（8 gate、17 个23kV、20 个12kV、14 intersections），并非2022文的44节点：比其多1个12kV节点及14个 intersections，少数目相抵后总节点多15。它也不能仅凭节点计数被认定为60节点版本（可能是抽象口径/数据筛选差异，须逐边、节点ID/坐标、类型核对）。
4. 目前已核实的是引用链与文献写明的类别/数量，不是 [49] 原始报告内是否存在可直接复刻当前59节点 CSV 的完整边表。报告 PDF 链接曾作为参考文献列出；需进一步逐页查阅其电力网络图/表并与 CSV 做结构映射。Rice 官方 td-INDP ZIP 仍HTTP 406，仍未取得用于逐文件比对的原始数据。

核验材料：
- Wang et al. 2022 PDF（已下载至临时文件 `/tmp/wanghla.pdf`；非工作区交付物），URL: http://en.urbanresilience.cn/Uploads/20220222/621430fd04f8a.pdf
- [49] 报告 PDF（论文引用 URL）: https://www.eng.buffalo.edu/mceer-reports/98/98-MN02.pdf
- [48] DOI: https://doi.org/10.1111/mice.12171
- Rice 数据页: https://duenas-osorio.rice.edu/sissra/datasets-and-benchmarks
- 60节点、76条边的 Shelby transmission network 文献: https://www.nature.com/articles/s41598-019-48036-0

## 对文献[48]、[49]的进一步核实（来源级核查）
本次直接核对了 Wiley 期刊页、University at Buffalo 官方 MCEER 仓储条目及 MCEER 原报告 PDF 的可索引内容。

### [48] González et al. (2016)
Wiley 官方记录确认书目信息：A.D. González, L. Dueñas-Osorio, M. Sánchez-Silva, A.L. Medaglia, “The Interdependent Network Design Problem for Optimal Infrastructure System Restoration,” *Computer-Aided Civil and Infrastructure Engineering*, 31(5), 334–350; DOI 10.1111/mice.12171；文章先于2015-12-04 online published，期刊卷期为2016年5月。论文主题是Shelby County互依网络的恢复优化模型与案例，不是纯数据集说明文。

可公开核验的后续同行评审材料对该案例网络有更具体的描述：Paredes et al. (2018) 直接称 Shelby power subtransmission test system 为60 nodes、121 links，water为49 nodes、71 links；其Shelby数据集/模型脉络与González等恢复工作一致。故[48]并不能简单解释为“44节点源数据”；60/121是文献中明确存在的更完整 power 图口径。HLA论文的44个对象应理解为它在2022研究中采用/描述的对象集（8 gate + 36 substations），而非足以证明[48]原始电网也只有44节点。

### [49] Shinozuka, Rose & Eguchi (1998)
参考项应按报告封面记为编辑者（editors）：M. Shinozuka, A. Rose, R.T. Eguchi (eds.), *Engineering and Socioeconomic Impacts of Earthquakes: An Analysis of Electricity Lifeline Disruptions in the New Madrid Area*, MCEER Monograph No. 2 / MCEER-98-MN02, 1998。University at Buffalo官方条目及官方MCEER报告PDF确认其身份。报告目录包含第3章“Seismic Performance of Electric Power Systems”（Masanobu Shinozuka、Howard H.M. Hwang），全报告关注New Madrid地震对Memphis地区电力lifeline及其经济影响。

报告前言/致谢称研究团队获得 Memphis Light, Gas and Water（MLGW）及 Shelby County Planning Department 的数据；这证实报告有真实当地资料基础。但目前可核实的公开条目和可检索报告内容没有提供一份可直接下载/复刻当前Shelby power nodes/edges的结构化节点—线路CSV。报告所含的电力系统脆弱性/地震影响分析也不等同于当代tdINDP数据文件。因此[49]是电力系统背景、工程资料与HLA图示改绘的来源，不能单凭它确立当前59节点CSV的逐项来源。

### 综合判断（对先前记录的校正）
- 文献[48]、[49]确实是Wang et al. (2022) Shelby电力系统描述的引用；但[48]是恢复优化研究，[49]是New Madrid/Memphis lifeline专题报告，二者均不能仅凭书目条目视为一份现成的“当前CSV来源文件”。
- HLA文献明确统计的44对象（8+17+19）是它的模型口径；图注明确表示拓扑图not to scale、modified from [49]。
- 另外文献明载的60节点/121线路 power subtransmission版本与44对象版本并存。当前59节点含14 intersection，不能只以节点数将其映射为44或60版；要完成来源确认仍需获取当代网络的逐节点/逐边文件，和当前CSV做ID/坐标/拓扑匹配。

直接来源：
- Wiley [48]官方文章页：https://onlinelibrary.wiley.com/doi/10.1111/mice.12171
- University at Buffalo官方[49]条目：https://ubir.buffalo.edu/xmlui/handle/10477/725
- [49]报告PDF（MCEER托管）：https://www.eng.buffalo.edu/mceer-reports/98/98-MN02.pdf
- 60 nodes /121 links文献复核：https://paredesroger.github.io/Papers/PDH18.pdf

## 原文/附件获取状态（2026-11-06）
- [49] MCEER-98-MN02：已通过 University at Buffalo 官方仓储条目确认元数据，并通过 Buffalo 官方旧域名 `https://www.eng.buffalo.edu/mceer-reports/98/98-MN02.pdf` 在线解析查阅报告前言/目录等文本。报告共9章，目录含第3章电力系统地震性能；报告致谢说明取得 MLGW 与 Shelby County Planning Department 数据。在线PDF解析对全文深层页面覆盖不完整，当前尚未逐页视觉核查第3章图表/附件。新版 Buffalo 仓储的直接 PDF 下载请求被服务端返回反爬验证 HTML；旧域名 PDF 可在网页阅读器中访问。
- [48] Wiley 官方文章页可查看完整书目信息和摘要，但 Wiley PDF/ePDF 链接当前返回访问拒绝/技术故障提示；页面没有可见的独立 Supporting Information/附件条目。尚未取得可本地打开的正式文章全文 PDF，因此没有伪称已逐页检查其正文。
- [48] 关联的 td-INDP database 是 Rice 实验室数据页单独列出的 benchmark ZIP，不是 Wiley 文章页面列出的附件。Rice 原始 ZIP URL 仍返回 HTTP 406；已找到的第三方仓库只能作为独立版本材料，不能替代官方附件核验。
- 本轮通过网页索引、官方元数据和可访问的报告文本已核实到来源性质和版本差异；若要完成[48]全文及附件的文件级核验，需取得出版商可访问的PDF（例如用户机构订阅）或作者公开稿/Rice原始ZIP。

## 纠正：用户上传 [48]/[49] 原文后的逐页核验（取代先前二手口径）
用户上传了 `1-s2.0-S1093968726007620-main.pdf`（González et al., DOI 10.1111/mice.12171，17页）与 `PB99130635.pdf`（MCEER-98-MN02，216页）。已用PDF文本解析检查正文及关键页。这里的全文直接证据优先于此前二手转述。

### [48] 原文实际写明
第4.1节“Power, water, and gas in Shelby County”称 Shelby 网络描述取自 Hernandez-Fajardo & Dueñas-Osorio (2010, 2011) 与 Song & Ok (2010)；并非说拓扑/网络清单直接取自 Shinozuka [49]。其量化句明确报告：总系统 289 components=125 nodes+164 links；power network 136 components=**60 nodes+76 links**；water 49+71；gas 16+17。Fig. 2(c)仅称 power network at a transmission level 的图示。
重要更正：此前 memo 一处记录“60 nodes / 121 links”，这是二手来源口径，不能用来描述用户给的[48]原文；对[48]应使用 60/76。121 links 不能归到该 PDF 的此网络实例。

### [49] 原文实际写明
用户给出的报告第3章第34页（PDF第58页）“Electric Power System”段落写明：MLGW electric power transmission network 是由 TVA 经 gate stations 向 **45 substations** 供电；包括 500、161、115、23 kV transmission lines，以及 gate、23 kV、12 kV substations；500 kV线及gate stations由 TVA运营，其他线路及变电站由 MLGW 运营。报告还明确警告：用于分析的电力系统模型“不是 Memphis 系统的精确模型”，原因是完整信息不可得；模型仅预期代表其近似物理特征，因此不应用该数值结果直接做具体技术/运营建议。Figure 3.1 是 MLGW transmission network 图。

### 与 HLA [2022] 的44节点口径及项目59节点的核验结论
- HLA论文写的是 8 gate + 17 个23kV +19 个12kV =44 对象；这个统计不等于[49]所说的45 substations（再加gate stations），也不等于[48]的60 nodes/76 links。因而HLA是在其案例模型中采用的一套较小组件清单/表示，不能说它完全照搬了[48]或[49]完整网络。
- [48]网络源头在其正文指向 Hernandez-Fajardo 2010/2011、Song & Ok 2010；它本身只给出图和汇总节点/边数，未在本文附表提供可直接映射的节点ID、逐边表或GIS坐标。
- [49]报告的45 substations是工程报告中的系统描述，且报告自承数据不完整、模型近似；图3.1可作历史拓扑/设备类型背景，却不是可直接机器读取的完整CSV附件。
- 当前项目CSV 59 nodes（8 gate、17 23kV、20 12kV、14 intersections）与[48] 60/76、[49] 45 substations + gate stations、HLA 44对象均非同一节点统计口径。当前CSV中14 intersections可能是拓扑中间点等建模节点，但仅凭命名/计数不能判定映射；应比较节点ID/坐标/边表后再下结论。
- 用户上传材料是两份文献原文（含正文中的图），不是数据附件包；本次未见任何独立Supplementary Information文件。Wang/HLA paper itself cites these texts rather than attaching a machine-readable Shelby dataset.

## 直接数据源确认：Figshare Shelby County Data（2026-11-06）
用户提供了 Figshare 数据集链接：https://figshare.com/articles/dataset/Shelby_County_Data/20060948。Figshare 公共 API 可访问并确认元数据：Alireza Rangrazjeddi (2022), “Shelby County Data,” version 1, DOI 10.6084/m9.figshare.20060948.v1；创建/公开日期 2022-06-13，许可 CC BY 4.0。描述为 Shelby County, TN interdependent infrastructure network，并说明该项目使用 Water 与 Power network。

Figshare API 列出的电力文件及校验：
- `Power Network Node Shelby Data.csv`，59 行节点数据，MD5 `04abb81d178faabe8d2009327007d5f5`；
- `Power Network Link Shelby  Data.csv`（Figshare 元数据文件名在 `Shelby` 后有双空格），146 行链路数据，MD5 `8ca4e7a92e6e9477c5d0fdf16061c943`。

归档目录中的 `Power Network Node Shelby Data.csv` 与 `Power Network Link Shelby Data.csv` 经逐文件 MD5 核对，分别与 Figshare API 元数据中的 computed_md5 完全一致。因此可确认这两份本工作区 Shelby 电网 CSV 的直接发布来源就是该 Figshare 数据集，而非此前推测的某一篇论文附表。Figshare 同一数据集还列有电-水互依关系、供水网络节点和链路 CSV；项目目录中的 `shelby_power_buses.csv` 是否由节点表转换得到，尚未做逐项校验。

这一发现解决的是“当前 CSV 文件直接从哪里发布/下载”的来源问题，不自动证明 Figshare 数据表与 [48] 文中 60 nodes/76 links 的具体生成关系。Figshare 表的 59 个节点、146 条链路与 [48] 的 60/76 仍存在版本/口径差异；若需追溯其科学/建模祖先，仍须比对 Figshare 数据集说明、作者代码和 [48] 的逐节点逐链路结构。先前关于当前工作区 CSV “来源未知”的表述由本节更新为：直接发布来源已确定为 Figshare，底层数据谱系与版本变换仍待查。
