# IEEE30 DC 潮流与冷却水调度原型核验记录

## 状态与文件
- 新增侧车脚本：`脚本/IEEE30_DC潮流验证.py`（单时段静态 smoke test）。
- 新增集成侧车：`脚本/IEEE30_DC冷却水仿真.py`。
- 未修改原脚本 `脚本/IEEE30_冷却水仿真.py`，未修改论文初稿。
- 集成脚本将 IEEE30 的 DC 节点功率平衡、线路 DC 方程、线路 rateA 限额加入时序 LP；保留冷却水约束、滚动控制时序和原冷端物理回放。

## 单时段 DC-OPF smoke test
命令：`python3 脚本/IEEE30_DC潮流验证.py`
- 30 母线、6 发电机、41 支路；总负荷 189.2 MW。
- 原始网络完整时：负荷削减 0 MW。
- bus 2 机组停运时：负荷削减仍为 0 MW（其余资源与网架可替代）。
- 最大节点平衡残差约 2.24e-13 MW 以下；DC 线路方程残差约 2.84e-14 MW 以下；线路限额违反 0。

## 与冷却水模型集成的初步核验
命令：`python3 脚本/IEEE30_DC冷却水仿真.py --mode both --duration-s 18000 --step-s 60 --replan-s 60`
参数采用默认 alpha=0.12、rho=0.425。结果：
- 预警时刻 13,403 s；当时 AET 1,827.66 s；初次 LP deadline 15,230 s。
- DC 被动 PA：冷端保护跳机时刻 15,376 s；故障后 DC 应急调度 ENS 18.886359583 MWh，峰值未供电 60.969000 MW；最大节点平衡残差 1.457e-13 MW，DC 残差 1.554e-13 MW，线路限额违反 0，最大线路利用率 98.457743%。
- 静态 SP：ENS 1.001290174 MWh，峰值未供电 13.030666667 MW；冷端回放在 15,230 s 发生计划停机。
- 动态 DP：ENS 0，峰值未供电 0 MW；冷端回放窗口内没有保护跳机。
- 动态滚动优化 58 次；主动策略共核验 59 次 LP（含 SP 初次求解）。最大节点平衡残差 1.284e-12 MW，DC 方程残差 4.903e-13 MW，线路限额违反 2.736e-13 MW，线性约束残差 1.284e-12；主动 LP 轨迹中最大线路利用率达到 100%。

## 当前解释与限制（不可称为最终结果）
1. 以上证明 DC 约束块已经接入优化 LP，且其节点平衡、线路方程、线路限额约束数值校验通过。
2. 结果只保存在终端/本记录，不更改手稿；不应先行写入论文。
3. 被动 PA 的保护跳机后应急再调度已另写为 DC 约束多时段 LP，健康机组在 trip 瞬间保持原出力，随后按原项目健康机组上爬坡限制恢复，并优化节点级缺供；逐秒插值后的 DC 方程、节点平衡、线路限额和爬坡均通过检查。SP 为计划停机，DP 窗口内没有保护跳机。若未来出现**早于计划的保护跳机**，当前主动策略回放器的应急健康机组调整仍可能使用原 aggregate recovery logic，须另行做 DC-feasible 应急再调度。
5. 当前 Pareto 选参脚本仍调用原聚合 LP。若要使用 DC-OPF 结果，必须另行用 DC 侧车重新做 alpha/rho 扫描和 Pareto 选择；不能直接沿用原选参结果。
6. 线路 rateA 使用 MATPOWER case30 原始值；机组成本采用原项目 `case_data` 中二次成本在初始出力处的边际线性化。模型仍是 DC 近似，不含电压/无功/损耗/频率。

## 时间网格与参数的追加检查
时间网格 `step-s` 是优化轨迹的 knot spacing（物理冷端仍按1 s回放），对 SP ENS 有可见影响：
- α=0.12、ρ=0.425，step=120 s：SP ENS 1.077156944 MWh，peak 13.310667 MW；
- step=60 s：SP ENS 1.001290174 MWh，peak 13.030667 MW；
- step=30 s：SP ENS 1.033221076 MWh，peak 13.170667 MW；
- step=15 s：SP ENS 1.012043229 MWh，peak 13.284250 MW；
- step=5 s：SP ENS 1.003884329 MWh，peak 13.380667 MW。
PA 的 ENS 在各分辨率约 18.8833–18.8945 MWh、peak 稳定 60.969 MW。DP 在已运行的 60 s/120 s网格均得到零 ENS；需注意零值可能受当前网格及阈值影响，不代表未经敏感性验证的普遍结论。SP 的 ENS 从 120 s 到 5 s 有约 6.8%变化；60 s 与 5 s 的 ENS 差约 0.26%。后续正式实验应采用更细网格（至少 5–15 s 做收敛对照），并固定/报告网格选择。

另运行 α=0.20、ρ=0.30、step=60 s：PA ENS 18.886359583 MWh / peak 60.969 MW；SP ENS 0.031500 MWh / peak 1.260 MW；DP ENS 0。该点仅为参数敏感性 smoke test，不是重新做过 Pareto 选参的结果，不能取代默认参数结论。

## DP 细网格收敛补充
已补做完整动态滚动 DP：
- step=15 s：57 次滚动更新，ENS=0，peak=0；58 次优化 LP 全通过 DC/线路校验；节点残差最大 1.460e-12 MW，DC 残差 5.809e-13 MW，线路限额违反 3.588e-13 MW。
- step=5 s：57 次滚动更新，ENS=0，peak=0；58 次优化 LP 全通过 DC/线路校验；节点残差最大 1.703e-12 MW，DC 残差 4.814e-13 MW，线路限额违反 2.132e-13 MW。
- step=60 s、120 s 的 DP 也均为 ENS=0/peak=0。
因此就当前情景与 alpha/rho 而言，DP 零缺供结果在 5–120 s 的优化网格下均复现；SP 则有较明显网格灵敏性，应正式比较时报告细网格或加密收敛结果。

## 2026-11-06：IEEE30 转为主算例并采用 DC-OPF 结果
用户决定现阶段以标准 IEEE30 为主，不再把来源未核清的 Shelby 数据作为论文定量主结果。原聚合主模型 `脚本/IEEE30_冷却水仿真.py` 保留不动；独立 DC-OPF 实现 `脚本/IEEE30_DC冷却水仿真.py` 现作为主网络约束实验入口，默认 mode=both、LP knot=5 s、DP replan=60 s。它复用原脚本的冷端物理回放，但替换 dispatch LP 为节点级 DC-OPF；并非 AC-OPF。

### 5-s 主结果复算（默认 α=0.12，ρ=0.425，T=18,000 s）
命令：`python3 脚本/IEEE30_DC冷却水仿真.py --mode both --duration-s 18000 --step-s 5 --replan-s 60 --alpha 0.12 --rho 0.425`
- case30：30 buses、6 generators、41 branches，总有功负荷 189.2 MW；水约束机组位于 bus 2，P0=60.969 MW，Pmax=80 MW。
- PA：ENS=18.883573241 MWh，峰值缺供=60.969 MW；物理保护跳机 15,376 s。跳机后由单独 DC 应急 LP 做健康机组再调度。
- SP：ENS=1.003884329 MWh，峰值缺供=13.380666667 MW；计划停机 15,230 s。
- DP：ENS=0、峰值缺供=0；57 次滚动更新，58 次 LP 检查；物理回放时域内无保护跳机，最低水量 263.301 m³。
- 主动 LP 最大节点残差 1.703e-12 MW，DC 支路方程残差 4.814e-13 MW，线路限额违反 2.132e-13 MW，最大 LP 约束残差 1.703e-12。PA passive post-trip DC replay 节点残差 2.558e-13 MW、DC 残差 1.918e-13 MW、线路限额违反 0。
- α=0.12、ρ=0.425 沿用旧聚合模型预筛值，仅作固定名义参数；没有声称已在 DC-OPF 下做 Pareto 重选或证明最优。

### 论文与可复现文件
- 新稿：`论文初稿/Cooling_Water_Resilience_IEEE30_DC_Revision.docx`。Shelby 定量主结果移出；增加节点平衡/DC 支路/率限约束公式，更新 ENS、峰值缺供、时间网格敏感性，并明确冷端模板非现场校准、DC不等于AC安全验证、Pmin未强制等边界。
- 图表重绘脚本：`脚本/IEEE30_DC主文稿图表.py`；输出到 `figures/IEEE30/`，不生成已删除的“结果”目录。
- 文稿重建脚本：`脚本/更新IEEE30主稿.py`；以原始 Draft_2.29 为源，产出 IEEE30 DC 版，不覆盖原稿。
- 主实验入口：`脚本/IEEE30_DC冷却水仿真.py`；原聚合主脚本保持原状。

### 论文里的 grid sensitivity 定量值
SP ENS (MWh) 与 LP knot spacing：5 s=1.003884329，15 s=1.012043229，30 s=1.033221076，60 s=1.001290174，120 s=1.077156944；非单调。相对5 s的最大差约7.30%，故5 s作为主报告网格，60 s值不称收敛值。DP已核验的5、15、60、120 s栅格ENS均为0；30 s动态DP未运行，不要声称每个中间网格都已验证。PA在5–120 s网格下ENS约18.8833–18.8945 MWh，峰值60.969 MW。

### 尚未完成/后续要点
- 正式主稿里 α、ρ 若要重新称为“selected/optimal”，需运行 DC-OPF 版本完整候选参数搜索；当前稿将其描述为继承的固定 nominal settings。
- Pmin（0.4Pmax）下方运行时间尚未对5-s DC轨迹重新计算；稿中表明其未在当前DC更新中重算，并再次说明Pmin未作为硬约束。
- DC 约束是线性化有功网流近似；未做 AC 潮流验证、无功/电压/频率分析、备用或 unit commitment。

## 2026-11-06 user revision: DC-OPF replaces aggregate primary; DC-specific α/ρ selected
User clarified that the DC model should overwrite the original aggregate model entry point and α/ρ must be recalculated. Applied: `脚本/IEEE30_冷却水仿真.py` is now the nodal DC-OPF primary executable (default α=0.12, ρ=0.45, step=60 s, mode=both). Original aggregate source was preserved as `脚本/IEEE30_冷却水仿真_aggregate_backup.py`; the new primary model imports this backup only for the pre-existing cold-end physics/replay. The earlier sidecar `脚本/IEEE30_DC冷却水仿真.py` is kept as a duplicate compatibility entry point. Primary selection script is now `脚本/IEEE30_Pareto选参.py`; the prior aggregate-only selection implementation is preserved as `脚本/IEEE30_Pareto选参_aggregate_backup.py`.

### DC-specific two-stage finite-grid α/ρ selection
- Search settings: T=18,000 s, LP knot=60 s, DP replan=60 s; DC nodal balance and MATPOWER branch limits active. The 5-s full two-policy/parameter search was attempted but was too costly in this runtime; the declared selection and primary evaluation therefore use the 60-s grid. This is explicit in the manuscript.
- Stage 1: ρ=0, α grid {0.04, 0.12, 0.20, 0.28, 0.36}. AET is treated as an early-warning/intervention-burden proxy and mean SP/DP ENS as service objective; normalized endpoint-chord knee selects **α=0.12** (AET=1,827.663 s; mean active ENS=0.430678 MWh; chord distance=0.499078).
- Stage 2: α=0.12, ρ grid {0.001, 0.01, 0.1, 0.2, 0.3, 0.35, 0.375, 0.4, 0.425, 0.45, 0.5, 0.6, 1.0, 2.0}; only 0<ρ≤0.5 eligible. Nine nondominated ρ points: 0.1, 0.2, 0.3, 0.35, 0.375, 0.4, 0.425, 0.45, 0.5. Endpoint-chord knee selects **ρ=0.45** (mean active ENS=0.552164 MWh; unweighted cost index=757.952063; chord distance=0.046726). Cost index is not a monetary cost, and selection is finite-grid/heuristic, not global optimum.
- Search artifacts: `结果/IEEE30_DCOPF_Pareto/IEEE30_DCOPF_Alpha_Rho_Pareto.xlsx`, `...png`, `selection_results.json`.

### Primary selected-pair evaluation (default model command)
Command: `python3 脚本/IEEE30_冷却水仿真.py` (defaults: both, 18,000 s, step=60, replan=60, α=.12, ρ=.45).
- PA: ENS=18.886359583 MWh; peak unmet=60.969 MW; trip=15,376 s.
- SP: ENS=1.104327674 MWh; peak unmet=13.590666667 MW; planned stop=15,230 s; minimum basin volume=278.247 m³.
- DP: ENS=0, peak unmet=0; 59 rolling updates; no physical trip; minimum basin volume=262.944 m³.
- 60 active LP solves: maximum nodal residual 1.156e-12 MW; DC-equation residual 2.434e-13 MW; line-limit violation 2.629e-13 MW; LP residual 1.156e-12; max line utilization 100%.
- Passive DC post-trip replay: ENS=18.886359583 MWh; max nodal residual 2.371e-13 MW; DC residual 1.572e-13 MW; line limit violation 0.
- SP knot sensitivity with selected α/ρ: 5 s=1.117469387 MWh; 15 s=1.123620208; 30 s=1.147423958; 60 s=1.104327674; 120 s=1.122450000. Relative maximum spread vs 60-s reference=3.90%. DP was only tested at the 60-s primary setting in this selected-pair run; do not claim DP zero across all knot spacings.

### Supersession and manuscript status
Prior α=.12/ρ=.425 and 5-s outcome text in the earlier 2026-11-06 note is superseded as the manuscript's primary parameter/result pair. The exact 5-s SP sensitivity values above are recalculated at α=.12/ρ=.45; the previous 5-s DP result at ρ=.425 is not the selected-pair DP result. Revised manuscript: `论文初稿/Cooling_Water_Resilience_IEEE30_DC_Revision.docx`; regeneration script: `脚本/更新IEEE30主稿.py`; graph script: `脚本/IEEE30_DC主文稿图表.py`. Original manuscript draft remains unchanged.

## 2026-11-06 later script consolidation (supersedes entry-point notes above)
The active simulation entries are `脚本/IEEE30_冷却水仿真.py` and `脚本/Shelby_County_DC冷却水仿真.py`. Each contains `--action run|select|all`; Shelby County case construction is integrated behind `--rebuild-case` and automatic missing-case recovery. Both import `脚本/Pareto_Selection_Core.py`. The required `脚本/IEEE30_冷却水仿真_aggregate_backup.py` is retained unchanged. The former standalone selector scripts and Shelby case-builder entry were removed after consolidation.

The single user-facing visualizer is `脚本/双案例组图.py`; it combines Figures 2/4/5/6/7 for both cases into `figures/Comparison/`. `--regenerate` invokes the internal style-preserving drawing sources (`脚本/_plot_ieee30_style.py`, `脚本/_plot_shelby_county_style.py`) before comparison assembly. The redundant single-case wrapper `IEEE30_DC主文稿图表.py` was removed. The manuscript generator was not run and no manuscript was modified in this refactor. Full run outputs are `结果/IEEE30_DCOPF/ieee30_selected_run.json` and `结果/Shelby_County_DCOPF/shelby_county_selected_run.json`.

## 2026-11-06 terminology and case presentation update
Per the user's correction, current research-facing materials identify the second case uniformly as **Shelby County**, without emphasizing its bus count. The study presents IEEE30 and Shelby County as equally important cases. Active entry is now `脚本/Shelby_County_DC冷却水仿真.py`; joint figures and outputs use `figures/Shelby_County/`, `结果/Shelby_County_DCOPF/`, and `结果/Shelby_County_DCOPF_Pareto/`. The topology panel no longer displays a node-count badge. The model still uses documented IEEE30-calibrated assumptions for electrical quantities not supplied by the Shelby County dataset; this method note is retained for accuracy, while “synthetic”/“59-node” framing has been removed from current presentation. Manuscript files remain untouched.

## 2026-11-06 archived-style redraw
Figures 2, 4, 5, 6, and 7 have been redrawn from the current IEEE30 and Shelby County run/selection outputs, following the layouts, panel grammar, and publication palette in `archive/legacy_two_case/scripts/`. Figure 1 and Figure 3 were not touched. The sole renderer is `脚本/双案例组图.py`; outputs are in `figures/Comparison/` as PNG/SVG/PDF, with supporting CSVs for Figures 4–7. Archived scripts themselves were not run because they retain old absolute paths and legacy case/parameter references. Current model assumptions and case labels remain as previously documented; manuscript files were not modified.

## 2026-11-06 后续绘图数据路径修订
后续脚本整理已取代上文的“Comparison/支撑 CSV”路径说明。当前 Figure 2/4/5/6/7 的可视化入口直接读取各案例已有运行 JSON、选参 JSON、MATPOWER 输入或 Shelby 原始节点/链路表，并在内存中计算绘图所需序列；不再另存双案例派生 CSV，也不存在 `结果/双案例图表数据/`。当前图片统一写入 `图片/` 根目录，格式仅 PNG；七个单图入口为 `脚本/Visualization/Figure1.py` 至 `Figure7.py`。
