# 双案例图组

此处仅保留 Figure 1–7 的 PNG 图片。Figures 1 和 3 从当前同步手稿原图提取，不重绘；Figure 2 使用 `data/figure2_assets/` 中的拓扑原图并校验当前网络规模，Figures 4–7 由当前双案例结果生成。

单图入口为 `脚本/Visualization/Figure1.py` 至 `Figure7.py`；绘图共用逻辑见 `Visualization_Core.py`。数据图读取当前案例 JSON、MATPOWER 和 Shelby 网络输入，不另存双案例中间 CSV。
