#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared rendering/data loader for the current two-case manuscript figures.

Figure 2 composes the supplied, bus-accurate topology artwork after checking it
against current case topology sizes; Figures 4–7 are drawn from current IEEE30 and
Shelby County inputs/results. Figures 1 and 3 are extracted unchanged from the
current synchronized manuscript. No retired single-case plotting scripts are required.
"""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
import networkx as nx
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, FancyBboxPatch, Rectangle

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'图片'
# One palette for every panel: case identity, strategy identity, and shared event marks.
IEEE='#1F4E79'; SHELBY='#1B7F74'; PA='#5C6B7A'; SP='#D17835'; DP='#2C6CB0'
CASES={
 'IEEE30':{
  'run':ROOT/'结果'/'IEEE30_DCOPF'/'ieee30_selected_run.json',
  'pareto':ROOT/'结果'/'IEEE30_DCOPF_Pareto'/'selection_results.json',
  'color':IEEE,'soft':'#E4EEF6'},
 'Shelby County':{
  'run':ROOT/'结果'/'Shelby_County_DCOPF'/'shelby_county_selected_run.json',
  'pareto':ROOT/'结果'/'Shelby_County_DCOPF_Pareto'/'selection_results.json',
  'color':SHELBY,'soft':'#E3F2F0'},
}
STRATEGIES=[('passive','PA',PA),('static','SP',SP),('dynamic','DP',DP)]
INK='#1C2833'; SLATE='#5C6770'; GRID='#E4E9ED'; SPINE='#7A8492'; RED='#B23A32'; GOLD='#E3B23C'
CHORD='#8A939C'


def load_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def load_cases():
    data={}
    for name,spec in CASES.items():
        run=load_json(spec['run']); selection=load_json(spec['pareto'])
        active=run['active']; passive=active['passive']; tr=passive['trajectory']
        case_path=ROOT/'data'/'IEEE30'/'case30.m' if name=='IEEE30' else ROOT/'data'/'Shelby'/'derived'/'case_shelby_county_dc.m'
        gen=matpower_table(case_path,'gen'); affected_gen=gen[np.isclose(gen[:,0],2)]
        if not len(affected_gen): raise RuntimeError(f'{name}: affected generator at bus/node 2 missing')
        case_spec={**spec,'p_rated_mw':float(affected_gen[0,8])}
        level=np.asarray(tr['water_level_m'],float); t=np.asarray(tr['time_s'],float)
        boundary=float(active['trip_level_m'])
        hits=np.flatnonzero(level<=boundary)
        if not len(hits): raise RuntimeError(f'{name}: passive trajectory did not reach the low-water boundary')
        j=int(hits[0])
        if j==0: low_s=float(t[0])
        else:
            t0,t1=t[j-1:j+1];h0,h1=level[j-1:j+1]
            low_s=float(t0+(boundary-h0)*(t1-t0)/(h1-h0)) if h1!=h0 else float(t1)
        trip_s=float(passive.get('trip',tr.get('trip_s')))
        data[name]={'spec':case_spec,'run':run,'active':active,'passive':passive,'passive_tr':tr,
                    'selection':selection,'low_s':low_s,'trip_s':trip_s,
                    'pressure_lag_s':trip_s-low_s}
    return data


def set_style():
    plt.rcParams.update({
      'font.family':'sans-serif','font.sans-serif':['Arial','Helvetica','DejaVu Sans','sans-serif'],
      'mathtext.fontset':'dejavusans','svg.fonttype':'none','pdf.fonttype':42,
      'font.size':7.5,'axes.titlesize':8,'axes.labelsize':7.5,
      'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':6.5,
      'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':0.8,
      'axes.edgecolor':SPINE,'xtick.color':SLATE,'ytick.color':SLATE,
      'text.color':INK,'axes.labelcolor':INK,'legend.frameon':False,'axes.titleweight':'bold'})


def clean_ax(ax,grid_axis='both'):
    ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color(SPINE);ax.spines['bottom'].set_color(SPINE)
    ax.tick_params(direction='out',length=2.6,width=.6,color=SPINE,pad=2.2)
    if grid_axis: ax.grid(True,axis=grid_axis,color=GRID,linewidth=.55,zorder=0)
    ax.set_axisbelow(True)


def panel_tag(ax, tag):
    ax.set_title(tag, loc='left', fontweight='bold', color=INK, pad=2.5, fontsize=8)


def column_title(fig, ax, name):
    pos=ax.get_position()
    fig.text((pos.x0+pos.x1)/2, pos.y1+0.016, name, ha='center', va='bottom',
             fontsize=9, fontweight='bold', color=CASES[name]['color'], clip_on=False)


def legend_kw(**extra):
    style=dict(frameon=False, fontsize=8, handlelength=1.6, handletextpad=.8, labelspacing=.25, borderaxespad=.3)
    style.update(extra)
    return style


def save_pair(fig, stem):
    OUT.mkdir(parents=True,exist_ok=True)
    png=OUT/f'{stem}.png'
    fig.savefig(png,dpi=400,bbox_inches='tight',facecolor='white')
    plt.close(fig)
    print('Wrote',png.relative_to(ROOT))


def matpower_table(path, table):
    text=path.read_text(encoding='utf-8')
    m=re.search(r'mpc\.'+table+r'\s*=\s*\[(.*?)\];',text,re.S)
    if not m: raise ValueError(f'MATPOWER table missing: {table}')
    rows=[]
    for line in m.group(1).splitlines():
        line=line.split('%',1)[0].strip().rstrip(';')
        if line: rows.append([float(x) for x in line.split()])
    return np.asarray(rows,float)


def get_topology(case_name):
    G=nx.Graph()
    if case_name=='IEEE30':
        base=ROOT/'data'/'IEEE30'/'case30.m'
        bus=matpower_table(base,'bus'); branch=matpower_table(base,'branch'); gen=matpower_table(base,'gen')
        G.add_nodes_from(int(x) for x in bus[:,0])
        G.add_edges_from((int(r[0]),int(r[1])) for r in branch)
        generators={int(x) for x in gen[:,0]}; affected=2
    else:
        import csv as _csv
        with (ROOT/'data'/'Shelby'/'Power Network Node Shelby Data.csv').open(newline='',encoding='utf-8-sig') as f:
            nodes=list(_csv.DictReader(f))
        with (ROOT/'data'/'Shelby'/'Power Network Link Shelby Data.csv').open(newline='',encoding='utf-8-sig') as f:
            links=list(_csv.DictReader(f))
        node_rows={int(r['Nodenum']):r for r in nodes}
        G.add_nodes_from(node_rows)
        G.add_edges_from({tuple(sorted((int(r['fromnode']),int(r['tonode'])))) for r in links})
        generators={i for i,r in node_rows.items() if r.get('type')=='gate_stations'}; affected=2
        pos={i:(float(r['X_Lon']),float(r['Y_Lat'])) for i,r in node_rows.items()}
        xs=np.array([p[0] for p in pos.values()]); ys=np.array([p[1] for p in pos.values()])
        dx=max(float(np.ptp(xs)),1e-9); dy=max(float(np.ptp(ys)),1e-9)
        pos={i:((x-xs.min())/dx,(y-ys.min())/dy) for i,(x,y) in pos.items()}
        return G,pos,generators,affected
    pos=nx.spring_layout(G,seed=27,k=1.05/np.sqrt(max(G.number_of_nodes(),1)),iterations=180)
    return G,pos,generators,affected


def redraw_fig2(data):
    """Compose the supplied, bus-accurate topology artwork as Figure 2.

    The two source schematics are preserved rather than replaced by a force-
    directed graph. The current model inputs are checked against their topology
    sizes before composition so the artwork cannot silently become stale.
    """
    from PIL import Image, ImageChops, ImageDraw, ImageFont, ImageOps
    assets=ROOT/'data'/'figure2_assets'
    ieee_src=assets/'IEEE_30bus_original_clarity_enhanced.png'
    shelby_src=assets/'Shelby_59_Node_Topology.png'
    for name,nodes,edges,generators in [('IEEE30',30,41,6),('Shelby County',59,73,8)]:
        graph,_,gens,_=get_topology(name)
        if (graph.number_of_nodes(),graph.number_of_edges(),len(gens))!=(nodes,edges,generators):
            raise RuntimeError(f'{name} topology does not match the supplied Figure 2 artwork')
    if not ieee_src.exists() or not shelby_src.exists():
        raise FileNotFoundError(f'Figure 2 source artwork missing from {assets}')

    def crop_to_artwork(im,padding=45):
        im=im.convert('RGB')
        diff=ImageChops.difference(im,Image.new('RGB',im.size,'white'))
        mask=diff.convert('L').point(lambda p:255 if p>18 else 0)
        box=mask.getbbox()
        if box is None:return im
        l,t,r,b=box
        return im.crop((max(0,l-padding),max(0,t-padding),min(im.width,r+padding),min(im.height,b+padding)))
    def tint(im,ink=INK):
        return ImageOps.colorize(im.convert('L'),black=ink,white='#FFFFFF').convert('RGB')
    def sans_font(size, bold=False):
        names=('arialbd.ttf','DejaVuSans-Bold.ttf') if bold else ('arial.ttf','DejaVuSans.ttf')
        roots=[Path(r'C:\Windows\Fonts'), Path('/usr/share/fonts/truetype/dejavu'), Path('/usr/share/fonts/truetype/liberation')]
        for root_dir in roots:
            for name in names:
                path=root_dir/name
                if path.exists(): return ImageFont.truetype(str(path), size)
        return ImageFont.load_default()

    ieee=Image.open(ieee_src).convert('RGB')
    # Enlarge bus labels in the supplied IEEE one-line diagram for legibility.
    draw=ImageDraw.Draw(ieee)
    boxes={1:(91,2667,105,2700),2:(646,3072,667,3105),3:(396,2667,414,2700),4:(719,2667,742,2700),5:(1638,3076,1653,3099),6:(1741,2667,1762,2700),7:(1814,2860,1835,2893),8:(2326,2669,2346,2704),9:(1427,2340,1450,2373),10:(1521,2068,1561,2101),11:(1072,2345,1106,2378),12:(698,2192,737,2225),13:(362,2193,400,2225),14:(460,1875,500,1907),15:(704,1244,742,1276),16:(943,1875,982,1907),17:(1416,1729,1456,1762),18:(1238,1244,1277,1276),19:(1699,1244,1737,1276),20:(1602,1488,1645,1520),21:(2051,1648,2092,1681),22:(2177,1868,2221,1901),23:(1130,872,1172,904),24:(1970,872,2014,904),25:(1689,516,1731,548),26:(1230,516,1274,548),27:(1166,176,1210,208),28:(2315,176,2360,208),29:(98,176,142,208),30:(97,596,142,628)}
    number_font=sans_font(48)
    for number,(x0,y0,x1,y1) in boxes.items():
        pad=5;draw.rectangle((x0-pad,y0-pad,x1+pad,y1+pad),fill='white');text=str(number)
        bb=draw.textbbox((0,0),text,font=number_font);tw,th=bb[2]-bb[0],bb[3]-bb[1];cx,cy=(x0+x1)/2,(y0+y1)/2
        draw.text((cx-tw/2-bb[0],cy-th/2-bb[1]),text,font=number_font,fill='black')
    # Enlarge IEEE generator/bus legend while retaining its symbols.
    card_box=(1972,3327,2549,3430);card=ieee.crop(card_box);scale=1.62
    card=card.resize((round(card.width*scale),round(card.height*scale)),Image.Resampling.LANCZOS)
    ImageDraw.Draw(card).rectangle((0,0,card.width-1,card.height-1),outline='white',width=10)
    ImageDraw.Draw(ieee).rectangle(card_box,fill='white')
    ieee.paste(card,(ieee.width-51-card.width,ieee.height-18-card.height))
    ieee=tint(crop_to_artwork(ieee))
    shelby=Image.open(shelby_src).convert('RGB')
    # Remove only the source legend's outer box; preserve the labels and glyphs.
    ImageDraw.Draw(shelby).rectangle((1840,2057,2420,2162),outline='white',width=12)
    shelby=tint(crop_to_artwork(shelby))

    image_h=2500
    def scale_height(im,h):
        return im.resize((round(im.width*h/im.height),h),Image.Resampling.LANCZOS)
    ieee_panel=scale_height(ieee,image_h);shelby_panel=scale_height(shelby,image_h)
    margin,gap,header_h,bottom_margin=60,100,130,50
    x1=margin;x2=x1+ieee_panel.width+gap;y_img=header_h
    canvas_w=x2+shelby_panel.width+margin;canvas_h=header_h+image_h+bottom_margin
    canvas=Image.new('RGB',(canvas_w,canvas_h),'white');draw=ImageDraw.Draw(canvas)
    label_font=sans_font(46, bold=True)
    title_font=sans_font(42, bold=True)
    for x,panel,label,title,title_color in [
        (x1,ieee_panel,'(a)','IEEE30',IEEE),(x2,shelby_panel,'(b)','Shelby County',SHELBY)]:
        draw.text((x+14,28),label,font=label_font,fill=INK)
        draw.text((x+118,32),title,font=title_font,fill=title_color)
        canvas.paste(panel,(x,y_img));draw.rectangle((x,y_img,x+panel.width-1,y_img+image_h-1),outline='#D5DDE3',width=2)
    OUT.mkdir(parents=True,exist_ok=True)
    out=OUT/'Figure2_network_topology_comparison.png'
    canvas.save(out,dpi=(300,300),optimize=True)
    print('Wrote',out.relative_to(ROOT),canvas.size,'; panels preserve their native aspect ratios')


def redraw_fig4(data):
    # Five shared rows: inventory, flow, temperature, backpressure, and output.
    set_style()
    fig,axes=plt.subplots(5,2,figsize=(7.5,9.15),sharey='row')
    fig.subplots_adjust(left=.135,right=.985,top=.945,bottom=.09,hspace=.48,wspace=.28)
    rows=[(r'$h_{\mathrm{basin}}$ (m)',(.85,3.72),[1,1.5,2,2.5,3,3.5]),
          (r'$Q_{cw}/Q_{design}$ (–)',(-.04,1.08),[0,.25,.5,.75,1]),
          (r'$T$ (°C)',(19,58),[20,30,40,50]),
          (r'$p_b$ (kPa)',(4,16.3),[4,6,8,10,12,14,16]),
          (r'$P/P_{\mathrm{rated}}$ (–)',(-.04,1.24),[0,.25,.5,.75,1])]
    level_color=SP; normal_color=SLATE
    event_handles=[Line2D([0],[0],color=level_color,ls=(0,(1,2)),lw=.95,label='1.0-m crossing'),
                   Line2D([0],[0],color=RED,ls=(0,(4,2)),lw=1.05,label='Trip')]
    for col,(name,d) in enumerate(data.items()):
        tr=d['passive_tr'];t=np.asarray(tr['time_s'],float);xh=t/3600
        low=float(d['low_s']);trip=float(d['trip_s']);lag=(trip-low)/60
        xe=(t-low)/60;color=CASES[name]['color']
        h=np.asarray(tr['water_level_m'],float);q=np.asarray(tr['qcw_frac'],float)
        for r,ax in enumerate(axes[:,col]):
            ax.set_ylim(*rows[r][1]);ax.set_yticks(rows[r][2]);clean_ax(ax,'both' if r<2 else None)
            ax.set_ylabel(rows[r][0],labelpad=5)
            ax.set_xlabel('Time (h)' if r<2 else 'Time (min)',labelpad=3)
            panel_tag(ax, f"({'a' if col==0 else 'b'}{r+1})")
        ax=axes[0,col]
        ax.plot(xh,h,color=color,lw=1.9,zorder=3)
        ax.axhline(float(d['active']['normal_level_m']),color=normal_color,ls=':',lw=1.0)
        ax.axhline(float(d['active']['trip_level_m']),color=level_color,ls='--',lw=1.0)
        ax.set_xlim(0,6);ax.set_xticks(np.arange(0,6.1,1))
        ax=axes[1,col];ax.plot(xh,q,color=color,lw=1.9,zorder=3)
        ax.set_xlim(0,6);ax.set_xticks(np.arange(0,6.1,1))
        for r in (2,3,4):
            ax=axes[r,col];ax.set_xlim(-4,4.5);ax.set_xticks([-4,-2,0,2,4])
            ax.axvspan(0,lag,color=RED,alpha=.045,zorder=0)
            ax.axvline(0,color=level_color,ls=(0,(1,2)),lw=.95,zorder=2)
            ax.axvline(lag,color=RED,ls=(0,(4,2)),lw=1.05,zorder=2)
        ax=axes[2,col]
        ax.plot(xe,np.asarray(tr['tin_c'],float),color=color,lw=1.6,ls=(0,(4,2)),alpha=.88,label='Tin')
        ax.plot(xe,np.asarray(tr['tsat_c'],float),color=color,lw=1.95,label='Tsat')
        ax.legend(loc='upper left', **legend_kw(ncol=2))
        ax=axes[3,col]
        ax.plot(xe,np.asarray(tr['pb_kpa'],float),color=color,lw=1.95,zorder=3)
        ax.axhline(15,color=RED,ls=(0,(5,3)),lw=.95,zorder=2)
        ax.text(-3.2,12.2,'15 kPa(a)',color=RED,fontsize=8,ha='left',va='center')
        ax=axes[4,col];rated=float(d['spec']['p_rated_mw'])
        ax.plot(xe,np.asarray(tr['p_cap_mw'],float)/rated,color=SLATE,ls='--',lw=1.5,zorder=3)
        ax.step(xe,np.asarray(tr['p_mw'],float)/rated,where='post',color=color,lw=1.9,zorder=4)
        ax.scatter([lag],[0],s=25,color=RED,zorder=5,edgecolor='white',linewidth=.6)
    fig.legend(handles=[
        Line2D([0],[0],color=SLATE,ls='--',lw=1.5,label='Available output'),
        Line2D([0],[0],color=SLATE,ls=':',lw=1.0,label='Normal level'),
        Line2D([0],[0],color=level_color,ls='--',lw=1.0,label='Low-water boundary'),
        *event_handles], loc='lower center', ncol=5, bbox_to_anchor=(.55,.012),
        frameon=False, fontsize=8, handlelength=1.8, handletextpad=.8, columnspacing=1.1)
    fig.canvas.draw()
    for col,name in enumerate(data):
        column_title(fig, axes[0,col], name)
    save_pair(fig,'Figure4_passive_cold_end_response')


def redraw_fig5(data):
    set_style()
    fig,ax=plt.subplots(figsize=(9.0,3.55));fig.subplots_adjust(left=.025,right=.985,top=.91,bottom=.12)
    ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
    x_nodes=[.22,.46,.71,.96]
    y_rows=[.70,.38]
    segment_colors=[PA, DP, RED]
    labels=['Interruption','First warning','Low-water boundary','Protection trip']
    node_colors=[PA, DP, SP, RED]
    for row,(name,d) in enumerate(data.items()):
        y=y_rows[row];alarm=float(d['active']['alarm'])/60;low=d['low_s']/60;trip=d['trip_s']/60
        aet=float(d['active']['aet'])/60;observed=max(0.,low-alarm);lag=max(0.,trip-low)
        ax.text(.005,y,name,ha='left',va='center',fontsize=9,fontweight='bold',color=CASES[name]['color'])
        for i,(x0,x1) in enumerate(zip(x_nodes[:-1],x_nodes[1:])):
            ax.annotate('',xy=(x1,y),xytext=(x0,y),
                arrowprops=dict(arrowstyle='-|>',lw=1.7,color=segment_colors[i],mutation_scale=9))
        ax.scatter(x_nodes,[y]*4,s=24,c=node_colors,zorder=4,edgecolors='white',linewidths=.55)
        segment_text=[f'Warning\n{alarm:.1f} min',
                      f'Water-only AET\nforecast {aet:.1f} min\nobserved {observed:.1f} min',
                      f'Protection lag\n{lag:.1f} min']
        for i,(x0,x1,txt) in enumerate(zip(x_nodes[:-1],x_nodes[1:],segment_text)):
            ax.text((x0+x1)/2,y+.055,txt,ha='center',va='bottom',fontsize=6.5,color=INK,linespacing=1.08,
                    bbox=dict(boxstyle='round,pad=.12',facecolor='white',edgecolor='none',alpha=.98))
    for x,lab in zip(x_nodes,labels):
        ax.text(x,.115,lab,ha='center',va='bottom',fontsize=7.2,color=INK)
    ax.text(.59,.015,'Sequence schematic; interval widths are not to scale.',
            ha='center',va='bottom',fontsize=7.0,color=SLATE)
    save_pair(fig,'Figure5_warning_AET_protection_sequence')


def redraw_fig6(data):
    # Time response above, shared-scale service bars below.
    set_style()
    fig=plt.figure(figsize=(9.1,7.85),facecolor='white')
    gs=fig.add_gridspec(4,2,height_ratios=[1.15,1.10,.78,.78],left=.105,right=.985,top=.86,bottom=.09,hspace=.58,wspace=.27)
    axs=np.array([[fig.add_subplot(gs[r,c]) for c in range(2)] for r in range(4)])
    metric_scale={m:max(float(d['active'][k][m]) for d in data.values() for k,_,_ in STRATEGIES) for m in ('peak','ens')}
    def value_label(v): return '<0.000001' if float(v)<1e-6 else f'{float(v):.2f}'
    span=0
    for d in data.values():
        alarm=float(d['active']['alarm'])
        for key,_,_ in STRATEGIES:
            x=(np.asarray(d['active'][key]['trajectory']['power_time_s'],float)-alarm)/60
            if np.any(x>=0): span=max(span, float(np.max(x[x>=0])))
    span=max(span, 1)
    for col,(name,d) in enumerate(data.items()):
        a=d['active'];alarm=float(a['alarm']);passive_tr=a['passive']['trajectory']
        pmat0=np.asarray(passive_tr['p_all_mw'],float);idx0=int(passive_tr['affected_index']);p0=float(pmat0[0,idx0])
        demand=float(passive_tr['demand_mw'])
        for row,ax in enumerate(axs[:,col],1):
            panel_tag(ax, f"({'a' if col==0 else 'b'}{row})")
        for key,label,color in STRATEGIES:
            item=a[key];tr=item['trajectory'];x=(np.asarray(tr['power_time_s'],float)-alarm)/60
            mask=x>=0
            pmat=np.asarray(tr['p_all_mw'],float);idx=int(tr['affected_index']);affected=pmat[:,idx];total=pmat.sum(axis=1);healthy=total-affected
            axs[0,col].plot(x[mask],affected[mask]/max(p0,1e-9),color=color,lw=1.7,zorder=3)
            axs[1,col].plot(x[mask],total[mask],color=color,lw=1.5,zorder=3)
            axs[1,col].plot(x[mask],healthy[mask],color=color,lw=1,ls='--',alpha=.72,zorder=2)
            ev=item.get('trip')
            if ev is not None and float(ev)>=alarm:
                ex=(float(ev)-alarm)/60;ls=':' if item.get('reason')=='backpressure_protection' else (0,(3,2))
                for ax in axs[:2,col]:ax.axvline(ex,color=color,lw=.9,ls=ls,alpha=.78,zorder=1)
        pmin=float(passive_tr['pmin_mw'])/max(p0,1e-9)
        axs[0,col].axhline(pmin,color=INK,lw=1,ls=':',zorder=1)
        axs[1,col].axhline(demand,color=INK,lw=1.05,ls=(0,(4,2)),zorder=1)
        for r,ax in enumerate(axs[:2,col]):
            clean_ax(ax,'both');ax.set_xlim(0,span);ax.set_xticks(np.arange(0,span+1,60));ax.set_xlabel('Time after warning (min)',labelpad=2)
        plotted=[np.asarray(ln.get_ydata(),float) for ln in axs[1,col].get_lines()]
        finite=np.concatenate([y[np.isfinite(y)] for y in plotted if y.size])
        finite=finite[finite>1]
        pad=0.08*(float(finite.max())-float(finite.min()))
        axs[1,col].set_ylim(float(finite.min())-pad, float(finite.max())+pad)
        axs[0,col].set_ylabel(r'$P_F/P_0$');axs[1,col].set_ylabel('Power (MW)')
        for row,metric,unit in [(2,'peak','Peak unserved power (MW)'),(3,'ens','Cumulative ENS (MWh)')]:
            ax=axs[row,col];vals=np.array([float(a[k][metric]) for k,_,_ in STRATEGIES]);ys=np.array([2,1,0]);xmax=max(float(metric_scale[metric])*1.42,1e-7)
            ax.barh(ys,vals,height=.52,color=[c for _,_,c in STRATEGIES],edgecolor='white',linewidth=.55,zorder=3)
            for yi,(_,_,color),v in zip(ys,STRATEGIES,vals):
                if v<1e-6:ax.scatter([0],[yi],s=15,marker='o',color=color,edgecolors='white',linewidths=.45,zorder=4)
                label_x=xmax*0.045 if v<1e-6 else float(v)+xmax*0.025
                ax.text(label_x,float(yi),value_label(v),ha='left',va='center',fontsize=7,color=INK,clip_on=False,zorder=5)
            ax.set_yticks(ys,[label for _,label,_ in STRATEGIES]);ax.set_xlim(0,xmax);ax.set_xlabel(unit,labelpad=2)
            ax.grid(False);ax.spines['left'].set_visible(False);ax.tick_params(axis='y',length=0,pad=5)
            ax.spines['bottom'].set_color(SPINE);ax.tick_params(axis='x',colors=SLATE)
            for tick,(_,_,color) in zip(ax.get_yticklabels(),STRATEGIES):tick.set_color(color);tick.set_fontweight('bold')
    fig.legend(handles=[Line2D([0],[0],color=c,lw=1.8,label=label) for _,label,c in STRATEGIES]+[
        Line2D([0],[0],color=INK,lw=1.3,label='Total'),
        Line2D([0],[0],color=INK,lw=1.05,ls='--',label='Healthy'),
        Line2D([0],[0],color=INK,lw=1.05,ls=(0,(4,2)),label='Demand'),
        Line2D([0],[0],color=INK,lw=1,ls=':',label='Minimum')],
        loc='upper center', ncol=7, bbox_to_anchor=(.5,.985), frameon=False, fontsize=8, handlelength=1.5, handletextpad=.6, columnspacing=.9)
    fig.canvas.draw()
    for col,name in enumerate(data):
        column_title(fig, axs[0,col], name)
    fig.text(.5,.02,'DC-OPF dispatch uses nodal balance and branch-flow limits. AC voltage and frequency are outside this comparison.',ha='center',va='bottom',fontsize=7,color=SLATE)
    save_pair(fig,'Figure6_strategy_outcomes_comparison')


def redraw_fig7(data):
    # Stage 1, stage 2, then the service change against passive operation.
    set_style()
    fig,axs=plt.subplots(3,2,figsize=(7.2,9.8),gridspec_kw={'height_ratios':[1.05,1.05,.78]})
    fig.subplots_adjust(left=.13,right=.985,top=.94,bottom=.08,hspace=.42,wspace=.28)
    alpha_color=IEEE; rho_color=SHELBY; select_color=GOLD; distance_color=RED
    def projection(points,xk,yk,selected):
        ordered=sorted(points,key=lambda p:p[xk]);a=np.array([ordered[0][xk],ordered[0][yk]],float);b=np.array([ordered[-1][xk],ordered[-1][yk]],float)
        p=np.array([selected[xk],selected[yk]],float);v=b-a;t=float(np.clip(np.dot(p-a,v)/max(float(np.dot(v,v)),1e-15),0,1));q=a+t*v
        return a,b,p,q,float(np.linalg.norm(p-q))
    def duplicate_groups(points):
        groups=[]
        for p in points:
            found=next((g for g in groups if abs(g['x']-p['norm_ens'])<=1e-8 and abs(g['y']-p['norm_cost_improvement'])<=1e-8),None)
            if found is None:groups.append({'x':p['norm_ens'],'y':p['norm_cost_improvement'],'selected':p['selected']})
            else:found['selected']=found['selected'] or p['selected']
        return sorted(groups,key=lambda g:(g['x'],g['y']))
    for col,(name,d) in enumerate(data.items()):
        sel=d['selection'];alpha=sorted(sel['alpha_candidates'],key=lambda r:r['norm_aet']);rho=sorted(sel['pareto_front'],key=lambda r:r['norm_ens'])
        chosen_a=next(r for r in alpha if r['selected']);chosen_r=next(r for r in rho if r['selected']);letter='a' if col==0 else 'b'
        for row,ax in enumerate(axs[:,col],1): panel_tag(ax, f'({letter}{row})')
        # Stage 1: alpha candidate chord and perpendicular distance.
        ax=axs[0,col];ax.plot([r['norm_aet'] for r in alpha],[r['norm_ens'] for r in alpha],color=alpha_color,marker='o',lw=1.65,ms=4.8,zorder=2)
        a,b,p,q,dist=projection(alpha,'norm_aet','norm_ens',chosen_a)
        stored=max(float(r['chord_distance']) for r in alpha)
        if abs(dist-stored)>1e-6:raise RuntimeError(f'{name} alpha chord mismatch: {dist} vs {stored}')
        ax.plot([a[0],b[0]],[a[1],b[1]],color=CHORD,lw=1,ls=(0,(4,2)),zorder=1);ax.plot([p[0],q[0]],[p[1],q[1]],color=distance_color,lw=1.2,ls=(0,(2,2)),zorder=4)
        ax.scatter([p[0]],[p[1]],marker='*',s=125,facecolor=select_color,edgecolor=INK,linewidth=.7,zorder=6);ax.scatter([q[0]],[q[1]],marker='x',s=24,color=distance_color,linewidth=1.1,zorder=6)
        ax.text(.98,.97,f"selected α = {chosen_a['alpha']:g}\n"+r'$d_{\perp}$ = '+f'{dist:.3f}',transform=ax.transAxes,ha='right',va='top',fontsize=8,color=INK,bbox=dict(boxstyle='round,pad=.25',facecolor='white',edgecolor='none',alpha=.94))
        ax.set_xlabel('Normalized warning-window burden (–)');ax.set_ylabel('Normalized mean active ENS (–)');ax.set_xlim(-.08,1.13);ax.set_ylim(-.08,1.13);clean_ax(ax,None)
        # Stage 2: Pareto points, endpoint chord and selected-point projection.
        ax=axs[1,col];groups=duplicate_groups(rho);ax.plot([g['x'] for g in groups],[g['y'] for g in groups],color=rho_color,lw=1.5,zorder=2)
        a,b,p,q,dist=projection(rho,'norm_ens','norm_cost_improvement',chosen_r);stored=max(float(r['chord_distance']) for r in rho)
        if abs(dist-stored)>1e-6:raise RuntimeError(f'{name} rho chord mismatch: {dist} vs {stored}')
        ax.plot([a[0],b[0]],[a[1],b[1]],color=CHORD,lw=1,ls=(0,(4,2)),zorder=1);ax.plot([p[0],q[0]],[p[1],q[1]],color=distance_color,lw=1.2,ls=(0,(2,2)),zorder=4)
        for g in groups:
            ax.scatter([g['x']],[g['y']],s=34,color=rho_color,zorder=3)
            if g['selected']:ax.scatter([g['x']],[g['y']],marker='*',s=132,facecolor=select_color,edgecolor=INK,linewidth=.7,zorder=7)
        ax.scatter([q[0]],[q[1]],marker='x',s=24,color=distance_color,linewidth=1.1,zorder=6)
        ax.text(.98,.04,f"selected ρ = {chosen_r['rho']:g}\n"+r'$d_{\perp}$ = '+f'{dist:.3f}\n{len(rho)} candidates / {len(groups)} points',transform=ax.transAxes,ha='right',va='bottom',fontsize=8,color=INK,bbox=dict(boxstyle='round,pad=.28',facecolor='white',edgecolor='none',alpha=.94))
        ax.set_xlabel('Normalized mean active ENS (–)');ax.set_ylabel('Normalized cost-proxy improvement (–)');ax.set_xlim(-.08,1.13);ax.set_ylim(-.08,1.13);clean_ax(ax,None)
        # Stage 3: service change against PA, using each case's current outcomes.
        ax=axs[2,col];active=d['active'];pa=float(active['passive']['ens']);ens=[pa,float(active['static']['ens']),float(active['dynamic']['ens'])]
        reductions=[0.0]+[float(np.clip(100*(1-v/pa),0,100)) if pa>0 else 0.0 for v in ens[1:]];ys=np.arange(3)
        bars=ax.barh(ys,reductions,height=.57,color=[c for _,_,c in STRATEGIES],edgecolor='white',linewidth=.7)
        ax.set_yticks(ys,[label for _,label,_ in STRATEGIES]);ax.invert_yaxis();ax.set_xlim(0,112);ax.set_xticks([0,25,50,75,100]);ax.set_xlabel('ENS reduction relative to PA (%)');ax.axvline(100,color='#C0C9CF',lw=.8,ls=':',zorder=0)
        for (_,label,_),bar,v,val in zip(STRATEGIES,bars,reductions,ens):
            y=bar.get_y()+bar.get_height()/2;text='>99.999%' if label=='DP' and val<1e-6 else (f'{v:.2f}%' if 99.9<v<100 else f'{v:.1f}%')
            if v>=88:ax.text(v-2,y,text,ha='right',va='center',fontsize=7.5,color='white',fontweight='bold')
            else:ax.text(max(v+2,2),y,text,ha='left',va='center',fontsize=7.5,color=INK,fontweight='bold')
        ax.grid(axis='x',color=GRID,lw=.65);ax.set_axisbelow(True)
        ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
        ax.spines['left'].set_color(SPINE);ax.spines['bottom'].set_color(SPINE)
        for tick,(_,_,color) in zip(ax.get_yticklabels(),STRATEGIES):tick.set_color(color);tick.set_fontweight('bold')
    for _ in range(3):
        fig.canvas.draw()
        box=axs[0,0].get_position()
        width_in=box.width*fig.get_figwidth(); height_in=box.height*fig.get_figheight()
        if abs(width_in-height_in)<0.03: break
        fig.set_figheight(fig.get_figheight()*width_in/height_in)
    geom=[Line2D([0],[0],color=alpha_color,lw=1.5,marker='o',ms=3.8,label='Candidates / front'),Line2D([0],[0],color=CHORD,lw=1,ls=(0,(4,2)),label='Endpoint chord'),Line2D([0],[0],color=distance_color,lw=1.15,ls=(0,(2,2)),marker='x',ms=3.5,label=r'$d_{\perp}$ to chord'),Line2D([0],[0],color=INK,lw=0,marker='*',markersize=8,markerfacecolor=select_color,label='Selected point')]
    fig.legend(handles=geom, loc='lower center', ncol=4, bbox_to_anchor=(.5,.01), frameon=False, fontsize=8, handlelength=1.8, handletextpad=.8, columnspacing=1.1)
    fig.canvas.draw()
    for col,name in enumerate(data):
        column_title(fig, axs[0,col], name)
    save_pair(fig,'Figure7_parameter_sensitivity_comparison')


def extract_manuscript_figure(number):
    from io import BytesIO
    from docx import Document
    from docx.oxml.ns import qn
    from PIL import Image
    paragraph_index={1:20,3:43}[number]
    source=ROOT/'手稿'/'Cooling_Water_Resilience_Two_Case_Synchronized.docx'
    doc=Document(source); drawings=doc.paragraphs[paragraph_index]._p.xpath('.//w:drawing')
    if not drawings: raise RuntimeError(f'Figure {number} drawing not found in {source}')
    rid=drawings[0].xpath('.//a:blip')[0].get(qn('r:embed'))
    part=doc.part.related_parts[rid]; blob=part.blob
    dest=ROOT/'图片'/f'Figure{number}_manuscript.png'
    dest.parent.mkdir(parents=True,exist_ok=True)
    if part.image.ext.lower()=='png': dest.write_bytes(blob)
    else: Image.open(BytesIO(blob)).convert('RGB').save(dest,format='PNG',optimize=True)
    print('Wrote',dest.relative_to(ROOT))


def run_figure(number):
    if number in (1,3):
        extract_manuscript_figure(number);return
    set_style();data=load_cases()
    draw={2:redraw_fig2,4:redraw_fig4,5:redraw_fig5,6:redraw_fig6,7:redraw_fig7}
    if number not in draw: raise ValueError('Figure number must be 1 through 7')
    draw[number](data)


def main():
    for number in range(1,8): run_figure(number)
    note=("# 双案例图组\n\n"
      "此处仅保留 Figure 1–7 的 PNG 图片。Figures 1 和 3 从当前同步手稿原图提取，不重绘；Figure 2 使用 `data/figure2_assets/` 中的拓扑原图并校验当前网络规模，Figures 4–7 由当前双案例结果生成。\n\n"
      "单图入口为 `脚本/Visualization/Figure1.py` 至 `Figure7.py`；绘图共用逻辑见 `Visualization_Core.py`。数据图读取当前案例 JSON、MATPOWER 和 Shelby 网络输入，不另存双案例中间 CSV。\n")
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'README.md').write_text(note,encoding='utf-8')

if __name__=='__main__':main()
