#!/usr/bin/env python3
"""Generate the paired strategy-outcomes figure."""
from Visualization_Core import run_figure

if __name__ == '__main__':
    run_figure(6)
