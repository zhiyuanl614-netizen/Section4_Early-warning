#!/usr/bin/env python3
"""Export the unchanged Figure 3 image embedded in the synchronized manuscript."""
from Visualization_Core import run_figure

if __name__ == '__main__':
    run_figure(3)
