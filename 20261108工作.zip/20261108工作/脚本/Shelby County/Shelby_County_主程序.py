#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shelby County DC-OPF and cooling-water resilience adapter.

Uses Shelby County dataset topology and reported flow attributes under the
stated modeling interpretation. Electrical fields absent from the dataset use
documented IEEE30-calibrated assumptions; results are conditional on them.
Only gate node 2 (local label G2; reported flow 319) is water-limited.
"""
from __future__ import annotations
import argparse, csv, importlib.util, json, re
from pathlib import Path
from types import SimpleNamespace
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/'data'/'Shelby'
DERIVED=DATA/'derived'
IEEE=ROOT/'data'/'IEEE30'/'case30.m'
OUT=DERIVED/'case_shelby_county_dc.m'
META=DERIVED/'case_shelby_county_dc_assumptions.json'
CASE=OUT
RESULT=ROOT/'结果'/'Shelby_County_DCOPF'


def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def get_table(text,name):
    m=re.search(r'mpc\.'+name+r'\s*=\s*\[(.*?)\];',text,re.S)
    if not m:raise ValueError('case missing '+name)
    return np.asarray([[float(x) for x in row.split('%',1)[0].strip().rstrip(';').split()]
      for row in m.group(1).splitlines() if row.split('%',1)[0].strip()],float)

def matpower_tables(path):
    text=path.read_text(encoding='utf-8')
    def get(name):
        m=re.search(r'mpc\.'+name+r'\s*=\s*\[(.*?)\];',text,re.S)
        if not m: raise ValueError('missing '+name)
        return np.asarray([[float(x) for x in row.split('%',1)[0].strip().rstrip(';').split()]
           for row in m.group(1).splitlines() if row.split('%',1)[0].strip()],float)
    base=float(re.search(r'mpc\.baseMVA\s*=\s*([\d.eE+-]+)',text).group(1))
    return {k:get(k) for k in ('bus','gen','branch','gencost')},base

def fmt(a):
    return '\n'.join('    '+' '.join(f'{v:.8g}' for v in row)+';' for row in a)

def build_case():
    ref,base=matpower_tables(IEEE)
    with open(DATA/'Power Network Node Shelby Data.csv',newline='',encoding='utf-8-sig') as f:
        nodes=list(csv.DictReader(f))
    with open(DATA/'Power Network Link Shelby Data.csv',newline='',encoding='utf-8-sig') as f:
        rawlinks=list(csv.DictReader(f))
    node_by_id={int(r['Nodenum']):r for r in nodes}
    gates=sorted((r for r in nodes if r['type']=='gate_stations'),key=lambda x:int(x['Nodenum']))
    if len(nodes)!=59 or len(gates)!=8: raise ValueError('Unexpected Shelby topology')
    p0=np.asarray([float(r['flow']) for r in gates])
    if np.any(p0<=0): raise ValueError('All gate flows must be positive')
    raw_pd={int(r['Nodenum']):max(0.,-float(r['flow'])) for r in nodes}
    raw_load=sum(raw_pd.values()); gen_total=float(p0.sum())
    load_scale=gen_total/raw_load
    pd={i:v*load_scale for i,v in raw_pd.items()}
    q_ratio=float(ref['bus'][:,3].sum()/ref['bus'][:,2].sum())
    qd={i:v*q_ratio for i,v in pd.items()}

    # Reconstruct undirected physical branches once; direction flags in the source are
    # retained in the source CSV but not imposed as one-way electrical flow limits.
    edge_map={}
    for r in rawlinks:
        a,b=int(r['fromnode']),int(r['tonode'])
        key=tuple(sorted((a,b)))
        if a==b: raise ValueError(f'self-loop {key}')
        if key not in edge_map: edge_map[key]=r
        elif abs(float(edge_map[key]['length'])-float(r['length']))>1e-8:
            raise ValueError(f'conflicting reverse-edge lengths at {key}')
    edges=sorted(edge_map.items())
    lengths=np.asarray([float(r['length']) for _,r in edges])
    x_scale=float(np.median(ref['branch'][:,3])/np.median(lengths))
    xvals=lengths*x_scale
    if np.any(xvals<=0): raise ValueError('nonpositive line reactance')
    load_scale_total=gen_total/float(ref['bus'][:,2].sum())
    # Use IEEE30's median thermal rating scaled to the Shelby base demand for every
    # un-rated Shelby branch; uniformity is explicit rather than invented per-line data.
    rate=float(np.median(ref['branch'][:,5])*load_scale_total)

    # The six IEEE30 P0/Pmax loading ratios are rank-interpolated to the eight gates.
    ref_p0=ref['gen'][:,1].copy(); ref_pmax=ref['gen'][:,8]
    slack=int(np.flatnonzero(ref['gen'][:,0]==1)[0])
    ref_p0[slack]-=float(ref_p0.sum()-ref['bus'][:,2].sum())
    ratios=np.sort(ref_p0/ref_pmax)
    rank=np.linspace(0,len(ratios)-1,len(gates))
    loading=np.interp(rank,np.arange(len(ratios)),ratios)
    pmax=np.empty(len(gates)); pmax[np.argsort(p0)]=np.sort(p0)/loading
    if np.any(pmax<p0): raise AssertionError('Pmax below flow-based P0')
    # Use the IEEE30 marginal-cost rank template, normalized to one, as relative costs.
    gc=ref['gencost']
    mc=2*gc[:,4]*ref_p0+gc[:,5]
    nmc=np.sort(mc/np.max(mc))
    nmc8=np.interp(rank,np.arange(len(nmc)),nmc)

    # MATPOWER bus schema: base kV labels follow the Shelby source type where known;
    # intersections use 23 kV as a stated placeholder. DC results do not use Q or kV.
    bus=[]
    gate_ids={int(r['Nodenum']) for r in gates}
    for r in sorted(nodes,key=lambda x:int(x['Nodenum'])):
        i=int(r['Nodenum']); typ=r['type']
        btype=3 if i==int(gates[0]['Nodenum']) else (2 if i in gate_ids else 1)
        kv={'gate_stations':115.,'23kv_substations':23.,'12kv_substations':12.,'intersections':23.}[typ]
        bus.append([i,btype,pd[i],qd[i],0.,0.,1,1.,0.,kv,1,1.05,.95])
    bus=np.asarray(bus,float)
    gen=[]
    for j,r in enumerate(gates):
        i=int(r['Nodenum']); p=p0[j]; pm=pmax[j]
        # Keep current research project's 0.7% Pmax/min ramp assumption; IEEE30 ramp
        # fields are zero, so this is not an empirical IEEE30 ramp value.
        gen.append([i,p,0.,1000.,-1000.,1.,base,1.,pm,0.,0.,0.,0.,0.,0.,0.,.007*pm,.07*pm,.21*pm,0.,0.])
    gen=np.asarray(gen,float)
    branch=[]
    for (a,b),r in edges:
        length=float(r['length']); x=length*x_scale
        branch.append([a,b,0.,x,0.,rate,rate,rate,0.,0.,1.,-360.,360.])
    branch=np.asarray(branch,float)
    # Linear gencost placeholders use the IEEE30 marginal-cost ranking; the cooling
    # dispatch adapter applies rho to the normalized template.
    gencost=np.asarray([[2,0,0,2,float(v),0.] for v in nmc8],float)

    text="function mpc = case_shelby_county_dc\nmpc.version = '2';\nmpc.baseMVA = 100;\n"
    for name,a in [('bus',bus),('gen',gen),('branch',branch),('gencost',gencost)]:
        text+=f'\nmpc.{name} = [\n{fmt(a)}\n];\n'
    OUT.write_text(text,encoding='utf-8')
    meta={
      'case':'Shelby County',
      'source':'Rangrazjeddi (2022), Figshare 10.6084/m9.figshare.20060948.v1',
      'baseMVA':base,'bus_count':len(bus),'generator_count':len(gen),'physical_branch_count':len(branch),
      'source_power_nodes':{'gates':8,'substations':37,'intersections':14},
      'gate_flow_as_P0_MW_assumption':True,'raw_gate_flow_total':gen_total,
      'raw_substation_load_abs_total':raw_load,'substation_load_multiplier':load_scale,
      'scaled_load_total':float(sum(pd.values())),'Q_over_P_from_IEEE30_total':q_ratio,
      'branch_direction':'undirected DC branches; paired source rows collapsed to one physical branch',
      'branch_x_rule':'x = source length * (median IEEE30 branch x / median Shelby source length); x units are per-unit surrogate',
      'branch_rateA_MW':rate,'branch_rate_rule':'median IEEE30 RATE_A scaled by total Shelby load / IEEE30 total load; uniform due absence of branch-specific ratings',
      'generator_pmax_rule':'P0 divided by rank-interpolated IEEE30 P0/Pmax loading ratios',
      'generator_pmin_MW':0,'ramp_rule':'0.007*Pmax per minute from prior project model assumption; IEEE30 ramp fields are zero',
      'cost_rule':'rank-interpolated normalized IEEE30 marginal costs; cooling dispatch rho scales relative generation cost',
      'affected_generator':'G2 = Figshare gate node 2; raw flow/P0 = 319; HLA-ID crosswalk not established',
      'main_sensitivity_requirement':'vary branch x/rateA, generator capacity ratios, and load multiplier; source metadata does not validate these physical values',
      'bus_base_kV_rule':'115 kV for gate, 23/12 kV for named substations, 23 kV placeholder for intersections; unused in DC equations',
      'reactive_load_rule':'Qd/Pd from aggregate IEEE30 bus ratio; ignored by DC-OPF',
      'data_source_line_capacity_cost_direction':'retained in original CSV; capacity/cost and direction codes are not used as verified electrical parameters',
      'generator_P0_MW':{f'G{int(r["Nodenum"])}':float(p0[k]) for k,r in enumerate(gates)},
      'generator_Pmax_MW':{f'G{int(r["Nodenum"])}':float(pmax[k]) for k,r in enumerate(gates)},
      'raw_load_by_node':{str(i):float(v) for i,v in raw_pd.items() if v>0},
      'scaled_load_by_node':{str(i):float(v) for i,v in pd.items() if v>0},
      'branch_x_range_pu':[float(xvals.min()),float(xvals.max())],
      'parameter_note':'Topology/flow fields come from the Shelby County dataset. Where the source does not specify DC electrical parameters (e.g. branch reactance and ratings), documented IEEE30-calibrated assumptions are used.'
    }
    META.write_text(json.dumps(meta,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(f'Created {OUT}')
    print('Shelby County DC-OPF input built from the dataset and documented parameter rules.')
    print(f'generation={gen_total:.6f} MW, raw_load={raw_load:.6f}, load_multiplier={load_scale:.9f}, scaled_load={sum(pd.values()):.6f} MW')
    print(f'P0 range={p0.min():.3f}..{p0.max():.3f}, Pmax range={pmax.min():.3f}..{pmax.max():.3f}, branch x={xvals.min():.5f}..{xvals.max():.5f}, rateA={rate:.3f} MW')


def custom_case_data(base,case='shelby59',generator_cost_ratio=.45):
    text=CASE.read_text(encoding='utf-8')
    bus,gen,gencost=(get_table(text,k) for k in ('bus','gen','gencost'))
    if case not in ('shelby59','shelby59_aggregate','ieee30'):
        raise ValueError('unsupported case '+str(case))
    if generator_cost_ratio<0 or not np.isfinite(generator_cost_ratio):
        raise ValueError('rho must be finite and nonnegative')
    gate_ids=gen[:,0].astype(int)
    affected_id=2 # Prior Shelby prototype's selected G2; Figshare gate node 2.
    hits=np.flatnonzero(gate_ids==affected_id)
    if len(hits)!=1:raise ValueError('G2 gate node 2 missing from gen table')
    F=int(hits[0]);p0=gen[:,1].copy();pmax=gen[:,8].copy()
    if not np.isclose(p0.sum(),bus[:,2].sum(),rtol=0,atol=1e-4):
        raise ValueError('base generation and scaled load do not balance')
    normalized_mc=gencost[:,4].copy()
    cgen=float(generator_cost_ratio)*normalized_mc
    RU=.007/60*pmax # retained project assumption; IEEE30 ramp columns are zero
    cold=base.cold
    model=cold.build_model(float(pmax[F]),ride_down=True,blowdown_isolated_on_detection=False)
    model=base.replace(model,basin_level_normal_m=base.BASIN_NORMAL_LEVEL_M,
      basin_level_trip_m=base.BASIN_TRIP_LEVEL_M,cycles_of_concentration=4.)
    pmin=model.p_min_tech_frac*pmax[F]
    sy=SimpleNamespace(N=len(gen),F=F,P0=p0,PMAX=pmax,RU=RU,L=float(bus[:,2].sum()),
      cgen=cgen,c_shed=1.,generator_cost_ratio=float(generator_cost_ratio),
      marginal_cost=normalized_mc,normalized_mc=normalized_mc,bus_codes=[f'G{i}' for i in gate_ids])
    return sy,model,cold,base.controlled_replay,float(pmin)

def run_parameter_selection(base,primary):
    core=load_module(ROOT/'脚本'/'IEEE30'/'Pareto_Selection_Core.py','pareto_selection_core_shelby59')
    out=ROOT/'结果'/'Shelby_County_DCOPF_Pareto';out.mkdir(parents=True,exist_ok=True)
    core.T=18000;core.STEP_S=60;core.REPLAN_S=60;core.OUT_DIR=out;core.CASE_LABEL='Shelby County'
    class Proxy:
        def scenario(self,case,**kwargs):
            primary.DC_CHECKS.clear()
            return base.scenario('shelby59',include_trajectory=False,**kwargs)
    proxy=Proxy()
    ar,rr,front,alpha,rho=core.select(proxy)
    core.write_workbook(out/'Shelby_County_Alpha_Rho_Pareto.xlsx',ar,rr,front,alpha,rho)
    core.write_plot(out/'Shelby_County_Alpha_Rho_Pareto.png',ar,rr,front,alpha,rho)
    payload={'case':'Shelby County','selected_alpha':alpha,'selected_rho':rho,
      'T_s':core.T,'LP_step_s':core.STEP_S,'DP_replan_s':core.REPLAN_S,
      'alpha_candidates':ar,'rho_candidates':rr,'pareto_front':front,
      'assumptions_file':'data/Shelby/derived/case_shelby_county_dc_assumptions.json',
      'qualification':'Electrical fields absent from the dataset use documented calibration assumptions; interpret results conditionally on those assumptions.'}
    (out/'selection_results.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(f'Shelby County selected alpha={alpha:.3f}, rho={rho:.3f}; outputs={out}')
    return alpha,rho


def save_run(result,passive,args,primary):
    RESULT.mkdir(parents=True,exist_ok=True)
    meta={'case':'Shelby County',
      'mode':args.mode,'duration_s':args.duration_s,'step_s':args.step_s,'replan_s':args.replan_s,
      'alpha':args.alpha,'rho':args.rho,'affected_generator':'G2 / gate node 2','affected_initial_flow_mw':319,
      'calibration_file':str(CASE),'assumptions_file':str(META)}
    full={**meta,'passive_dc':passive,'active':result,
      'qualification':'Electrical fields absent from the dataset use documented calibration assumptions; interpret results conditionally on those assumptions.'}
    to_json=lambda obj: obj.tolist() if isinstance(obj,np.ndarray) else (obj.item() if hasattr(obj,'item') else str(obj))
    (RESULT/'shelby_county_selected_run.json').write_text(json.dumps(full,indent=2,ensure_ascii=False,default=to_json)+'\n',encoding='utf-8')
    summary={**meta,'passive_dc':{k:v for k,v in passive.items() if k!='trajectory'},
      'active':{k:({q:z for q,z in v.items() if q!='trajectory'} if isinstance(v,dict) else v) for k,v in result.items()},
      'qualification':full['qualification']}
    (RESULT/'shelby_county_dc_cooling_results.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False,default=to_json)+'\n',encoding='utf-8')


def main():
    ap=argparse.ArgumentParser(description='Shelby County DC-OPF + cooling-water main simulation')
    ap.add_argument('--action',choices=('run','select','all'),default='run',help='run with parameters; select alpha/rho only; or select then run')
    ap.add_argument('--rebuild-case',action='store_true',help='rebuild the MATPOWER input from Shelby source CSVs')
    ap.add_argument('--mode',choices=('static','both','dynamic'),default='both')
    ap.add_argument('--duration-s',type=int,default=18000)
    ap.add_argument('--step-s',type=int,default=60)
    ap.add_argument('--replan-s',type=int,default=60)
    ap.add_argument('--rho',type=float,default=.20)
    ap.add_argument('--alpha',type=float,default=.12)
    a=ap.parse_args()
    if a.duration_s<2 or a.step_s<1 or a.replan_s<1:ap.error('invalid duration/step')
    if a.rebuild_case or not CASE.exists():build_case()
    primary=load_module(ROOT/'脚本'/'IEEE30'/'IEEE30_主程序.py','shelby_dc_primary')
    primary.CASE_PATH=CASE;primary.GRID=primary.load_case()
    base=primary.load_base_module()
    base.case_data=lambda case='shelby59',generator_cost_ratio=.45:custom_case_data(base,case,generator_cost_ratio)
    base.optimize=primary.optimize_dc
    if a.action in ('select','all'):
        a.alpha,a.rho=run_parameter_selection(base,primary)
        if a.action=='select':return
    primary.DC_CHECKS.clear()
    passive=primary.passive_dc(base,a.duration_s,a.step_s,a.rho)
    result=base.scenario('shelby59',T=a.duration_s,step=a.step_s,replan=a.replan_s,
      mode=a.mode,generator_cost_ratio=a.rho,warning_alpha=a.alpha,include_trajectory=True)
    result['case']='Shelby County'
    result['passive']={'ens':passive['ens_mwh'],'peak':passive['peak_unserved_mw'],'trip':passive['trip_s'],
      'reason':'backpressure_protection','trajectory':passive['trajectory']}
    passive_summary={'ens_mwh':passive['ens_mwh'],'peak_unserved_mw':passive['peak_unserved_mw'],
      'trip_s':passive['trip_s'],'max_nodal_residual_mw':passive['max_nodal_residual_mw'],
      'max_dc_equation_residual_mw':passive['max_dc_equation_residual_mw'],
      'max_line_limit_violation_mw':passive['max_line_limit_violation_mw'],
      'trajectory':passive['trajectory']}
    save_run(result,passive_summary,a,primary)
    print('Shelby County DC-OPF + cooling-water run')
    print(f'action={a.action}, mode={a.mode}, T={a.duration_s}s, step={a.step_s}s, alpha={a.alpha:g}, rho={a.rho:g}')
    print('DC-OPF network loaded; Shelby County topology and dispatch fields processed.')
    print('Affected generator: G2; reported dataset flow is interpreted as the initial generation proxy.')
    print(f'PA ENS={passive["ens_mwh"]:.6f} MWh, SP ENS={result.get("static",{}).get("ens",float("nan")) if result.get("static") else float("nan"):.6f} MWh, DP ENS={result.get("dynamic",{}).get("ens",float("nan")) if result.get("dynamic") else float("nan"):.6f} MWh')
    if primary.DC_CHECKS:print(f'DC solves checked={len(primary.DC_CHECKS)}, max nodal residual={max(x["nodal"] for x in primary.DC_CHECKS):.2e} MW, max DC residual={max(x["dc"] for x in primary.DC_CHECKS):.2e} MW, max line violation={max(x["line"] for x in primary.DC_CHECKS):.2e} MW')
    print('Saved:',RESULT/'shelby_county_selected_run.json')
    print('Parameter note: dataset topology/flow fields are used directly; electrical fields absent from the source use documented IEEE30-calibrated assumptions.')

if __name__=='__main__':main()
