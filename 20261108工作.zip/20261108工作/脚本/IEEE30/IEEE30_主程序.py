#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Primary IEEE30 cooling-water dispatch with nodal DC-OPF constraints.

Imports the unchanged aggregate cooling-water model, replaces only its dispatch LP
with a nodal DC-OPF LP, then uses the original PA/SP/DP timeline and physical replay.
This is the primary network-constrained IEEE30 experiment. The original aggregate
model file is imported only for cold-end physics and replay; it remains unchanged.
"""
from __future__ import annotations
import argparse
import importlib.util
import json
import math
import re
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

ROOT=Path(__file__).resolve().parents[2]
BASE_PATH=ROOT/'脚本'/'IEEE30'/'IEEE30_冷却水仿真_aggregate_backup.py'
CASE_PATH=ROOT/'data'/'IEEE30'/'case30.m'


def load_case():
    text=CASE_PATH.read_text(encoding='utf-8')
    def get(name):
        m=re.search(r'mpc\.'+name+r'\s*=\s*\[(.*?)\];',text,re.S)
        if not m: raise ValueError(f'MATPOWER case missing {name}')
        return np.asarray([[float(x) for x in row.split('%',1)[0].strip().rstrip(';').split()]
                           for row in m.group(1).splitlines() if row.split('%',1)[0].strip()],float)
    bus,gen,branch=get('bus'),get('gen'),get('branch')
    base=float(re.search(r'mpc\.baseMVA\s*=\s*([\d.eE+-]+)',text).group(1))
    ids={int(v):i for i,v in enumerate(bus[:,0])}
    nb,ng,nl=len(bus),len(gen),len(branch)
    inc=np.zeros((nb,nl)); fb=np.empty(nl,int);tb=np.empty(nl,int)
    bval=np.zeros(nl);shift=np.deg2rad(branch[:,9]);status=branch[:,10]!=0
    taps=branch[:,8].copy();taps[taps==0]=1.
    for l,row in enumerate(branch):
        fb[l]=ids[int(row[0])];tb[l]=ids[int(row[1])]
        inc[fb[l],l]=1.;inc[tb[l],l]=-1.
        if status[l]:
            if abs(row[3])<1e-12: raise ValueError(f'zero x on branch {l}')
            bval[l]=base/(row[3]*taps[l])
    rate=branch[:,5].copy()
    if np.any(rate[status]<=0): raise ValueError('active line missing positive rateA')
    gb=np.asarray([ids[int(v)] for v in gen[:,0]],int)
    return SimpleNamespace(bus=bus,gen=gen,branch=branch,nb=nb,ng=ng,nl=nl,base=base,
        ids=ids,inc=inc,fb=fb,tb=tb,bval=bval,shift=shift,status=status,rate=rate,gb=gb,
        pd=bus[:,2].copy(),ref=int(np.flatnonzero(bus[:,1]==3)[0]))

GRID=load_case()
DC_CHECKS=[]


def load_base_module():
    spec=importlib.util.spec_from_file_location('ieee30_cooling_aggregate_base',BASE_PATH)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod


def knots(T,alarm,trip,step):
    if not 0<alarm<trip<=T or step<1: raise ValueError('invalid event times')
    return np.asarray(sorted(set(range(alarm,T,step))|{alarm,trip,T}),dtype=int)


def optimize_dc(T,alarm,trip,water0,vmin,a,b,step,caps,sy):
    """Multi-period LP: nodal balance + DC line equations/limits + ramps + water."""
    g=GRID;N,F=sy.N,sy.F
    if N!=g.ng: raise ValueError('generator count disagrees with IEEE30 MATPOWER case')
    times=knots(T,alarm,trip,step);K=len(times);ng,nb,nl=g.ng,g.nb,g.nl
    pgid=np.arange(K*ng).reshape(K,ng)
    sid=pgid.size+np.arange(K*nb).reshape(K,nb)
    tid=pgid.size+sid.size+np.arange(K*nb).reshape(K,nb)
    fid=pgid.size+sid.size+tid.size+np.arange(K*nl).reshape(K,nl)
    nv=pgid.size+sid.size+tid.size+fid.size
    weights=np.zeros(K);water_weights=np.zeros(K)
    for k,dt in enumerate(np.diff(times)):
        wl=(dt+1)/2.;wr=(dt-1)/2.
        weights[k]+=wl;weights[k+1]+=wr
        if times[k]<trip:
            if times[k+1]>trip: raise AssertionError('trip knot missing')
            water_weights[k]+=wl;water_weights[k+1]+=wr
    c=np.zeros(nv)
    c[pgid.ravel()]=np.repeat(weights,ng)*np.tile(sy.cgen,K)/3600.
    c[sid.ravel()]=np.repeat(weights,nb)*sy.c_shed/3600.
    # Nodal balances and branch equations.
    er=[];ec=[];ev=[];rhs_eq=[];row=0
    for k in range(K):
        for n in range(nb):
            for i in np.flatnonzero(g.gb==n): er.append(row);ec.append(pgid[k,i]);ev.append(1.)
            er.append(row);ec.append(sid[k,n]);ev.append(1.)
            for l in np.flatnonzero(g.inc[n,:]): er.append(row);ec.append(fid[k,l]);ev.append(-g.inc[n,l])
            rhs_eq.append(g.pd[n]);row+=1
        for l in range(nl):
            er.append(row);ec.append(fid[k,l]);ev.append(1.)
            if g.status[l]:
                er.append(row);ec.append(tid[k,g.fb[l]]);ev.append(-g.bval[l])
                er.append(row);ec.append(tid[k,g.tb[l]]);ev.append(g.bval[l])
                rhs_eq.append(-g.bval[l]*g.shift[l])
            else: rhs_eq.append(0.)
            row+=1
    Aeq=coo_matrix((ev,(er,ec)),shape=(row,nv)).tocsr();beq=np.asarray(rhs_eq)
    # Ramp directions match the source policy: healthy units ramp up, affected unit down.
    direction=np.ones(ng);direction[F]=-1.
    limits=sy.RU.copy();limits[F]=sy.PMAX[F]
    ar=[];ac=[];av=[];bu=[];r=0
    for k in range(K):
        dt=times[k]-times[k-1] if k else 1
        for i in range(ng):
            d=direction[i]
            ar.extend([r,r]);ac.extend([pgid[k,i],pgid[k-1,i] if k else pgid[k,i]])
            av.extend([d,-d if k else 0.]);bu.append(float(limits[i]*dt+(d*sy.P0[i] if not k else 0.)));r+=1
            ar.extend([r,r]);ac.extend([pgid[k,i],pgid[k-1,i] if k else pgid[k,i]])
            av.extend([-d,d if k else 0.]);bu.append(float(-d*sy.P0[i] if not k else 0.));r+=1
    waterrow=r
    for k in range(K): ar.append(waterrow);ac.append(pgid[k,F]);av.append(b*water_weights[k])
    bu.append(float(water0-vmin-(trip-alarm)*a));r+=1
    Aub=coo_matrix((av,(ar,ac)),shape=(r,nv)).tocsr();bub=np.asarray(bu)
    ubpg=np.broadcast_to(sy.PMAX,(K,ng)).copy()
    if trip<T: ubpg[times>=trip,F]=0.
    for j,t in enumerate(times):
        if t>=trip: continue
        lo=max(alarm,int(times[j-1]) if j else int(t))
        hi=min(T,int(times[j+1]) if j+1<K else int(t),trip-1)
        if hi>=lo: ubpg[j,F]=min(ubpg[j,F],float(np.min(caps[lo:hi+1])))
    bounds=[]
    bounds += [(0.,float(v)) for v in ubpg.ravel()]
    bounds += [(0.,float(g.pd[n])) for k in range(K) for n in range(nb)]
    bounds += [((0.,0.) if n==g.ref else (-math.pi,math.pi)) for k in range(K) for n in range(nb)]
    bounds += [((-float(g.rate[l]),float(g.rate[l])) if g.status[l] else (0.,0.))
               for k in range(K) for l in range(nl)]
    res=linprog(c,A_ub=Aub,b_ub=bub,A_eq=Aeq,b_eq=beq,bounds=bounds,method='highs')
    if not res.success: raise RuntimeError(f'DC-OPF LP failed ({res.status}): {res.message}')
    pg=res.x[pgid];shed=res.x[sid];theta=res.x[tid];flow=res.x[fid]
    sec=np.arange(T+1)
    p=np.empty((T+1,ng));p[:alarm]=sy.P0
    s=np.zeros((T+1,nb));th=np.zeros((T+1,nb));fl=np.zeros((T+1,nl))
    for j in range(ng):p[alarm:,j]=np.interp(sec[alarm:],times,pg[:,j])
    for j in range(nb):
        s[alarm:,j]=np.interp(sec[alarm:],times,shed[:,j]);th[alarm:,j]=np.interp(sec[alarm:],times,theta[:,j])
    for j in range(nl):fl[alarm:,j]=np.interp(sec[alarm:],times,flow[:,j])
    if trip<T:p[trip:,F]=0.
    ens=float(s[alarm:T].sum()/3600.)
    gen_energy=p[alarm:T].sum(axis=0)/3600.
    gen_cost=float(np.dot(sy.cgen,gen_energy));expected_cost=gen_cost+sy.c_shed*ens
    objective_check=abs(float(res.fun)-expected_cost)
    water_used=(trip-alarm)*a+b*float(p[alarm:trip,F].sum())
    inj=np.zeros((T-alarm,nb))
    for j in range(ng):inj[:,g.gb[j]]+=p[alarm:T,j]
    inj-=g.pd[None,:]-s[alarm:T,:]
    inj-=fl[alarm:T,:]@g.inc.T
    bal_res=float(np.max(np.abs(inj)))
    dc_flow=g.bval[None,:]*(th[alarm:T,g.fb]-th[alarm:T,g.tb]-g.shift[None,:])
    dc_flow[:,~g.status]=0.
    dc_res=float(np.max(np.abs(dc_flow-fl[alarm:T])))
    limit_res=float(max(0.,np.max(np.abs(fl[alarm:T, g.status])-g.rate[g.status])))
    linear_violation=float(max(0.,np.max(Aub@res.x-bub),np.max(np.abs(Aeq@res.x-beq))))
    dp=np.diff(p[:T],axis=0);healthy=np.arange(ng)!=F;tol=2e-5
    if bal_res>tol or dc_res>tol or limit_res>tol or linear_violation>tol: raise RuntimeError('DC balance/line/LP residual verification failed')
    if water_used>water0-vmin+tol or objective_check>tol: raise RuntimeError('water/objective consistency check failed')
    if np.max(dp[:,healthy]-sy.RU[healthy])>tol or np.min(dp[:,healthy])<-tol: raise RuntimeError('healthy-unit ramp verification failed')
    if trip<T and np.max(p[trip:T,F])>tol: raise RuntimeError('planned trip not enforced')
    peak=float(np.max(s[alarm:T,:].sum(axis=1)))
    DC_CHECKS.append({'nodal':bal_res,'dc':dc_res,'line':limit_res,'lp':linear_violation,
                      'line_utilization':float(np.max(np.abs(fl[alarm:T][:,g.status])/g.rate[g.status]))})
    return {'p':p,'trip':trip,'ens':ens,'peak':peak,'violation':linear_violation,
        'objective_check':objective_check,'objective_cost':expected_cost,
        'load_shed_cost':float(sy.c_shed*ens),'generation_cost':gen_cost,
        'water_used':water_used,'node_count':K,'solver':res.message,
        'max_nodal_residual_mw':bal_res,'max_dc_equation_residual_mw':dc_res,
        'max_line_limit_violation_mw':limit_res,'shed_by_bus_mw':s,'flows_mw':fl,
        'theta_rad':th,'line_max_utilization':float(np.max(np.abs(fl[alarm:T][:,g.status])/g.rate[g.status]))}


def passive_dc(base,T,step,rho):
    """Passive policy with DC-feasible emergency redispatch after physical trip.

    Until the cold-end protection event, generators remain at the base schedule.
    At the trip instant the affected unit is forced to zero and healthy units are
    held at their pre-trip outputs; subsequent healthy ramp-up is optimized to
    minimize ENS subject to DC network and thermal limits.
    """
    sy,model,cold,engine,pmin=base.case_data('ieee30',generator_cost_ratio=rho)
    schedule=np.broadcast_to(sy.P0,(T+1,sy.N)).copy()
    cold_run=base.replay(engine,model,sy,schedule[:,sy.F],T+1,T)
    if cold_run.t_trip_h is None: raise RuntimeError('passive case has no protection trip in horizon')
    trip=int(round(cold_run.t_trip_h*3600))
    if trip<=0 or trip>=T: raise RuntimeError(f'passive trip outside horizon: {trip}')
    # Post-trip event grid; timestep immediately at trip captures instantaneous loss.
    times=np.asarray(sorted(set([trip]+list(range(trip+step,T,step))+[T])),int)
    K=len(times);g=GRID;ng,nb,nl=g.ng,g.nb,g.nl
    if K<2: raise RuntimeError('post-trip horizon too short')
    pgid=np.arange(K*ng).reshape(K,ng);sid=pgid.size+np.arange(K*nb).reshape(K,nb)
    tid=pgid.size+sid.size+np.arange(K*nb).reshape(K,nb)
    fid=pgid.size+sid.size+tid.size+np.arange(K*nl).reshape(K,nl);nv=pgid.size+sid.size+tid.size+fid.size
    weights=np.zeros(K)
    for k,dt in enumerate(np.diff(times)):
        weights[k]+=(dt+1)/2.;weights[k+1]+=(dt-1)/2.
    c=np.zeros(nv);c[pgid.ravel()]=np.repeat(weights,ng)*np.tile(sy.cgen,K)/3600.
    c[sid.ravel()]=np.repeat(weights,nb)*sy.c_shed/3600.
    # DC equalities at every post-event knot.
    er=[];ec=[];ev=[];beq=[];row=0
    for k in range(K):
        for n in range(nb):
            for i in np.flatnonzero(g.gb==n):er.append(row);ec.append(pgid[k,i]);ev.append(1.)
            er.append(row);ec.append(sid[k,n]);ev.append(1.)
            for l in np.flatnonzero(g.inc[n]):er.append(row);ec.append(fid[k,l]);ev.append(-g.inc[n,l])
            beq.append(g.pd[n]);row+=1
        for l in range(nl):
            er.append(row);ec.append(fid[k,l]);ev.append(1.)
            if g.status[l]:
                er.extend([row,row]);ec.extend([tid[k,g.fb[l]],tid[k,g.tb[l]]]);ev.extend([-g.bval[l],g.bval[l]])
                beq.append(-g.bval[l]*g.shift[l])
            else:beq.append(0.)
            row+=1
    Aeq=coo_matrix((ev,(er,ec)),shape=(row,nv)).tocsr()
    # Healthy units are fixed through the instantaneous trip at t_trip.
    bounds=[]
    for k in range(K):
        for i in range(ng):
            if i==sy.F:bounds.append((0.,0.))
            elif k==0:bounds.append((float(sy.P0[i]),float(sy.P0[i])))
            else:bounds.append((0.,float(sy.PMAX[i])))
    bounds += [(0.,float(g.pd[n])) for k in range(K) for n in range(nb)]
    bounds += [((0.,0.) if n==g.ref else (-math.pi,math.pi)) for k in range(K) for n in range(nb)]
    bounds += [((-float(g.rate[l]),float(g.rate[l])) if g.status[l] else (0.,0.)) for k in range(K) for l in range(nl)]
    # Healthy ramp-up only after the trip instant.
    ar=[];ac=[];av=[];bub=[];rr=0
    for k in range(1,K):
        dt=times[k]-times[k-1]
        for i in range(ng):
            if i==sy.F:continue
            ar.extend([rr,rr]);ac.extend([pgid[k,i],pgid[k-1,i]]);av.extend([1.,-1.]);bub.append(float(sy.RU[i]*dt));rr+=1
            ar.extend([rr,rr]);ac.extend([pgid[k,i],pgid[k-1,i]]);av.extend([-1.,1.]);bub.append(0.);rr+=1
    Aub=coo_matrix((av,(ar,ac)),shape=(rr,nv)).tocsr()
    res=linprog(c,A_eq=Aeq,b_eq=np.asarray(beq),A_ub=Aub,b_ub=np.asarray(bub),bounds=bounds,method='highs')
    if not res.success:raise RuntimeError(f'passive post-trip DC-OPF failed: {res.message}')
    pg=res.x[pgid];shed=res.x[sid];th=res.x[tid];flow=res.x[fid]
    sec=np.arange(trip,T+1);p=np.empty((len(sec),ng));s=np.zeros((len(sec),nb));theta=np.zeros((len(sec),nb));fl=np.zeros((len(sec),nl))
    for i in range(ng):p[:,i]=np.interp(sec,times,pg[:,i])
    for i in range(nb):s[:,i]=np.interp(sec,times,shed[:,i]);theta[:,i]=np.interp(sec,times,th[:,i])
    for i in range(nl):fl[:,i]=np.interp(sec,times,flow[:,i])
    # Include the event instant and every second through T-1 in metrics.
    ens=float(s[:-1].sum()/3600.);peak=float(s[:-1].sum(axis=1).max())
    nodal=np.zeros((len(sec),nb))
    for i in range(ng):nodal[:,g.gb[i]]+=p[:,i]
    nodal-=g.pd[None,:]-s;nodal-=fl@g.inc.T
    dcflow=g.bval[None,:]*(theta[:,g.fb]-theta[:,g.tb]-g.shift[None,:]);dcflow[:,~g.status]=0.
    bal=float(np.max(np.abs(nodal)));dc=float(np.max(np.abs(dcflow-fl)))
    lim=float(max(0.,np.max(np.abs(fl[:,g.status])-g.rate[g.status])))
    if max(bal,dc,lim)>2e-5:raise RuntimeError(f'passive DC trajectory validation failed: {bal}, {dc}, {lim}')
    # ramp checks across interpolated second-by-second trajectory
    healthy=np.arange(ng)!=sy.F;dp=np.diff(p,axis=0)
    if np.max(dp[:,healthy]-sy.RU[healthy])>2e-5 or np.min(dp[:,healthy])<-2e-5:
        raise RuntimeError('passive healthy ramp validation failed')
    p_full=np.broadcast_to(sy.P0,(T+1,ng)).copy();p_full[trip:]=p
    shed_full=np.zeros(T+1);shed_full[trip:]=s.sum(axis=1)
    trajectory={'time_s':np.asarray(cold_run.t_s,dtype=float),
        'water_m3':np.asarray(cold_run.volume_m3,dtype=float),
        'water_level_m':np.asarray(cold_run.level_m,dtype=float),
        'qcw_frac':np.asarray(cold_run.qcw_frac,dtype=float),
        'tin_c':np.asarray(cold_run.tin_c,dtype=float),
        'tsat_c':np.asarray(cold_run.tsat_c,dtype=float),
        'pb_kpa':np.asarray(cold_run.pb_kpa,dtype=float),
        'p_mw':np.asarray(cold_run.p_mw,dtype=float),
        'p_cap_mw':np.asarray(cold_run.p_cap_mw,dtype=float),
        'loss_m3s':np.asarray(cold_run.loss_m3s,dtype=float),
        'p_all_mw':p_full,'power_time_s':np.arange(T+1,dtype=float),
        'load_shed_mw':shed_full,'shed_time_s':np.arange(T+1,dtype=float),
        'demand_mw':float(g.pd.sum()),'affected_index':int(sy.F),
        'pmin_mw':float(pmin),'trip_s':trip,'stop_reason':'backpressure_protection'}
    return {'trip_s':trip,'ens_mwh':ens,'peak_unserved_mw':peak,
        'max_nodal_residual_mw':bal,'max_dc_equation_residual_mw':dc,
        'max_line_limit_violation_mw':lim,
        'max_line_utilization':float(np.max(np.abs(fl[:,g.status])/g.rate[g.status])),
        'shed_at_trip_mw':float(s[0].sum()),'post_trip_knot_count':K,
        'trajectory':trajectory}


def run_parameter_selection(base):
    """Run the shared discrete alpha/rho selector from this case's main entry."""
    core_path=ROOT/'脚本'/'IEEE30'/'Pareto_Selection_Core.py'
    spec=importlib.util.spec_from_file_location('pareto_selection_core_ieee30',core_path)
    core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
    out=ROOT/'结果'/'IEEE30_DCOPF_Pareto';out.mkdir(parents=True,exist_ok=True)
    core.T=18000;core.STEP_S=60;core.REPLAN_S=60;core.OUT_DIR=out;core.CASE_LABEL='IEEE30'
    class Proxy:
        def scenario(self,case,**kwargs):
            DC_CHECKS.clear()
            return base.scenario('ieee30',include_trajectory=False,**kwargs)
    proxy=Proxy()
    ar,rr,front,alpha,rho=core.select(proxy)
    core.write_workbook(out/'IEEE30_DCOPF_Alpha_Rho_Pareto.xlsx',ar,rr,front,alpha,rho)
    core.write_plot(out/'IEEE30_DCOPF_Alpha_Rho_Pareto.png',ar,rr,front,alpha,rho)
    payload={'selected_alpha':alpha,'selected_rho':rho,'T_s':core.T,'LP_step_s':core.STEP_S,
      'DP_replan_s':core.REPLAN_S,'alpha_candidates':ar,'rho_candidates':rr,'pareto_front':front}
    (out/'selection_results.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(f'IEEE30 selected alpha={alpha:.3f}, rho={rho:.3f}; outputs={out}')
    return alpha,rho


def save_run(result,passive,args):
    out=ROOT/'结果'/'IEEE30_DCOPF';out.mkdir(parents=True,exist_ok=True)
    payload={'case':'IEEE30','T_s':args.duration_s,'LP_step_s':args.step_s,'DP_replan_s':args.replan_s,
      'alpha':args.alpha,'rho':args.rho,'network':{'buses':GRID.nb,'generators':GRID.ng,'branches':GRID.nl},
      'passive_dc':passive,'active':result,
      'qualification':'DC-OPF IEEE30 case with the manuscript cooling-water model.'}
    (out/'ieee30_selected_run.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False,
       default=lambda x:x.tolist() if isinstance(x,np.ndarray) else (x.item() if hasattr(x,'item') else str(x)))+'\n',encoding='utf-8')


def main():
    ap=argparse.ArgumentParser(description='IEEE30 DC-OPF + cooling-water simulation; includes the alpha/rho sweep.')
    ap.add_argument('--action',choices=('run','select','all'),default='run',help='run selected parameters; select only; or select then run')
    ap.add_argument('--mode',choices=('static','both','dynamic'),default='both')
    ap.add_argument('--duration-s',type=int,default=18000)
    ap.add_argument('--step-s',type=int,default=60)
    ap.add_argument('--replan-s',type=int,default=60)
    ap.add_argument('--rho',type=float,default=0.45)
    ap.add_argument('--alpha',type=float,default=0.12)
    args=ap.parse_args()
    if args.duration_s<2 or args.step_s<1 or args.replan_s<1:ap.error('invalid duration/step')
    base=load_base_module();base.optimize=optimize_dc
    if args.action in ('select','all'):
        args.alpha,args.rho=run_parameter_selection(base)
        if args.action=='select':return
    DC_CHECKS.clear()
    passive=passive_dc(base,args.duration_s,args.step_s,args.rho)
    result=base.scenario('ieee30',T=args.duration_s,step=args.step_s,replan=args.replan_s,
        mode=args.mode,generator_cost_ratio=args.rho,warning_alpha=args.alpha,include_trajectory=True)
    result['passive']={'ens':passive['ens_mwh'],'peak':passive['peak_unserved_mw'],'trip':passive['trip_s'],
        'reason':'backpressure_protection','trajectory':passive['trajectory']}
    save_run(result,{'ens_mwh':passive['ens_mwh'],'peak_unserved_mw':passive['peak_unserved_mw'],
        'trip_s':passive['trip_s'],'max_nodal_residual_mw':passive['max_nodal_residual_mw'],
        'max_dc_equation_residual_mw':passive['max_dc_equation_residual_mw'],
        'max_line_limit_violation_mw':passive['max_line_limit_violation_mw']},args)
    print('IEEE30 DC-OPF + cooling-water run')
    print(f'action={args.action}, mode={args.mode}, T={args.duration_s}s, step={args.step_s}s, alpha={args.alpha:g}, rho={args.rho:g}')
    print(f'network: {GRID.nb} buses, {GRID.ng} generators, {GRID.nl} branches')
    print(f'PA ENS={passive["ens_mwh"]:.9f} MWh, SP ENS={result.get("static",{}).get("ens",float("nan")) if result.get("static") else float("nan"):.9f} MWh, DP ENS={result.get("dynamic",{}).get("ens",float("nan")) if result.get("dynamic") else float("nan"):.9f} MWh')
    if DC_CHECKS:
        print(f'DC solves checked={len(DC_CHECKS)}; max nodal residual={max(x["nodal"] for x in DC_CHECKS):.3e} MW; max DC residual={max(x["dc"] for x in DC_CHECKS):.3e} MW; max line violation={max(x["line"] for x in DC_CHECKS):.3e} MW')
    print('Saved:',ROOT/'结果'/'IEEE30_DCOPF'/'ieee30_selected_run.json')

if __name__=='__main__':main()
