#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""IEEE30 DC-OPF smoke test; does not modify the manuscript or existing simulation.

Runs two single-snapshot LP checks against MATPOWER case30.m:
  1) intact network: nodal DC balance and branch limits, minimize linearized generation cost;
  2) bus-2 generator unavailable: same constraints, expensive load shedding permitted.

This is a verification prototype for the power-network constraint block only. It is
not yet coupled to the cold-end dynamics or PA/SP/DP replay.
"""
from __future__ import annotations
import re
from pathlib import Path
import numpy as np
from scipy.optimize import linprog

ROOT = Path(__file__).resolve().parents[2]
CASE = ROOT / 'data' / 'IEEE30' / 'case30.m'
TOL = 1e-7


def read_matpower_case(path=CASE):
    text = Path(path).read_text(encoding='utf-8')
    def get(name):
        m = re.search(r'mpc\.' + name + r'\s*=\s*\[(.*?)\];', text, re.S)
        if not m:
            raise ValueError(f'missing MATPOWER matrix {name}')
        rows=[]
        for raw in m.group(1).splitlines():
            line=raw.split('%',1)[0].strip().rstrip(';').strip()
            if line:
                rows.append([float(x) for x in line.split()])
        return np.asarray(rows, dtype=float)
    return get('bus'), get('gen'), get('branch'), get('gencost'), float(
        re.search(r'mpc\.baseMVA\s*=\s*([\d.eE+-]+)', text).group(1))


def solve_dc_opf(bus, gen, branch, gencost, base_mva, unavailable_bus=None):
    """LP in [Pg, load shed, theta, branch flow], all P/f in MW, angles in rad."""
    nb, ng, nl = len(bus), len(gen), len(branch)
    bus_ids = bus[:,0].astype(int)
    index = {b:i for i,b in enumerate(bus_ids)}
    pd = bus[:,2].copy()
    pg_bus = np.array([index[int(b)] for b in gen[:,0]], dtype=int)
    fbus = np.array([index[int(b)] for b in branch[:,0]], dtype=int)
    tbus = np.array([index[int(b)] for b in branch[:,1]], dtype=int)
    x = branch[:,3]
    status = branch[:,10] != 0
    if np.any(np.abs(x[status]) < 1e-12):
        raise ValueError('active branch has zero reactance')
    tap = branch[:,8].copy(); tap[tap == 0] = 1.0
    shift = np.deg2rad(branch[:,9])
    rate = branch[:,5].copy()
    # MATPOWER uses 0 for unspecified thermal limits; no zero-limit line is
    # present in this case, but fail closed if the input later changes.
    if np.any(rate[status] <= 0):
        raise ValueError('active branch has missing/nonpositive rateA')
    susceptance = base_mva / (x * tap)

    # variable blocks: Pg(ng), shed(nb), theta(nb), f(nl)
    off_pg=0; off_s=ng; off_th=ng+nb; off_f=ng+2*nb
    nvar=ng+2*nb+nl
    c=np.zeros(nvar)
    # Local linear marginal generation-cost approximation at the source dispatch.
    # MATPOWER polynomial coefficients are [startup, shutdown, n, c2, c1, c0].
    if np.any(gencost[:,0] != 2) or np.any(gencost[:,3] != 3):
        raise ValueError('prototype expects quadratic MATPOWER gencost records')
    p0=gen[:,1]
    marginal=2*gencost[:,4]*p0+gencost[:,5]
    c[off_pg:off_pg+ng]=marginal
    c[off_s:off_s+nb]=1.0e5  # VOLL, deliberately dominates marginal generation cost

    bounds=[]
    for i in range(ng):
        lo=max(0.0,gen[i,9]); hi=gen[i,8]
        if unavailable_bus is not None and int(gen[i,0]) == unavailable_bus:
            hi=0.0
        bounds.append((lo,hi))
    bounds += [(0.0,float(pd[i])) for i in range(nb)]
    bounds += [(0.0,0.0) if int(bus[i,1])==3 else (-np.pi,np.pi) for i in range(nb)]
    bounds += [(-float(rate[k]),float(rate[k])) if status[k] else (0.0,0.0) for k in range(nl)]

    # Nodal conservation: generation - served load = net outgoing flow.
    Aeq=[]; beq=[]
    for n in range(nb):
        row=np.zeros(nvar)
        row[off_pg:off_pg+ng][pg_bus==n]=1.0
        row[off_s+n]=1.0  # Pg - (Pd - shed) = netflow -> Pg + shed - netflow = Pd
        row[off_f:off_f+nl] -= (fbus==n).astype(float)
        row[off_f:off_f+nl] += (tbus==n).astype(float)
        Aeq.append(row); beq.append(pd[n])
    # DC branch constitutive equations: f = b*(theta_from-theta_to-shift).
    for k in range(nl):
        row=np.zeros(nvar); row[off_f+k]=1.0
        if status[k]:
            row[off_th+fbus[k]] -= susceptance[k]
            row[off_th+tbus[k]] += susceptance[k]
            rhs=-susceptance[k]*shift[k]
        else:
            rhs=0.0
        Aeq.append(row); beq.append(rhs)

    res=linprog(c,A_eq=np.asarray(Aeq),b_eq=np.asarray(beq),bounds=bounds,method='highs')
    if not res.success:
        raise RuntimeError(f'DC-OPF failed ({res.status}): {res.message}')
    z=res.x
    pg=z[off_pg:off_pg+ng]; shed=z[off_s:off_s+nb]
    theta=z[off_th:off_th+nb]; flow=z[off_f:off_f+nl]
    # independent physical residuals
    nodal=np.zeros(nb)
    np.add.at(nodal,pg_bus,pg)
    nodal -= pd-shed
    np.add.at(nodal,fbus,-flow); np.add.at(nodal,tbus,flow)
    flow_calc=np.where(status,susceptance*(theta[fbus]-theta[tbus]-shift),0.0)
    line_res=float(np.max(np.abs(flow-flow_calc)))
    balance_res=float(np.max(np.abs(nodal)))
    limit_violation=float(max(0.0,np.max(np.abs(flow[status])-rate[status])))
    if balance_res>TOL or line_res>TOL or limit_violation>TOL:
        raise AssertionError(f'validation residuals: nodal={balance_res:g}, DC={line_res:g}, limits={limit_violation:g}')
    return {'pg':pg,'shed':shed,'theta':theta,'flow':flow,'line_limit':rate,
            'bus_ids':bus_ids,'gen_bus':gen[:,0].astype(int),'branch_from':branch[:,0].astype(int),
            'branch_to':branch[:,1].astype(int),'status':status,'total_load':float(pd.sum()),
            'served_load':float((pd-shed).sum()),'shed_mw':float(shed.sum()),
            'max_abs_flow_mw':float(np.max(np.abs(flow[status]))),
            'max_line_utilization':float(np.max(np.abs(flow[status])/rate[status])),
            'max_nodal_residual_mw':balance_res,'max_dc_equation_residual_mw':line_res,
            'max_line_limit_violation_mw':limit_violation,'objective':float(res.fun)}


def main():
    bus,gen,branch,gencost,base=read_matpower_case()
    assert (len(bus),len(gen),len(branch),len(gencost))==(30,6,41,6)
    base_load=float(bus[:,2].sum())
    intact=solve_dc_opf(bus,gen,branch,gencost,base)
    outage=solve_dc_opf(bus,gen,branch,gencost,base,unavailable_bus=2)
    print('IEEE30 DC-OPF smoke test (single snapshot; no cold-end coupling)')
    print(f'case shape: buses={len(bus)}, generators={len(gen)}, branches={len(branch)}, baseMVA={base:g}')
    print(f'total load: {base_load:.3f} MW')
    for label,r in [('intact',intact),('bus-2 generator unavailable',outage)]:
        print(f'[{label}] served={r["served_load"]:.6f} MW; shed={r["shed_mw"]:.6f} MW; '
              f'max |flow|={r["max_abs_flow_mw"]:.6f} MW; '
              f'max line utilization={r["max_line_utilization"]:.6%}')
        print(f'  checks: max nodal residual={r["max_nodal_residual_mw"]:.3e} MW; '
              f'max DC equation residual={r["max_dc_equation_residual_mw"]:.3e} MW; '
              f'line-limit violation={r["max_line_limit_violation_mw"]:.3e} MW')
        print('  Pg by generator bus (MW):', ', '.join(f'{b}:{p:.3f}' for b,p in zip(r['gen_bus'],r['pg'])))
    if intact['shed_mw']>1e-5:
        raise AssertionError('intact case unexpectedly sheds load')
    print('PASS: DC nodal balance, branch equations, and thermal limits verified.')
    print('NOTE: this is a DC-OPF prototype check only; PA/SP/DP and cooling-water results remain unchanged.')

if __name__=='__main__':
    main()
