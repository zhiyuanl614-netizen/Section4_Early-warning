#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared discrete alpha/rho Pareto selection and workbook/plot utilities.

Each case's main simulation script provides a scenario proxy and sets the case
label/output directory before calling these functions.
"""
from __future__ import annotations
import importlib.util
import math
from pathlib import Path
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parents[2]
MODEL_SCRIPT = ROOT / '脚本' / 'IEEE30' / 'IEEE30_主程序.py'
OUT_DIR = ROOT / '结果' / 'IEEE30'
CASE_LABEL = 'IEEE30'
ALPHA_GRID = [0.04, 0.12, 0.20, 0.28, 0.36]
RHO_GRID = [0.001, 0.01, 0.1, 0.2, 0.3, 0.35, 0.375, 0.4, 0.425, 0.45, 0.5, 0.6, 1.0, 2.0]
T = 18000
STEP_S = 60
REPLAN_S = 60


def load_model():
    spec = importlib.util.spec_from_file_location('ieee30_cooling_dispatch', MODEL_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'无法加载模型脚本: {MODEL_SCRIPT}')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def chord_distances(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if len(x) < 2:
        return np.zeros(len(x))
    a = np.array([x[0], y[0]])
    b = np.array([x[-1], y[-1]])
    d = b - a
    norm = np.linalg.norm(d)
    if norm <= 1e-15:
        return np.zeros(len(x))
    return np.abs(d[0] * (a[1] - y) - (a[0] - x) * d[1]) / norm


def pareto_mask(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    out = []
    for i in range(len(x)):
        dominated = any(
            j != i and x[j] <= x[i] + 1e-12 and y[j] <= y[i] + 1e-12
            and (x[j] < x[i] - 1e-12 or y[j] < y[i] - 1e-12)
            for j in range(len(x))
        )
        out.append(not dominated)
    return np.asarray(out, dtype=bool)


def normalize(v):
    v = np.asarray(v, dtype=float)
    span = float(v.max() - v.min()) if len(v) else 0.0
    return (v - v.min()) / span if span > 1e-12 else np.zeros_like(v)


def run_case(mod, alpha, rho):
    return mod.scenario(
        'ieee30', T=T, step=STEP_S, replan=REPLAN_S, mode='both',
        generator_cost_ratio=float(rho), warning_alpha=float(alpha)
    )


def select(mod):
    # Stage 1: alpha candidates are usable-water fractions, not water levels.
    alpha_rows = []
    for alpha in ALPHA_GRID:
        result = run_case(mod, alpha, 0.0)
        static, dynamic = result['static'], result['dynamic']
        alpha_rows.append({
            'alpha': float(alpha), 'warning_volume_m3': float(result['warning']),
            'aet_s': float(result['aet']), 'static_ens': float(static['ens']),
            'dynamic_ens': float(dynamic['ens']),
            'mean_active_ens': (static['ens'] + dynamic['ens']) / 2,
            'max_active_peak': max(static['peak'], dynamic['peak']),
            'alarm_s': result['alarm'], 'deadline_s': result['deadline'],
        })
    x = normalize([r['aet_s'] for r in alpha_rows])
    y = normalize([r['mean_active_ens'] for r in alpha_rows])
    distance = chord_distances(x, y)
    alpha_index = int(np.argmax(distance))
    selected_alpha = alpha_rows[alpha_index]['alpha']
    for i, row in enumerate(alpha_rows):
        row.update(norm_aet=float(x[i]), norm_ens=float(y[i]),
                   chord_distance=float(distance[i]), selected=(i == alpha_index))

    # Stage 2: fix selected alpha; record all rho cases, but select only over
    # the declared 0 < rho <= 0.5 decision range.
    rho_rows = []
    for rho in RHO_GRID:
        result = run_case(mod, selected_alpha, rho)
        static, dynamic = result['static'], result['dynamic']
        ens = float((static['ens'] + dynamic['ens']) / 2)
        cost_index = float((static['generation_cost'] + dynamic['generation_cost']) / (2 * rho))
        rho_rows.append({
            'rho': float(rho), 'mean_active_ens': ens,
            'unweighted_cost_index': cost_index,
            'max_active_peak': max(static['peak'], dynamic['peak']),
            'static_ens': float(static['ens']), 'dynamic_ens': float(dynamic['ens']),
            'static_peak': float(static['peak']), 'dynamic_peak': float(dynamic['peak']),
            'alarm_s': result['alarm'], 'aet_s': result['aet'],
            'deadline_s': result['deadline'],
            'replans': sum(1 for u in result['updates'] if u[1] == '重规划'),
            'failures': sum(1 for u in result['updates'] if u[1] == '无候选，保留原计划'),
        })
    eligible = [r for r in rho_rows if 0 < r['rho'] <= 0.5]
    ex = np.asarray([r['mean_active_ens'] for r in eligible], dtype=float)
    ey = np.asarray([r['unweighted_cost_index'] for r in eligible], dtype=float)
    mask = pareto_mask(ex, ey)
    front = [r for r, keep in zip(eligible, mask) if keep]
    front.sort(key=lambda r: (r['mean_active_ens'], r['unweighted_cost_index'], r['rho']))
    fx = normalize([r['mean_active_ens'] for r in front])
    fy = normalize([-r['unweighted_cost_index'] for r in front])
    fdist = chord_distances(fx, fy)
    if not front:
        raise RuntimeError('ρ选择区间内没有Pareto点')
    best = float(np.max(fdist))
    tied = [i for i, d in enumerate(fdist) if abs(float(d) - best) <= 1e-12]
    selected_index = min(tied, key=lambda i: front[i]['rho'])
    selected_rho = float(front[selected_index]['rho'])
    for i, row in enumerate(front):
        row.update(norm_ens=float(fx[i]), norm_cost_improvement=float(fy[i]),
                   chord_distance=float(fdist[i]))
    front_by_rho = {r['rho']: r for r in front}
    for row in rho_rows:
        row['eligible'] = 0 < row['rho'] <= 0.5
        row['pareto_nondominated'] = row['rho'] in front_by_rho
        row['norm_ens'] = front_by_rho.get(row['rho'], {}).get('norm_ens')
        row['norm_cost_improvement'] = front_by_rho.get(row['rho'], {}).get('norm_cost_improvement')
        row['chord_distance'] = front_by_rho.get(row['rho'], {}).get('chord_distance')
        row['selected'] = abs(row['rho'] - selected_rho) < 1e-12
    return alpha_rows, rho_rows, front, selected_alpha, selected_rho


def add_table(ws, headers, rows):
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(bold=True, color='FFFFFF')
        c.fill = PatternFill('solid', fgColor='4472C4')
        c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    for row in rows:
        ws.append(row)
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions
    for col in range(1, len(headers) + 1):
        max_len = max(len(str(ws.cell(row, col).value or '')) for row in range(1, ws.max_row + 1))
        ws.column_dimensions[get_column_letter(col)].width = min(34, max(14, max_len + 2))
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical='center', wrap_text=True)


def write_workbook(path, alpha_rows, rho_rows, front, selected_alpha, selected_rho):
    wb = Workbook()
    summary = wb.active
    summary.title = '顺序选参摘要'
    summary.merge_cells('A1:F1')
    summary['A1'] = f'{CASE_LABEL}｜α优先、ρ条件选择｜批量复算'
    summary['A1'].font = Font(name='微软雅黑', size=14, bold=True, color='FFFFFF')
    summary['A1'].fill = PatternFill('solid', fgColor='17365D')
    summary['A1'].alignment = Alignment(horizontal='center')
    selected_alpha_row = next(r for r in alpha_rows if r['selected'])
    selected_rho_row = next(r for r in rho_rows if r['selected'])
    rows = [
        ('阶段1固定参数', 'rho=0; AET负担代理 vs 静态/动态平均ENS'),
        ('选定α', f"{selected_alpha:.3f}"),
        ('选定α的预警水量', f"{selected_alpha_row['warning_volume_m3']:.3f} m³"),
        ('阶段1弦距', f"{selected_alpha_row['chord_distance']:.6f}"),
        ('阶段2固定参数', f"alpha={selected_alpha:.3f}; 扫描rho并比较平均ENS与未加权成本指数"),
        ('条件ρ', f"{selected_rho:.3f}"),
        ('ρ点平均主动ENS', f"{selected_rho_row['mean_active_ens']:.6f} MWh"),
        ('ρ点未加权成本指数', f"{selected_rho_row['unweighted_cost_index']:.6f}"),
        ('阶段2弦距', f"{selected_rho_row['chord_distance']:.6f}"),
        ('仿真设置', f'T={T} s; LP步长={STEP_S} s; 动态重规划={REPLAN_S} s'),
        ('方法限制', '候选网格上的离散Pareto折中，不是连续全局最优或现场成本最优。'),
    ]
    for i, (key, value) in enumerate(rows, 3):
        summary.cell(i, 1, key).font = Font(bold=True, color='17365D')
        summary.cell(i, 2, value)
        summary.merge_cells(start_row=i, start_column=2, end_row=i, end_column=6)
        summary.cell(i, 2).alignment = Alignment(wrap_text=True, vertical='top')
    summary.column_dimensions['A'].width = 26
    for col in range(2, 7):
        summary.column_dimensions[get_column_letter(col)].width = 18

    ws = wb.create_sheet('阶段1 α候选')
    headers = ['α', '预警水量(m³)', 'AET(s)', '静态ENS(MWh)', '动态ENS(MWh)',
               '平均主动ENS(MWh)', '最大主动峰值缺供(MW)', '归一AET', '归一ENS', '端点弦距', '选中']
    add_table(ws, headers, [[r['alpha'], r['warning_volume_m3'], r['aet_s'], r['static_ens'],
                             r['dynamic_ens'], r['mean_active_ens'], r['max_active_peak'],
                             r['norm_aet'], r['norm_ens'], r['chord_distance'], '是' if r['selected'] else '']
                            for r in alpha_rows])

    ws = wb.create_sheet('阶段2 ρ候选')
    headers = ['ρ', '平均主动ENS(MWh)', '未加权机组成本指数均值', '最大主动峰值缺供(MW)',
               '静态ENS', '动态ENS', '静态峰值', '动态峰值', '纳入0<ρ≤0.5',
               'Pareto非支配', '归一ENS', '归一成本改善', '端点弦距', '动态重规划成功', '失败回退', '选中']
    add_table(ws, headers, [[r['rho'], r['mean_active_ens'], r['unweighted_cost_index'],
                             r['max_active_peak'], r['static_ens'], r['dynamic_ens'],
                             r['static_peak'], r['dynamic_peak'], '是' if r['eligible'] else '',
                             '是' if r['pareto_nondominated'] else '', r['norm_ens'],
                             r['norm_cost_improvement'], r['chord_distance'], r['replans'],
                             r['failures'], '是' if r['selected'] else ''] for r in rho_rows])

    ws = wb.create_sheet('ρ非支配前沿')
    headers = ['ρ', '平均主动ENS(MWh)', '未加权成本指数均值', '归一ENS',
               '归一成本改善', '弦距', '选中']
    add_table(ws, headers, [[r['rho'], r['mean_active_ens'], r['unweighted_cost_index'],
                             r['norm_ens'], r['norm_cost_improvement'], r['chord_distance'],
                             '是' if abs(r['rho'] - selected_rho) < 1e-12 else ''] for r in front])

    ws = wb.create_sheet('方法与边界')
    notes = [
        ('顺序', '阶段1固定rho=0选α；阶段2固定所选α后再选条件ρ。'),
        ('α定义', 'α=(Vwarn−Vprotect)/(Vnormal−Vprotect)；预警由水量阈值触发。'),
        ('阶段1', 'AET估计提前量作为负担代理，与静态/动态主动ENS均值折中；五点共同min-max归一化，取到端点弦最大垂距的候选。'),
        ('ρ网格', ', '.join(map(str, [0.0] + RHO_GRID))),
        ('阶段2', '最小化平均主动ENS和未加权归一机组成本指数；仅在0<rho<=0.5的非支配点上归一化并按端点弦最大距离选取。'),
        ('成本代理', 'IEEE30 MATPOWER case30.m的二次gencost在初始P0处线性化；MC_i=2*c2_i*P0_i+c1_i，除以max(MC)归一化。rho缩放机组成本相对缺供ENS的权重。'),
        ('ρ范围解释', 'rho>=1仅为压力情景；rho候选不代表文献给出的唯一推荐权重。'),
        ('仿真设置', f'T={T}s，LP节点{STEP_S}s，动态重规划{REPLAN_S}s；正常/预警/保护池水位模型参数来自IEEE30研究设定。'),
        ('结论限制', '离散网格Pareto候选；AET是估计量；目标为归一指数，不代表货币成本，也不构成实机安全认证。'),
    ]
    add_table(ws, ['项目', '说明'], notes)
    wb.save(path)


def write_plot(path, alpha_rows, rho_rows, front, selected_alpha, selected_rho):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    ax = axes[0]
    x = [r['norm_aet'] for r in alpha_rows]
    y = [r['norm_ens'] for r in alpha_rows]
    ax.plot(x, y, '-o', color='#2F5597')
    for r in alpha_rows:
        ax.annotate(f"α={r['alpha']:.2f}", (r['norm_aet'], r['norm_ens']), xytext=(4, 5), textcoords='offset points', fontsize=8)
    chosen = next(r for r in alpha_rows if r['selected'])
    ax.scatter([chosen['norm_aet']], [chosen['norm_ens']], s=110, facecolors='none', edgecolors='#C00000', linewidths=1.8)
    ax.set_title('Stage 1: select alpha at rho=0')
    ax.set_xlabel('Normalized AET burden (lower is better)')
    ax.set_ylabel('Normalized mean ENS (lower is better)')
    ax.grid(alpha=.25)

    ax = axes[1]
    ax.plot([r['norm_ens'] for r in front], [r['norm_cost_improvement'] for r in front], '-o', color='#548235')
    for r in front:
        ax.annotate(f"ρ={r['rho']:.3g}", (r['norm_ens'], r['norm_cost_improvement']), xytext=(4, 5), textcoords='offset points', fontsize=7)
    chosen_rho_row = next(r for r in rho_rows if r['selected'])
    ax.scatter([chosen_rho_row['norm_ens']], [chosen_rho_row['norm_cost_improvement']], s=110, facecolors='none', edgecolors='#C00000', linewidths=1.8)
    ax.set_title(f'Stage 2: select rho at alpha={selected_alpha:.2f}')
    ax.set_xlabel('Normalized mean ENS (lower is better)')
    ax.set_ylabel('Normalized cost improvement (higher is better)')
    ax.grid(alpha=.25)
    fig.suptitle(f'{CASE_LABEL} two-stage Pareto: alpha={selected_alpha:.2f}, rho={selected_rho:.3f}')
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches='tight')
    plt.close(fig)


def main():
    mod = load_model()
    alpha_rows, rho_rows, front, selected_alpha, selected_rho = select(mod)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    xlsx = OUT_DIR / 'IEEE30_两阶段Pareto自动复算.xlsx'
    png = OUT_DIR / 'IEEE30_两阶段Pareto自动复算.png'
    write_workbook(xlsx, alpha_rows, rho_rows, front, selected_alpha, selected_rho)
    write_plot(png, alpha_rows, rho_rows, front, selected_alpha, selected_rho)
    ar = next(r for r in alpha_rows if r['selected'])
    rr = next(r for r in rho_rows if r['selected'])
    print('IEEE30 two-stage Pareto batch selection')
    print(f'alpha grid: {ALPHA_GRID}')
    print(f'selected alpha={selected_alpha:.3f}, Vwarn={ar["warning_volume_m3"]:.3f} m3, AET={ar["aet_s"]:.3f}s, mean active ENS={ar["mean_active_ens"]:.6f}MWh, chord={ar["chord_distance"]:.6f}')
    print(f'rho grid: {RHO_GRID}')
    print(f'selected conditional rho={selected_rho:.3f}, mean active ENS={rr["mean_active_ens"]:.6f}MWh, unweighted cost index={rr["unweighted_cost_index"]:.6f}, chord={rr["chord_distance"]:.6f}')
    print('Saved:', xlsx)
    print('Saved:', png)


if __name__ == '__main__':
    main()
