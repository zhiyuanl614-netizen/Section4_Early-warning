#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Figure 6: paired PA/SP/DP outcomes for IEEE30 and Shelby County.
The primary outcome rows are instantaneous unserved power and cumulative ENS;
unit output and aggregate generation/demand retain the dispatch-to-service context.
"""
from __future__ import annotations
import csv
import importlib.util
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib import font_manager
from svg_font_utils import enforce_times_new_roman

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / '脚本'
OUT_CSV = ROOT / '结果' / 'Fig6' / 'Fig6_策略对比时序.csv'
OUT_PNG = ROOT / 'Fig6_PA_SP_DP_Case_Comparison.png'
OUT_SVG = ROOT / 'Fig6_PA_SP_DP_Case_Comparison.svg'

# Reconfirmed by the updated discrete Pareto scans (not transferred across cases).
CASES = [
    dict(label='IEEE30', module='ieee', T=18000, alpha=0.12, rho=0.425),
    dict(label='Shelby County', module='shelby', T=22000, alpha=0.12, rho=0.300),
]
STEP_S = 60
REPLAN_S = 60
STRATEGIES = [('passive', 'PA', '#596579'), ('static', 'SP', '#D17835'), ('dynamic', 'DP', '#2D70A8')]


def load_script_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Cannot import {path}')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def run_case(spec):
    if spec['module'] == 'ieee':
        mod = load_script_module('fig5_ieee_model', SCRIPTS / 'IEEE30_冷却水仿真.py')
        result = mod.scenario('ieee30', T=spec['T'], step=STEP_S, replan=REPLAN_S,
                              mode='both', warning_alpha=spec['alpha'],
                              generator_cost_ratio=spec['rho'], include_trajectory=True)
    else:
        wrap = load_script_module('fig5_shelby_wrapper', SCRIPTS / 'Shelby_冷却水仿真.py')
        mod = wrap.load_model_module()
        mod, buses, generators, load_mw, raw_generation, scale, p0, pmax, normalized_mc, affected = wrap.build_test(mod)
        result = mod.scenario('Shelby59_aggregate', T=spec['T'], step=STEP_S,
                              replan=REPLAN_S, mode='both', warning_alpha=spec['alpha'],
                              generator_cost_ratio=spec['rho'], include_trajectory=True)
        result['shelby_load_mw'] = float(load_mw)
    if result.get('alarm') is None:
        raise RuntimeError(f"{spec['label']}: no valid warning alarm; cannot construct paired Fig. 5")
    for key, label, _ in STRATEGIES:
        if result.get(key) is None or 'trajectory' not in result[key]:
            raise RuntimeError(f"{spec['label']} {label}: trajectory export missing")
    return result


def export_csv(runs):
    OUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    fields = ['case', 'strategy', 'time_from_outage_s', 'time_after_warning_min',
              'affected_output_mw', 'healthy_fleet_output_mw', 'total_generation_mw',
              'demand_mw', 'load_shed_mw', 'cumulative_ens_mwh',
              'water_volume_m3', 'water_level_m', 'usable_water_fraction',
              'warning_alpha', 'warning_volume_m3', 'protection_volume_m3',
              'Pmin_mw', 'trip_or_stop_s', 'stop_reason']
    with OUT_CSV.open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for spec, res in runs:
            alarm = int(res['alarm'])
            v0, vmin, warn = float(res['v0']), float(res['vmin']), float(res['warning'])
            for key, label, _ in STRATEGIES:
                item = res[key]
                tr = item['trajectory']
                pmat = np.asarray(tr['p_all_mw'], dtype=float)
                pf_idx = int(tr['affected_index'])
                demand = float(tr['demand_mw'])
                shed = np.asarray(tr['load_shed_mw'], dtype=float)
                # One-second outcome grid: cumulative ENS is the running sum of
                # positive unmet MW over each one-second interval.
                cum_ens = np.r_[0.0, np.cumsum(np.maximum(shed, 0.0)) / 3600.0]
                ptime = np.asarray(tr['power_time_s'], dtype=int)
                wt = np.asarray(tr['time_s'], dtype=int)
                wv = np.asarray(tr['water_m3'], dtype=float)
                wl = np.asarray(tr['water_level_m'], dtype=float)
                water_by_t = {int(t): (float(v), float(h)) for t, v, h in zip(wt, wv, wl)}
                trip_or_stop = item.get('trip')
                for j, t in enumerate(ptime):
                    if t < alarm:
                        continue
                    row = {k: '' for k in fields}
                    total = float(np.sum(pmat[j]))
                    affected = float(pmat[j, pf_idx])
                    other = total - affected
                    row.update(case=spec['label'], strategy=label,
                               time_from_outage_s=int(t), time_after_warning_min=(int(t)-alarm)/60.0,
                               affected_output_mw=affected, healthy_fleet_output_mw=other,
                               total_generation_mw=total, demand_mw=demand,
                               load_shed_mw=float(shed[j]) if j < len(shed) else '',
                               cumulative_ens_mwh=max(0.0, float(cum_ens[min(int(t), len(shed))] - cum_ens[min(alarm, len(shed))])),
                               warning_alpha=spec['alpha'], warning_volume_m3=warn,
                               protection_volume_m3=vmin, Pmin_mw=tr['pmin_mw'],
                               trip_or_stop_s=trip_or_stop if trip_or_stop is not None else '',
                               stop_reason=item.get('reason', ''))
                    if int(t) in water_by_t:
                        vol, level = water_by_t[int(t)]
                        row['water_volume_m3'] = vol
                        row['water_level_m'] = level
                        row['usable_water_fraction'] = (vol-vmin)/(v0-vmin) if v0 > vmin else ''
                    w.writerow(row)


def make_figure(runs):
    """Outcome-first redesign: dispatch context above, headline metrics below."""
    # The SVG is normalized to declare Times New Roman; local PNG rendering uses
    # DejaVu Serif because the proprietary Times face is not bundled here.
    FIG_FONT='Times New Roman'
    plt.rcParams.update({
        'font.family':FIG_FONT,'font.serif':[FIG_FONT],
        'mathtext.fontset':'stix','font.size':8.5,
        'axes.titlesize':8.8,'axes.labelsize':8.3,
        'xtick.labelsize':7.4,'ytick.labelsize':7.8,
        'legend.fontsize':7.2,'axes.spines.top':False,
        'axes.spines.right':False,'svg.fonttype':'none',
        'axes.linewidth':.8,
    })
    # The visual hierarchy is intentionally different from the previous
    # 4×2 line-small-multiples: two rows retain temporal mechanism context;
    # two rows use horizontal strategy-comparison charts for peak MW and ENS.
    fig=plt.figure(figsize=(9.1,7.75),facecolor='white')
    gs=fig.add_gridspec(4,2,height_ratios=[1.15,1.10,.78,.78],
                        left=.105,right=.985,top=.855,bottom=.105,
                        hspace=.58,wspace=.27)
    axs=np.array([[fig.add_subplot(gs[r,c]) for c in range(2)] for r in range(4)])
    colors={key:color for key,label,color in STRATEGIES}
    strategy_names={key:label for key,label,color in STRATEGIES}
    # Use a common x-scale across case columns within each metric row so
    # horizontal bar lengths remain comparable between IEEE30 and Shelby.
    metric_scale={metric:max(float(res[k][metric]) for _,res in runs for k,_,_ in STRATEGIES)
                  for metric in ('peak','ens')}

    def value_label(v):
        return '<0.000001' if float(v)<1e-6 else f'{float(v):.2f}'

    for col,(spec,res) in enumerate(runs):
        case_name='IEEE30' if spec['module']=='ieee' else 'Shelby County'
        panel_letter='a' if col==0 else 'b'
        alarm=int(res['alarm'])
        affected_panel,fleet_panel,peak_panel,ens_panel=axs[:,col]
        # No plot titles: retain only panel IDs; case names are column headers.
        for row,ax in enumerate((affected_panel,fleet_panel,peak_panel,ens_panel),1):
            ax.text(0.0,1.018,f'({panel_letter}{row})',transform=ax.transAxes,
                    ha='left',va='bottom',fontsize=8.4,fontweight='bold',clip_on=False)

        passive_tr=res['passive']['trajectory']
        pmat0=np.asarray(passive_tr['p_all_mw'],dtype=float)
        fidx0=int(passive_tr['affected_index'])
        p0=float(pmat0[0,fidx0])
        pmin_ratio=float(passive_tr['pmin_mw'])/p0
        demand_mw=float(res['shelby_load_mw']) if spec['module']=='shelby' else float(passive_tr['demand_mw'])

        # Mechanism context: affected-unit trajectory and aggregate balance.
        for key,label,color in STRATEGIES:
            item=res[key]
            tr=item['trajectory']
            x=(np.asarray(tr['power_time_s'],dtype=float)-alarm)/60.0
            keep=x>=0
            pmat=np.asarray(tr['p_all_mw'],dtype=float)
            fidx=int(tr['affected_index'])
            pf=pmat[:,fidx]
            total=pmat.sum(axis=1)
            healthy=total-pf
            affected_panel.plot(x[keep],pf[keep]/p0,color=color,lw=1.7,zorder=3)
            fleet_panel.plot(x[keep],total[keep],color=color,lw=1.5,zorder=3)
            fleet_panel.plot(x[keep],healthy[keep],color=color,lw=1.0,ls='--',alpha=.72,zorder=2)

            # Event styles distinguish a physical protective trip from a plan.
            event_s=item.get('trip')
            if event_s is not None and event_s>=alarm:
                event_x=(float(event_s)-alarm)/60.0
                ls=':' if item.get('reason')=='backpressure_protection' else (0,(3,2))
                for ax in (affected_panel,fleet_panel):
                    ax.axvline(event_x,color=color,lw=.9,ls=ls,alpha=.78,zorder=1)

        affected_panel.axhline(pmin_ratio,color='#303944',lw=1.0,ls=':',zorder=1)
        fleet_panel.axhline(demand_mw,color='#222222',lw=1.15,ls=(0,(4,2)),zorder=1)
        affected_panel.set_ylabel(r'$P_F/P_0$')
        fleet_panel.set_ylabel('Power (MW)')
        for ax in (affected_panel,fleet_panel):
            ax.grid(True,color='#E3E8ED',lw=.65)
            ax.set_axisbelow(True)
            ax.set_xlim(0,80)
            ax.set_xticks([0,20,40,60,80])
        affected_panel.set_xlabel('Time after warning (min)',labelpad=2)
        fleet_panel.set_xlabel('Time after warning (min)',labelpad=2)

        # Outcome comparison charts: the bar length gives cross-strategy scale;
        # end labels preserve readable values even when one strategy is tiny.
        y=np.array([2,1,0])
        labels=[strategy_names[k] for k,_,_ in STRATEGIES]
        for ax,metric,unit in (
            (peak_panel,'peak','Peak unserved power (MW)'),
            (ens_panel,'ens','Cumulative ENS (MWh)'),
        ):
            vals=np.array([float(res[k][metric]) for k,_,_ in STRATEGIES])
            maxval=float(vals.max())
            xmax=max(1.0,float(metric_scale[metric])*1.42)
            ax.barh(y,vals,height=.52,
                    color=[colors[k] for k,_,_ in STRATEGIES],
                    edgecolor='white',linewidth=.55,zorder=3)
            for yi,(key,_,color),v in zip(y,STRATEGIES,vals):
                if v<1e-6:
                    ax.scatter([0],[yi],s=15,marker='o',color=color,
                               edgecolors='white',linewidths=.45,zorder=4)
                offset=max(maxval*.012, xmax*.006, .008)
                ax.text(float(v)+offset,float(yi),value_label(v),
                        ha='left',va='center',fontsize=7.6,color='#26313D',
                        fontweight='bold',clip_on=False,zorder=5)
            ax.set_yticks(y,labels)
            for tick,(_,_,color) in zip(ax.get_yticklabels(),STRATEGIES):
                tick.set_color(color)
                tick.set_fontweight('bold')
            ax.set_xlim(0,xmax)
            ax.set_xlabel(unit,labelpad=2)
            ax.grid(axis='x',color='#E3E8ED',lw=.65)
            ax.set_axisbelow(True)
            ax.spines['left'].set_visible(False)
            ax.tick_params(axis='y',length=0,pad=5)

        # Legends live inside the relevant subplots, repeated consistently by case.
        strategy_handles=[Line2D([0],[0],color=c,lw=1.8,label=label)
                          for _,label,c in STRATEGIES]
        style_handles=[
            Line2D([0],[0],color='#303944',lw=1.35,ls='-',label='Total generation'),
            Line2D([0],[0],color='#303944',lw=1.1,ls='--',label='Healthy fleet output'),
            Line2D([0],[0],color='#222222',lw=1.1,ls=(0,(4,2)),label='Demand'),
        ]
        affected_panel.legend(handles=strategy_handles,loc='lower left',ncol=1,
                              frameon=False,borderpad=.15,labelspacing=.25,handlelength=1.5,fontsize=6.8)
        affected_panel.text(.98,pmin_ratio,r'$P_{min}/P_0$',
                            transform=affected_panel.get_yaxis_transform(),
                            ha='right',va='bottom',fontsize=6.4,color='#303944')
        fleet_panel.legend(handles=style_handles,loc='lower right',ncol=1,
                           frameon=False,borderpad=.12,labelspacing=.18,handlelength=1.25,fontsize=5.8)

    # Case names identify columns but are not a figure title.
    fig.canvas.draw()
    for col,(spec,_) in enumerate(runs):
        ax=axs[0,col]
        pos=ax.get_position()
        case_name='IEEE30' if spec['module']=='ieee' else 'Shelby County'
        fig.text((pos.x0+pos.x1)/2,pos.y1+.025,case_name,ha='center',va='bottom',
                 fontsize=9.0,fontweight='bold',family=FIG_FONT)
    fig.text(.5,.018,
             'Peak and ENS values summarize modelled aggregate power balance; they are not network-security results.',
             ha='center',va='bottom',fontsize=7.1,color='#596579')
    fig.savefig(OUT_PNG,dpi=360,bbox_inches='tight',facecolor='white')
    fig.savefig(OUT_SVG,bbox_inches='tight',facecolor='white')
    enforce_times_new_roman(OUT_SVG)
    plt.close(fig)


def main():
    runs = [(spec, run_case(spec)) for spec in CASES]
    export_csv(runs)
    make_figure(runs)
    for spec, result in runs:
        print(spec['label'], 'alpha=', spec['alpha'], 'rho=', spec['rho'],
              'alarm_s=', result['alarm'])
        for key, label, _ in STRATEGIES:
            x=result[key]
            print(f"  {label}: ENS={x['ens']:.6f} MWh; peak={x['peak']:.6f} MW; "
                  f"trip/stop={x['trip']}; reason={x['reason']}; min_water={x['min_water']:.3f} m3; "
                  f"Pmin_low_steps={x['low_pmin']}")
    print('Wrote', OUT_PNG)
    print('Wrote', OUT_SVG)
    print('Wrote', OUT_CSV)

if __name__ == '__main__':
    main()
