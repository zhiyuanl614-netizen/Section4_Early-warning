#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shelby cooling-water interruption warning/dispatch with an 8-unit aggregate wrapper.

The cold-end physics and dispatch logic reuse the same project model as IEEE30.
Shelby County is represented as a project-defined aggregate power-balance case:
the supplied CSV contains no branch model or verified nameplate/ramp/cost curves.
This wrapper configures its case inputs and explicit model mappings separately.
"""
import importlib.util
from pathlib import Path
from types import SimpleNamespace
import math
import numpy as np
import pandas as pd
try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    Workbook = Font = PatternFill = Alignment = Border = Side = get_column_letter = None

ROOT = Path(__file__).resolve().parent.parent
BUS_CSV = ROOT / 'data' / 'Shelby' / 'Power Network Node Shelby Data.csv'
RESULT_DIR = ROOT / '结果' / 'Shelby'
BASE_SCRIPT = ROOT / '脚本' / 'IEEE30_冷却水仿真.py'

# Explicit project assumptions for this aggregate-only case:
# 1) gate-station flow values are preserved as the units' initial output P0;
#    with no bus-load input, aggregate L is set to sum(P0), as in a balanced
#    aggregate generation model. No export proxy is added.
# 2) relative marginal costs are a rank-order mapping of IEEE30's normalized
#    marginal-cost template; these are not verified Shelby unit-specific costs;
# 3) nameplate loading ratio is borrowed from the IEEE30 fleet-average ratio,
#    solely as a test assumption, not Shelby data;
# 4) G2 is the water-limited unit as selected by the user;
# 5) no branches, voltage-flow constraints, or generator-specific site data.
LOAD_SHARING = 'raw_gate_flow_as_P0; L_equals_sum_P0'
RAMP_FRAC_PER_MIN = 0.007  # project assumption; IEEE30 MATPOWER ramp columns are zero
AFFECTED_BUS_CODE = 'G2'
ALPHA = 0.12  # selected from the independently scaled Shelby stage-1 Pareto sweep
RHO = 0.30     # conditional rho selected after fixing Shelby alpha
REPLAN_S = 60
SIM_T = 22000  # Shelby-only extended window to cover all five warning thresholds after basin scaling.


def load_model_module():
    spec = importlib.util.spec_from_file_location('ieee30_cooling_dispatch', BASE_SCRIPT)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def build_test(mod):
    df = pd.read_csv(BUS_CSV)
    if not {'Nodenum', 'type', 'flow'}.issubset(df.columns):
        raise ValueError('输入CSV缺少Nodenum/type/flow必要字段')
    g = df[df['type'].astype(str).str.lower() == 'gate_stations'].copy().sort_values('Nodenum')
    if len(g) != 8:
        raise ValueError(f'期望8个gate_stations（对应G1–G8），实际{len(g)}个')
    g['bus_code'] = g['Nodenum'].astype(int).map(lambda x: f'G{x}')
    p0 = g['flow'].to_numpy(dtype=float)
    system_sink = float(p0.sum())  # no bus-load data used; balanced aggregate demand proxy
    raw_generation = system_sink
    if system_sink <= 0:
        raise ValueError('gate_stations的flow合计必须为正')
    # Preserve gate-station flow as P0 and set aggregate system load L=sum(P0),
    # matching the balanced aggregate model convention. No export proxy.
    # Pmax uses the IEEE30 fleet-average P0/Pmax loading ratio.
    ref_sy = mod.case_data('ieee30', generator_cost_ratio=0.0)[0]
    ref_loading_ratio = float(ref_sy.P0.sum() / ref_sy.PMAX.sum())
    # Project cost mapping: rank Shelby units by P0, then interpolate the
    # sorted IEEE30 normalized marginal-cost template to 8 rank positions.
    ref_mc = np.sort(ref_sy.normalized_mc)
    ranks = np.linspace(0, len(ref_mc)-1, len(g))
    mapped_mc_by_rank = np.interp(ranks, np.arange(len(ref_mc)), ref_mc)
    normalized_mc = np.empty(len(g), dtype=float)
    normalized_mc[np.argsort(p0)] = mapped_mc_by_rank
    scale = 1.0
    load_mw = system_sink
    pmax = p0 / ref_loading_ratio
    affected = int(np.flatnonzero(g['bus_code'].to_numpy() == AFFECTED_BUS_CODE)[0])
    if not math.isclose(float(p0.sum()), system_sink, rel_tol=0, abs_tol=1e-9):
        raise AssertionError('原始门站出力与L=sum(P0)的聚合总需求不平衡')

    def shelby_case_data(case='shelby59_aggregate', generator_cost_ratio=0.0):
        if not math.isfinite(generator_cost_ratio) or generator_cost_ratio < 0:
            raise ValueError('机组权重必须为非负有限数')
        cold = mod.cold
        model = cold.build_model(float(pmax[affected]), ride_down=True,
                                 blowdown_isolated_on_detection=False)
        # Keep the cold-end model's capacity-scaled 500 MW reference parameters;
        # basin geometry and normal/protection state stay in the prototype model.
        # Pareto candidates are supplied as usable-water fractions (alpha), not
        # as basin area or warning-level inputs. CoC=4 remains the project assumption.
        model = mod.replace(model,cycles_of_concentration=4.0)
        marginal = normalized_mc.copy()  # normalized project proxy (max=1)
        cgen = generator_cost_ratio * normalized_mc
        sy = SimpleNamespace(
            N=len(g), F=affected, P0=p0.copy(), PMAX=pmax.copy(),
            RU=RAMP_FRAC_PER_MIN / 60 * pmax.copy(), L=system_sink,
            cgen=cgen, c_shed=1.0,
            generator_cost_ratio=float(generator_cost_ratio),
            marginal_cost=marginal, normalized_mc=normalized_mc,
            bus_codes=g['bus_code'].tolist(),
        )
        pmin = model.p_min_tech_frac * pmax[affected]
        return sy, model, cold, mod.controlled_replay, float(pmin)

    mod.case_data = shelby_case_data
    return mod, df, g, load_mw, raw_generation, scale, p0, pmax, normalized_mc, affected


def main():
    mod = load_model_module()
    mod, buses, generators, load_mw, raw_generation, scale, p0, pmax, normalized_mc, affected = build_test(mod)
    res = mod.scenario('Shelby59_aggregate', T=SIM_T, step=60,
                       replan=REPLAN_S, mode='both',
                       warning_alpha=ALPHA,
                       generator_cost_ratio=RHO)
    print('=== Shelby 59-bus aggregate validation ===')
    print('Input:', BUS_CSV)
    print(f"Buses={len(buses)}; generator buses={','.join(generators['bus_code'])}; ")
    print(f"gate generation P0 total={raw_generation:.3f}; modeled aggregate L=sum(P0)={load_mw:.3f}; no bus loads or export proxy used; affected={AFFECTED_BUS_CODE} (node 2).")
    print('Assumptions: raw gate flow used as P0; L=sum(P0); Pmax from IEEE30 fleet-average loading; ramp 0.007/min project assumption; cost proxy is rank-mapped IEEE30 normalized MC; no branch constraints.')
    print('Generator P0 MW (raw gate flow):', ', '.join(f'{v:.3f}' for v in p0))
    print('Generator Pmax MW (modeled):', ', '.join(f'{v:.3f}' for v in pmax))
    print(f"IEEE30 fleet average P0/Pmax={189.2/335:.6f}; alpha={ALPHA:.2f}; rho={RHO:.3f}; replan={REPLAN_S} s.")
    print(f"冷端按500 MW参考模板随G2 Pmax缩放；模型内部池几何={res['basin_area_m2']:.3f} m²（1600×Pmax_G2/500，仅作物理模型审计）。Pareto按水量计算：Vnormal={res['v0']:.3f}、Vprotect={res['vmin']:.3f}、Vwarn={res['warning']:.3f} m³。")
    print(f"报警={res['alarm']} s；AET估计={res['aet']:.3f} s；首次计划期限={res['deadline']} s。")
    for key,label in [('passive','被动'),('static','静态主动'),('dynamic','动态主动')]:
        z=res[key]
        if z is None: continue
        print(f"{label}: ENS={z['ens']:.6f} MWh；最大缺供={z['peak']:.6f} MW；缺供项={z['load_shed_cost']:.6f}；加权机组成本项={z['generation_cost']:.6f}；总目标={z['objective_cost']:.6f}。")
    successful=sum(1 for u in res['updates'] if u[1]=='重规划')
    failed=sum(1 for u in res['updates'] if u[1]=='无候选，保留原计划')
    print(f"动态更新：成功{successful}次，失败{failed}次；结果仅为项目定义的无网络约束聚合模型。")
    save_results(res, buses, generators, load_mw, raw_generation, scale, p0, pmax, normalized_mc)
    print('Saved:', RESULT_DIR/'Shelby_8机聚合验证.xlsx')


def save_results(res, buses, generators, load_mw, raw_generation, scale, p0, pmax, normalized_mc):
    RESULT_DIR.mkdir(parents=True,exist_ok=True)
    out=RESULT_DIR/'Shelby_8机聚合验证.xlsx'
    wb=Workbook();ws=wb.active;ws.title='聚合验证结果'
    ws.merge_cells('A1:J1');ws['A1']='Shelby 59母线 / 8机组聚合验证（合成参数）'
    ws['A1'].font=Font(name='微软雅黑',size=15,bold=True,color='FFFFFF');ws['A1'].fill=PatternFill('solid',fgColor='17365D');ws['A1'].alignment=Alignment(horizontal='center')
    ws.merge_cells('A2:J2');ws['A2']=f'水量比例 α={ALPHA:.2f}；机组成本相对权重 ρ={RHO:.3f}；受影响机组 {AFFECTED_BUS_CODE}；动态重规划间隔 {REPLAN_S} s。'
    ws['A2'].alignment=Alignment(horizontal='center')
    headers=['策略','ENS (MWh；相对于L=sum(P0))','最大功率缺供 (MW；相对于L=sum(P0))','缺供项','加权机组成本项','加权总目标','受影响机组发电量(MWh)','最低水量(m³)','停机时刻(s)','低于Pmin时长(s)']
    for c,h in enumerate(headers,1):
        q=ws.cell(4,c,h);q.font=Font(bold=True,color='FFFFFF');q.fill=PatternFill('solid',fgColor='4472C4');q.alignment=Alignment(horizontal='center',wrap_text=True)
    for r,(key,label) in enumerate([('passive','被动'),('static','静态主动'),('dynamic','动态主动')],5):
        x=res[key]
        vals=[label,x['ens'],x['peak'],x['load_shed_cost'],x['generation_cost'],x['objective_cost'],x['energy'],x['min_water'],x['trip'] if x['trip'] is not None else '窗口内未停机',x['low_pmin']]
        for c,v in enumerate(vals,1):
            q=ws.cell(r,c,v);q.alignment=Alignment(horizontal='center',vertical='center')
            if r%2: q.fill=PatternFill('solid',fgColor='F3F6FA')
        for c in range(2,9):ws.cell(r,c).number_format='0.000000'
    for c,width in enumerate([18,16,24,18,23,18,26,20,23,25],1):ws.column_dimensions[get_column_letter(c)].width=width
    ws.freeze_panes='A5';ws.auto_filter.ref='A4:J7'
    ws.merge_cells('A9:J9');ws['A9']=f"报警={res['alarm']} s；AET估计={res['aet']:.3f} s；首次计划期限={res['deadline']} s；动态成功重规划={sum(1 for u in res['updates'] if u[1]=='重规划')}次，失败={sum(1 for u in res['updates'] if u[1]=='无候选，保留原计划')}次。"
    ws['A9'].alignment=Alignment(wrap_text=True);ws.row_dimensions[9].height=30
    cfg=wb.create_sheet('合成假设与边界')
    cfg.merge_cells('A1:B1');cfg['A1']='输入数据、合成假设与适用边界';cfg['A1'].font=Font(name='微软雅黑',size=14,bold=True,color='FFFFFF');cfg['A1'].fill=PatternFill('solid',fgColor='17365D');cfg['A1'].alignment=Alignment(horizontal='center')
    notes=[('来源CSV',str(BUS_CSV)),('母线数',len(buses)),('机组母线',', '.join(generators['bus_code'])),('机组出力flow合计',f'{raw_generation:.3f}；8个gate_stations的原始flow直接作为机组P0，数值暂按MW等值使用（单位未经元数据确认）'),('聚合需求L',f'{load_mw:.3f}，按IEEE30式聚合平衡约定由L=sum(P0)设置；非母线负荷数据'),('负荷数据处理','不读取非gate_stations母线的负荷flow；不构造外送代理'),('flow处理',f'门站flow未缩放（系数{scale:.1f}）；模型总需求由8台P0之和确定'),('受影响机组',AFFECTED_BUS_CODE),('α定义',f'{ALPHA:.2f}；α=(Vwarn−Vprotect)/(Vnormal−Vprotect)，Pareto阈值直接从可用水量定义，不以水位作为候选输入'),('ρ',f'{RHO:.3f}，缺供成本权重归一为1'),('初始机组出力',f'保留8个gate_stations的原始flow作为P0，总和{raw_generation:.3f}；单机出力见下方机组参数表'),('合成Pmax',f'各机Pmax=P0/IEEE30全机组平均负载率（189.2/335={189.2/335:.6f}）；仅为类比标定，不是Shelby实测值'),('合成边际成本','CSV无可用机组成本曲线；按Shelby机组P0排序，将IEEE30归一化边际成本序列插值映射到8个机组，仅作合成异质成本代理；ρ由Shelby情景Pareto选取'),('爬坡','统一采用项目假设RU=0.007/60×Pmax；IEEE30 MATPOWER ramp_agc/ramp_10/ramp_30栏均为0，不能直接提供有效爬坡数值'),('仿真窗口',f'{SIM_T} s（Shelby独立窗口，扩展以覆盖重新标定池体下的五档预警阈值）'),('动态更新','固定60 s'),('网络边界','仅聚合功率平衡；无线路/变压器潮流、电压和线限约束'),('冷端缩放','冷端从500 MW参考模板按Shelby合成G2的Pmax缩放；设计循环水量和池几何随容量缩放，其余参考参数/控制设定按模板方法保留；非Shelby现场标定'),('水量与Pareto',f"Pareto直接使用水量：Vnormal={res['v0']:.3f}、Vprotect={res['vmin']:.3f}、Vwarn={res['warning']:.3f} m³；α=(Vwarn−Vprotect)/(Vnormal−Vprotect)={ALPHA:.2f}。池面积={res['basin_area_m2']:.3f} m²仅为500 MW模板容量缩放后的物理模型内部几何，不作为候选参数；CoC=4为项目假设"),('解释','结果只验证算法在另一组总负荷与8机组结构下的可运行性，不是Shelby电网或机组的工程预测。')]
    notes.extend([('无功负荷','新CSV没有无功负荷字段；本聚合测试只使用flow有功量，不对Mvar作推断。'),('flow口径限制','只读取8个gate_stations的flow作为P0；按IEEE30式平衡聚合模型设L=sum(P0)=1434，不引入其他母线负荷或外送代理。因实际负荷未纳入，ENS是相对于合成聚合L的缺供，不应解读为现场用户ENS。')])
    for r,(a,b) in enumerate(notes,3):
        cfg.cell(r,1,a);cfg.cell(r,2,b);cfg.cell(r,1).font=Font(bold=True,color='17365D');cfg.cell(r,1).fill=PatternFill('solid',fgColor='D9EAF7')
        cfg.cell(r,1).alignment=Alignment(vertical='top',wrap_text=True);cfg.cell(r,2).alignment=Alignment(vertical='top',wrap_text=True)
        cfg.row_dimensions[r].height=30 if len(str(b))<90 else 48
    cfg.column_dimensions['A'].width=24;cfg.column_dimensions['B'].width=110;cfg.freeze_panes='A3'
    units=wb.create_sheet('门站出力合成')
    units.append(['机组','节点号','原始gate flow','初始出力P0（原flow）','合成Pmax','原始flow份额','合成归一化MC'])
    for c in units[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='4472C4')
    for i,row in enumerate(generators.itertuples(index=False),0):
        raw=float(row.flow)
        units.append([row.bus_code,int(row.Nodenum),raw,float(p0[i]),float(pmax[i]),raw/raw_generation,float(normalized_mc[i])])
    for c,width in enumerate([14,14,20,24,20,18,22],1):units.column_dimensions[get_column_letter(c)].width=width
    units.freeze_panes='A2'
    upd=wb.create_sheet('动态重规划记录');upd.append(['时间(s)','动作','计划期限/说明'])
    for c in upd[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='4472C4')
    for t,action,detail in res['updates']:upd.append([t,action,detail])
    upd.column_dimensions['A'].width=18;upd.column_dimensions['B'].width=24;upd.column_dimensions['C'].width=28;upd.freeze_panes='A2'
    wb.save(out)

if __name__ == '__main__':
    main()
