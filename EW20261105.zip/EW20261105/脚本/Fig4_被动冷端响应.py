from __future__ import annotations

"""Generate the passive cold-end response plot (Figure 4) for IEEE30 and Shelby.

The panels show the no-warning baseline makeup interruption at t=0. They separate
physical availability from actual unit output and distinguish the cold-end thermal
states from the backpressure protection response. Parameters remain reference or
synthetic templates, not field calibration. Numerical checks are not field/model
validation.
"""

import importlib.util
import sys
from pathlib import Path
from svg_font_utils import enforce_times_new_roman

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
OUT_DIR = ROOT / '结果' / 'Fig4'
OUT_DIR.mkdir(parents=True, exist_ok=True)
PNG_OUT = ROOT / 'Fig4_Passive_Physical_Response.png'
SVG_OUT = ROOT / 'Fig4_Passive_Physical_Response.svg'
CSV_OUT = OUT_DIR / 'Fig4_baseline_timeseries.csv'


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'无法加载模块: {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def make_case(label: str):
    base = load_module(f'_fig3_ieee_base_{label}', ROOT / '脚本' / 'IEEE30_冷却水仿真.py')
    if label == 'IEEE30':
        return base, 'ieee30', 0.425, 18_000, '#2868A8'
    wrapper = load_module(f'_fig3_shelby_wrapper_{label}', ROOT / '脚本' / 'Shelby_冷却水仿真.py')
    model_module, *_ = wrapper.build_test(base)
    return model_module, 'shelby59_aggregate', 0.30, 22_000, '#596579'


def simulate(label: str, dt_s: float, sample_s: float):
    module, case_name, rho, horizon_s, color = make_case(label)
    sy, model, cold, engine, _pmin = module.case_data(case_name, generator_cost_ratio=rho)
    schedule = np.broadcast_to(sy.P0, (horizon_s + 1, sy.N)).copy()
    run = engine(
        model,
        power_schedule_mw=schedule[:, sy.F],
        planned_stop_s=horizon_s + 1,
        dt_s=dt_s,
        sample_every_s=sample_s,
        t_max_h=horizon_s / 3600.0,
        initial_load_frac=float(sy.P0[sy.F] / sy.PMAX[sy.F]),
    )
    t = np.asarray(run.t_s, dtype=float)
    trip_s = float(run.t_trip_h * 3600.0) if run.t_trip_h is not None else None
    return {
        'label': label, 'color': color, 'run': run, 't': t,
        'trip_s': trip_s, 'trip_h': None if trip_s is None else trip_s / 3600.0,
        'rho': rho, 'p0': float(sy.P0[sy.F]), 'model': model,
        'cold': cold, 'dt_s': dt_s,
    }


def main():
    # Plot the refined 0.25 s trajectories; compare against the original 1.0 s step.
    # One-second output resolves the protection threshold and the 3-s hold without obscuring the multi-hour trend.
    base = {lab: simulate(lab, 0.25, 1.0) for lab in ('IEEE30', 'Shelby')}
    coarse = {lab: simulate(lab, 1.0, 60.0) for lab in ('IEEE30', 'Shelby')}

    rows = []
    for lab in ('IEEE30', 'Shelby'):
        d = base[lab]
        r = d['run']
        t_h = d['t'] / 3600.0
        for i, t in enumerate(t_h):
            rows.append({
                'case': lab,
                'time_h': t,
                'basin_level_m': r.level_m[i],
                'basin_volume_m3': r.volume_m3[i],
                'cooling_water_flow_fraction': r.qcw_frac[i],
                'condenser_backpressure_kPa': r.pb_kpa[i],
                'affected_unit_power_MW': r.p_mw[i],
                'affected_unit_power_fraction_of_initial': r.p_mw[i] / d['p0'],
                'condenser_inlet_temperature_C': r.tin_c[i],
                'condenser_outlet_temperature_C': r.tout_c[i],
                'condenser_saturation_temperature_C': r.tsat_c[i],
                'available_unit_capability_fraction_of_rated': d['cold'].backpressure_power_factor(d['model'], r.pb_kpa[i]),
                'actual_unit_power_fraction_of_rated': r.p_mw[i] / d['model'].p_rated_mw,
            })
    pd.DataFrame(rows).to_csv(CSV_OUT, index=False, float_format='%.8g')

    checks = {}
    for lab in ('IEEE30', 'Shelby'):
        a, b = base[lab], coarse[lab]
        r1, r2 = a['run'], b['run']
        dt_trip_s = abs(a['trip_s'] - b['trip_s']) if a['trip_s'] is not None and b['trip_s'] is not None else float('nan')
        checks[lab] = {
            'trip_h': a['trip_h'],
            'protection_threshold_kpa': float(a['model'].pb_trip_kpa),
            'trip_reason': r1.mechanism,
            'trip_refinement_s': dt_trip_s,
            'max_pb_kpa': float(np.max(r1.pb_kpa)),
            'energy_residual_mj_025s': float(r1.max_energy_residual_mj),
            'energy_residual_mj_1s': float(r2.max_energy_residual_mj),
        }

    # Prefer Times New Roman for delivery; the sandbox lacks that proprietary face,
    # so DejaVu Serif is the local raster/math fallback. SVG retains the TNR preference.
    plt.rcParams.update({
        'font.family': 'serif', 'font.serif': ['Times New Roman', 'DejaVu Serif'],
        'mathtext.fontset': 'stix',
        'font.size': 8.4, 'axes.titlesize': 8.8, 'axes.labelsize': 8.4,
        'xtick.labelsize': 7.6, 'ytick.labelsize': 7.6,
        'svg.fonttype': 'none', 'axes.linewidth': 0.75,
    })
    # A single, unpartitioned small-multiple layout. Each subplot has its own
    # axis labels; the common limits retain direct comparisons between cases.
    fig, axes = plt.subplots(5, 2, figsize=(7.5, 9.15), sharey='row')
    fig.subplots_adjust(left=.135, right=.99, top=.945, bottom=.065,
                        hspace=.48, wspace=.28)
    row_config = [
        (r'$h_{\mathrm{basin}}$ (m)', (.85, 3.72), [1.0, 1.5, 2.0, 2.5, 3.0, 3.5]),
        (r'$Q_{cw}/Q_{design}$ (–)', (-.04, 1.08), [0, .25, .5, .75, 1.0]),
        (r'$T$ (°C)', (19.0, 58.0), [20, 30, 40, 50]),
        (r'$p_b$ (kPa)', (4.0, 16.3), [4, 6, 8, 10, 12, 14, 16]),
        (r'$P/P_{\mathrm{rated}}$ (–)', (-.04, 1.24), [0, .25, .5, .75, 1.0]),
    ]
    trip_color, level_color = '#B23A32', '#C45B32'
    normal_color, grid_color = '#74838D', '#E2E8EC'
    event_marker_handles = [
        Line2D([0], [0], color=level_color, linestyle=(0, (1, 2)), linewidth=.95,
               label='1.0-m crossing'),
        Line2D([0], [0], color=trip_color, linestyle=(0, (4, 2)), linewidth=1.05,
               label='Trip'),
    ]

    for col, label in enumerate(('IEEE30', 'Shelby')):
        d = base[label]
        r = d['run']
        color = d['color']
        t_h = d['t'] / 3600.0
        level_trip = float(d['model'].basin_level_trip_m)
        crossing_idx = next((j for j, h in enumerate(r.level_m) if h <= level_trip), None)
        if crossing_idx is None:
            raise RuntimeError(f'{label}: low-water boundary was not reached')
        if crossing_idx == 0:
            low_s = float(d['t'][0])
        else:
            t0, t1 = d['t'][crossing_idx-1:crossing_idx+1]
            h0, h1 = r.level_m[crossing_idx-1:crossing_idx+1]
            low_s = float(t0 + (level_trip-h0)*(t1-t0)/(h1-h0)) if h1 != h0 else float(t1)
        trip_s = float(d['trip_s'])
        lag_min = (trip_s-low_s)/60.0
        event_x = (d['t']-low_s)/60.0
        pb_limit = float(d['model'].pb_trip_kpa)
        if r.mechanism != 'backpressure_protection':
            raise RuntimeError(f'{label}: expected backpressure-protection termination, got {r.mechanism}')

        for row, ax in enumerate(axes[:, col]):
            ax.set_ylim(*row_config[row][1])
            ax.set_yticks(row_config[row][2])
            ax.grid(True, color=grid_color, linewidth=.6, zorder=0)
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.spines['left'].set_color('#82909A')
            ax.spines['bottom'].set_color('#7A8492')
            ax.tick_params(direction='out', length=2.7, width=.65, color='#7A8492', pad=2.5)
            ax.tick_params(labelleft=True)
            ax.set_ylabel(row_config[row][0], labelpad=5)
            ax.set_xlabel('Time (h)' if row < 2 else 'Time (min)', labelpad=3)
            ax.set_title(f"({'a' if col == 0 else 'b'}{row+1})", loc='left',
                         fontweight='bold', color='#263547', pad=2, fontsize=8.0)

        # Long-horizon water-resource trajectory. Threshold lines are identified in the caption.
        ax = axes[0, col]
        ax.plot(t_h, r.level_m, color=color, linewidth=1.9, zorder=3,
                label='Basin level')
        ax.axhline(d['model'].basin_level_normal_m, color=normal_color,
                   linestyle=':', linewidth=1.0, zorder=2, label='Normal level')
        ax.axhline(level_trip, color=level_color, linestyle='--', linewidth=1.0,
                   zorder=2, label='Low-water boundary')
        ax.legend(loc='center right', frameon=False, fontsize=5.8,
                  handlelength=1.45, labelspacing=.22, borderaxespad=.25)
        ax.set_xlim(0, 6.0)
        ax.set_xticks(np.arange(0, 6.1, 1.0))

        ax = axes[1, col]
        ax.plot(t_h, r.qcw_frac, color=color, linewidth=1.9, zorder=3,
                label=r'$Q_{cw}/Q_{design}$')
        ax.legend(loc='lower left', frameon=False, fontsize=6.0,
                  handlelength=1.5, borderaxespad=.3)
        ax.set_xlim(0, 6.0)
        ax.set_xticks(np.arange(0, 6.1, 1.0))

        # Event zoom: x=0 is the simulated 1.0-m crossing. The subtle tint marks
        # the interval to trip; protection trips at the first resolved 15-kPa(a) threshold crossing.
        x_min, x_max = -4.0, 4.5
        for row in (2, 3, 4):
            ax = axes[row, col]
            ax.set_xlim(x_min, x_max)
            ax.set_xticks([-4, -2, 0, 2, 4])
            ax.axvspan(0, lag_min, color='#B23A32', alpha=.035, zorder=0)
            ax.axvline(0, color=level_color, linestyle=(0, (1, 2)), linewidth=.95, zorder=2)
            ax.axvline(lag_min, color=trip_color, linestyle=(0, (4, 2)), linewidth=1.05, zorder=2)

        ax = axes[2, col]
        ax.plot(event_x, r.tin_c, color=color, linewidth=1.6, linestyle=(0, (4, 2)),
                alpha=.88, label=r'$T_{in}$')
        ax.plot(event_x, r.tsat_c, color=color, linewidth=1.95,
                label=r'$T_{sat}$')
        line_handles, line_labels = ax.get_legend_handles_labels()
        marker_labels = [h.get_label() for h in event_marker_handles]
        ax.legend(line_handles + event_marker_handles, line_labels + marker_labels,
                  loc='upper left', bbox_to_anchor=(.01, .94), frameon=False,
                  fontsize=5.7, ncol=2, handlelength=1.35,
                  columnspacing=.7, labelspacing=.12, borderaxespad=.12)

        ax = axes[3, col]
        ax.plot(event_x, r.pb_kpa, color=color, linewidth=1.95, zorder=3,
                label=r'$p_b$')
        ax.axhline(pb_limit, color=trip_color, linestyle=(0, (5, 3)),
                   linewidth=.95, zorder=2, label='15 kPa(a)')
        line_handles, line_labels = ax.get_legend_handles_labels()
        marker_labels = [h.get_label() for h in event_marker_handles]
        ax.legend(line_handles + event_marker_handles, line_labels + marker_labels,
                  loc='upper left', bbox_to_anchor=(.02, .82), frameon=False,
                  fontsize=5.5, ncol=2, handlelength=1.25,
                  columnspacing=.55, labelspacing=.12, borderaxespad=.12)

        ax = axes[4, col]
        p_actual = np.asarray(r.p_mw, dtype=float) / d['model'].p_rated_mw
        p_available = np.asarray([d['cold'].backpressure_power_factor(d['model'], pb)
                                  for pb in r.pb_kpa], dtype=float)
        ax.plot(event_x, p_available, color='#596779', linestyle='--', linewidth=1.5,
                label=r'$P_{avail}/P_{rated}$', zorder=3)
        ax.step(event_x, p_actual, where='post', color=color, linewidth=1.9,
                label=r'$P_{actual}/P_{rated}$', zorder=4)
        line_handles, line_labels = ax.get_legend_handles_labels()
        marker_labels = [h.get_label() for h in event_marker_handles]
        ax.legend(line_handles + event_marker_handles, line_labels + marker_labels,
                  loc='lower left', bbox_to_anchor=(.02, .02), frameon=False,
                  fontsize=5.4, ncol=1, handlelength=1.25,
                  columnspacing=.45, labelspacing=.12, borderaxespad=.12)
        ax.scatter([lag_min], [0], s=25, color=trip_color, zorder=5,
                   edgecolor='white', linewidth=.6)

    fig.canvas.draw()
    for col, col_title in enumerate(('IEEE30 (80 MW)', 'Shelby County (564.8 MW-eq.)')):
        pos = axes[0, col].get_position()
        fig.text((pos.x0 + pos.x1) / 2, pos.y1 + 0.018, col_title,
                 ha='center', va='bottom', fontsize=9.0, fontweight='bold',
                 family='Times New Roman', color='#263547')

    fig.savefig(PNG_OUT, dpi=400, bbox_inches='tight', facecolor='white')
    fig.savefig(SVG_OUT, bbox_inches='tight', facecolor='white')
    enforce_times_new_roman(SVG_OUT)
    print(f'Wrote {PNG_OUT}')
    print(f'Wrote {SVG_OUT}')
    print(f'Wrote {CSV_OUT}')
    for lab, vals in checks.items():
        print(lab, vals)



if __name__ == '__main__':
    main()
