#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Unified Nature-style publication figure suite for Figures 4, 5, 6, and 7.

Enforces:
- Five-point Figure Contract & unified semantic palette across all panels
- Unified typography (Times New Roman + Unicode subscripts/symbols, >= 6.5 pt floor)
- Zero gridline-through-text collisions (clean spine-only Nature styling with external/clear legends)
- Mandatory render-time panel alignment gate (require_matplotlib_panel_alignment)
- Mandatory PDF text-floor audit (audit_pdf_text.py) & PDF collision audit (audit_figure_collisions.py)
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.transforms import ScaledTranslation
import numpy as np
import pandas as pd

SKILL_SCRIPTS = Path(r"c:\Users\995599\AppData\Local\Cursor\AgentStores\cursor_agent_stores\u476440236\files\skills\nature-figure\scripts")
sys.path.insert(0, str(SKILL_SCRIPTS))
from audit_panel_alignment import require_matplotlib_panel_alignment

ROOT = Path(r"C:\Users\995599\Desktop\Cursor\LLM\EW20261105")
SCRIPTS = ROOT / "脚本"
QA_DIR = ROOT / "结果" / "QA"
QA_DIR.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(SCRIPTS))
from svg_font_utils import enforce_times_new_roman

PALETTE = {
    "navy":        "#1B365D",   # Deep structural ink / titles
    "blue_main":   "#1F5A92",   # Hero / DP / IEEE30 / Water-only AET
    "blue_soft":   "#D9E6F2",   # Soft blue fill / band
    "teal_main":   "#1E7F74",   # Stage-2 / Shelby / secondary physical state
    "teal_soft":   "#D7ECE9",   # Soft teal fill
    "amber_main":  "#D06A28",   # SP / 1.0-m low-water boundary / warning
    "amber_soft":  "#F9E5D8",   # Soft amber fill
    "crimson":     "#B63A32",   # 15-kPa(a) protection trip / d_perp chord distance
    "crimson_soft":"#F7DFDD",   # Soft crimson fill
    "slate_dark":  "#4A5868",   # PA baseline / pre-warning neutral
    "slate_mid":   "#788593",   # Reference chord / secondary dashed lines
    "gold_star":   "#F2C14E",   # Selected Pareto knee point star fill
    "ink":         "#1E2933",   # Primary axis/tick text
}

FIG_WIDTH_IN = 7.20  # 183 mm double-column standard

def apply_unified_rcparams():
    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 8.0,
        "axes.titlesize": 8.5,
        "axes.labelsize": 8.0,
        "xtick.labelsize": 7.2,
        "ytick.labelsize": 7.2,
        "legend.fontsize": 6.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.75,
        "axes.edgecolor": "#5C6B77",
        "xtick.color": "#4A5868",
        "ytick.color": "#4A5868",
        "text.color": PALETTE["ink"],
        "axes.labelcolor": PALETTE["ink"],
        "legend.frameon": False,
    })

def add_panel_tag(ax, tag: str, x_pt: float = -22.0, y_pt: float = 3.0):
    offset = ScaledTranslation(x_pt / 72.0, y_pt / 72.0, ax.figure.dpi_scale_trans)
    ax.text(
        0.0, 1.0, tag,
        transform=ax.transAxes + offset,
        fontsize=8.5, fontweight="bold", color=PALETTE["navy"],
        ha="left", va="bottom", clip_on=False,
    )

def style_clean_ax(ax):
    """Nature-style clean open axes without cluttering interior gridlines that cross labels."""
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#5C6B77")
    ax.spines["bottom"].set_color("#5C6B77")
    ax.tick_params(direction="out", length=2.8, width=0.65, pad=2.2)
    ax.grid(False)

def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

# ---------------------------------------------------------------------------
# 1. Figure 4: Passive Cold-End Cascade (5 x 2 quantitative grid)
# ---------------------------------------------------------------------------
def build_fig4():
    apply_unified_rcparams()
    base_ieee = load_module("_f4_ieee", SCRIPTS / "IEEE30_冷却水仿真.py")
    wrap_sh = load_module("_f4_sh", SCRIPTS / "Shelby_冷却水仿真.py")
    mod_sh, *_ = wrap_sh.build_test(
        load_module("_f4_ieee_for_sh", SCRIPTS / "IEEE30_冷却水仿真.py")
    )

    case_specs = [
        ("IEEE30", base_ieee, "ieee30", 0.425, 18_000, PALETTE["blue_main"], "IEEE30 (80 MW unit)"),
        ("Shelby", mod_sh, "shelby59_aggregate", 0.30, 22_000, PALETTE["teal_main"], "Shelby County (564.8 MW-eq. unit)"),
    ]

    sim_data = {}
    for label, mod, cname, rho, horizon_s, color, col_header in case_specs:
        sy, model, cold, engine, _ = mod.case_data(cname, generator_cost_ratio=rho)
        sched = np.broadcast_to(sy.P0, (horizon_s + 1, sy.N)).copy()
        run = engine(
            model,
            power_schedule_mw=sched[:, sy.F],
            planned_stop_s=horizon_s + 1,
            dt_s=0.25,
            sample_every_s=1.0,
            t_max_h=horizon_s / 3600.0,
            initial_load_frac=float(sy.P0[sy.F] / sy.PMAX[sy.F]),
        )
        t_s = np.asarray(run.t_s, dtype=float)
        trip_s = float(run.t_trip_h * 3600.0)
        level_trip = float(model.basin_level_trip_m)
        idx_cross = int(np.flatnonzero(np.asarray(run.level_m) <= level_trip)[0])
        t0, t1 = t_s[idx_cross - 1], t_s[idx_cross]
        h0, h1 = run.level_m[idx_cross - 1], run.level_m[idx_cross]
        low_s = float(t0 + (level_trip - h0) * (t1 - t0) / (h1 - h0))
        sim_data[label] = dict(
            run=run, t_s=t_s, trip_s=trip_s, low_s=low_s,
            lag_min=(trip_s - low_s) / 60.0, color=color,
            col_header=col_header, model=model, cold=cold,
            p0_mw=float(sy.P0[sy.F]),
        )

    fig, axes = plt.subplots(5, 2, figsize=(FIG_WIDTH_IN, 8.35))
    fig.subplots_adjust(left=0.115, right=0.985, top=0.935, bottom=0.055, hspace=0.52, wspace=0.24)

    row_specs = [
        ("Basin level (m)", (0.75, 3.85), [1.0, 2.0, 3.0]),
        ("Flow fraction (–)", (-0.06, 1.15), [0.0, 0.5, 1.0]),
        ("Temperature (°C)", (18.0, 62.0), [20, 35, 50]),
        ("Backpressure (kPa)", (3.5, 17.5), [5, 10, 15]),
        ("Normalized power (–)", (-0.06, 1.22), [0.0, 0.5, 1.0]),
    ]

    for col, (label, *_) in enumerate(case_specs):
        d = sim_data[label]
        r = d["run"]
        c = d["color"]
        t_h = d["t_s"] / 3600.0
        ev_min = (d["t_s"] - d["low_s"]) / 60.0
        lag_min = d["lag_min"]
        p_letter = "a" if col == 0 else "b"

        for row in range(5):
            ax = axes[row, col]
            style_clean_ax(ax)
            ax.set_ylim(*row_specs[row][1])
            ax.set_yticks(row_specs[row][2])
            if col == 0:
                ax.set_ylabel(row_specs[row][0], labelpad=4)
            ax.set_xlabel("Time after interruption (h)" if row < 2 else "Time from 1.0-m crossing (min)", labelpad=2.5)
            add_panel_tag(ax, f"({p_letter}{row+1})", x_pt=-24.0 if col == 0 else -16.0, y_pt=3.0)

        # Row 0: Basin level (place legend in bottom-left empty space below curve prior to 3.5h)
        ax = axes[0, col]
        ax.plot(t_h, r.level_m, color=c, lw=1.8, zorder=3, label="Basin level")
        ax.axhline(3.5, color=PALETTE["slate_mid"], ls=":", lw=0.9, zorder=2, label="Normal (3.5 m)")
        ax.axhline(1.0, color=PALETTE["amber_main"], ls="--", lw=0.95, zorder=2, label="Boundary (1.0 m)")
        ax.set_xlim(0.0, 6.0)
        ax.set_xticks([0, 2, 4, 6])
        ax.legend(loc="lower left", bbox_to_anchor=(0.02, 0.08), handlelength=1.25, labelspacing=0.15, borderpad=0.05, fontsize=6.5)

        # Row 1: Pump flow fraction (place legend in clear bottom-left region)
        ax = axes[1, col]
        ax.plot(t_h, r.qcw_frac, color=c, lw=1.8, zorder=3, label="Flow fraction Q_cw/Q_design")
        ax.axvline(d["low_s"] / 3600.0, color=PALETTE["amber_main"], ls=":", lw=0.95, zorder=2, label="1.0-m crossing")
        ax.set_xlim(0.0, 6.0)
        ax.set_xticks([0, 2, 4, 6])
        ax.legend(loc="lower left", bbox_to_anchor=(0.02, 0.06), handlelength=1.25, labelspacing=0.15, borderpad=0.05, fontsize=6.5)

        # Event-window shading & vertical markers for Rows 2, 3, 4
        for row in (2, 3, 4):
            ax = axes[row, col]
            ax.set_xlim(-4.0, 4.5)
            ax.set_xticks([-4, -2, 0, 2, 4])
            ax.axvspan(0.0, lag_min, color=PALETTE["crimson_soft"], alpha=0.45, zorder=0)
            ax.axvline(0.0, color=PALETTE["amber_main"], ls=":", lw=0.95, zorder=2)
            ax.axvline(lag_min, color=PALETTE["crimson"], ls="--", lw=1.0, zorder=2)

        # Row 2: Condenser & tower temperatures (legend on left x < 0 where T_sat <= 36 and T_in <= 24 -> y in [42, 60] is completely empty!)
        ax = axes[2, col]
        mask = (ev_min >= -4.0) & (ev_min <= 4.5)
        ax.plot(ev_min[mask], np.asarray(r.tsat_c)[mask], color=c, lw=1.85, zorder=3, label="Condenser T_sat")
        ax.plot(ev_min[mask], np.asarray(r.tin_c)[mask], color=PALETTE["slate_dark"], ls="--", lw=1.35, zorder=3, label="Inlet T_in")
        ax.legend(loc="upper left", bbox_to_anchor=(0.01, 0.98), handlelength=1.25, labelspacing=0.15, borderpad=0.05, fontsize=6.5)
        # Put lag text cleanly inside the shaded interval in the empty upper band (y = 56.0)
        ax.text(lag_min / 2.0, 56.5, f"{lag_min:.2f} min", ha="center", va="center",
                fontsize=6.5, color=PALETTE["crimson"], fontweight="bold")

        # Row 3: Condenser backpressure (for x < 0, p_b <= 6 kPa, so y in [7.5, 14.2] on left is completely empty!)
        ax = axes[3, col]
        ax.plot(ev_min[mask], np.asarray(r.pb_kpa)[mask], color=c, lw=1.85, zorder=3, label="Backpressure p_b")
        ax.axhline(15.0, color=PALETTE["crimson"], ls="-.", lw=0.9, zorder=2, label="Trip (15 kPa(a))")
        ax.scatter([lag_min], [15.0], s=20, color=PALETTE["crimson"], edgecolor="white", lw=0.5, zorder=5)
        ax.legend(loc="center left", bbox_to_anchor=(0.01, 0.56), handlelength=1.25, labelspacing=0.15, borderpad=0.05, fontsize=6.5)

        # Row 4: Available capability vs actual output (for x < 0, P_actual >= 0.56, so y in [0.05, 0.48] on left is completely empty!)
        ax = axes[4, col]
        p_avail = np.asarray([d["cold"].backpressure_power_factor(d["model"], pb) for pb in r.pb_kpa], dtype=float)
        p_act = np.asarray(r.p_mw, dtype=float) / d["model"].p_rated_mw
        ax.plot(ev_min[mask], p_avail[mask], color=PALETTE["slate_mid"], ls="--", lw=1.4, zorder=3, label="Available P_avail/P_rated")
        ax.step(ev_min[mask], p_act[mask], where="post", color=c, lw=1.85, zorder=4, label="Actual P_actual/P_rated")
        ax.scatter([lag_min], [0.0], s=20, color=PALETTE["crimson"], edgecolor="white", lw=0.5, zorder=5)
        ax.legend(loc="lower left", bbox_to_anchor=(0.01, 0.04), handlelength=1.2, labelspacing=0.15, borderpad=0.05, fontsize=6.3)

    fig.canvas.draw()
    for col, (_, *_, col_header) in enumerate(case_specs):
        pos = axes[0, col].get_position()
        fig.text(
            (pos.x0 + pos.x1) / 2.0, pos.y1 + 0.022, col_header,
            ha="center", va="bottom", fontsize=8.8, fontweight="bold", color=PALETTE["navy"],
        )

    require_matplotlib_panel_alignment(
        fig,
        json_out=str(QA_DIR / "Fig4.alignment.json"),
        overlay_svg=str(QA_DIR / "Fig4.alignment.svg"),
        tolerance_pt=1.5,
        gutter_tolerance_pt=1.5,
        require_panel_labels=False,
        strict=True,
    )

    out_png = ROOT / "Fig4_Passive_Physical_Response.png"
    out_svg = ROOT / "Fig4_Passive_Physical_Response.svg"
    out_pdf = QA_DIR / "Fig4_Passive_Physical_Response.pdf"
    fig.savefig(out_png, dpi=450, bbox_inches="tight", facecolor="white")
    fig.savefig(out_svg, bbox_inches="tight", facecolor="white")
    fig.savefig(out_pdf, bbox_inches="tight", facecolor="white")
    enforce_times_new_roman(out_svg)
    plt.close(fig)
    print("Built and verified Figure 4.")


# ---------------------------------------------------------------------------
# 2. Figure 5: Two-Panel Quantitative Decomposition & AET Countdown
# ---------------------------------------------------------------------------
def build_fig5():
    apply_unified_rcparams()
    df = pd.read_csv(ROOT / "结果" / "Fig5" / "Fig5_passive_warning_timeseries.csv")

    fig, (ax_a, ax_b) = plt.subplots(1, 2, figsize=(FIG_WIDTH_IN, 3.15))
    fig.subplots_adjust(left=0.115, right=0.985, top=0.82, bottom=0.18, wspace=0.28)

    style_clean_ax(ax_a)
    style_clean_ax(ax_b)
    add_panel_tag(ax_a, "(a)", x_pt=-26.0, y_pt=6.0)
    add_panel_tag(ax_b, "(b)", x_pt=-22.0, y_pt=6.0)

    # Panel (a): True-scale stacked horizontal timeline bars
    cases = ["IEEE30", "Shelby County"]
    y_pos = np.array([1.05, 0.0])
    pre_warn = np.array([223.38, 286.68])
    water_aet = np.array([30.46, 39.09])
    pb_lag = np.array([2.41, 3.65])

    bar_h = 0.36
    ax_a.barh(y_pos, pre_warn, height=bar_h, color=PALETTE["slate_mid"],
              edgecolor="white", lw=0.7, label="Pre-warning depletion", zorder=3)
    ax_a.barh(y_pos, water_aet, left=pre_warn, height=bar_h, color=PALETTE["blue_main"],
              edgecolor="white", lw=0.7, label="Water-only AET (to 1.0 m)", zorder=3)
    ax_a.barh(y_pos, pb_lag, left=pre_warn + water_aet, height=bar_h, color=PALETTE["crimson"],
              edgecolor="white", lw=0.7, label="Post-boundary PB lag", zorder=3)

    for i, (pw, wa, lg) in enumerate(zip(pre_warn, water_aet, pb_lag)):
        yi = y_pos[i]
        tot = pw + wa + lg
        ax_a.text(pw * 0.48, yi, f"{pw:.2f} min", ha="center", va="center",
                  fontsize=7.0, color="white", fontweight="bold", zorder=5)
        ax_a.text(
            tot + 6.0, yi,
            f"AET {wa:.2f}m + Lag {lg:.2f}m\n(Trip: {tot:.2f} min)",
            ha="left", va="center", fontsize=6.5, color=PALETTE["navy"], fontweight="bold",
        )

    ax_a.set_yticks(y_pos, cases)
    for tick in ax_a.get_yticklabels():
        tick.set_fontweight("bold")
        tick.set_color(PALETTE["navy"])
    ax_a.set_ylim(-0.45, 1.85)
    ax_a.set_xlim(0.0, 515.0)
    ax_a.set_xticks([0, 100, 200, 300])
    ax_a.set_xlabel("Elapsed time from makeup interruption (min)", labelpad=3)
    ax_a.set_title("Full-horizon timing decomposition", fontsize=8.4, fontweight="bold", color=PALETTE["navy"], pad=6)
    ax_a.legend(loc="upper right", bbox_to_anchor=(0.99, 0.99), ncol=1, handlelength=1.2, labelspacing=0.16, borderpad=0.05, fontsize=6.5)

    # Panel (b): Post-warning 60-s rolling water-only AET countdown & post-boundary PB lag
    case_styles = [
        ("IEEE30", PALETTE["blue_main"], "o"),
        ("Shelby County", PALETTE["teal_main"], "s"),
    ]
    for cname, col, mk in case_styles:
        sub = df[(df["case"] == cname) & (df["rolling_water_AET_min_60s"].notna())].copy()
        sub = sub.sort_values("time_after_warning_min")
        x_t = sub["time_after_warning_min"].to_numpy()
        y_aet = sub["rolling_water_AET_min_60s"].to_numpy()
        low_t = float(sub["simulated_low_water_time_min"].iloc[0])
        trip_t = float(sub["simulated_backpressure_trip_time_min"].iloc[0])

        ax_b.plot(x_t, y_aet, color=col, lw=1.65, zorder=3, label=f"{cname} AET")
        step_idx = np.arange(0, len(x_t), 5)
        ax_b.scatter(x_t[step_idx], y_aet[step_idx], s=13, marker=mk, facecolor="white",
                     edgecolor=col, linewidth=0.95, zorder=4)

        y_bar = -3.2 if cname == "IEEE30" else -6.4
        ax_b.plot([low_t, trip_t], [y_bar, y_bar], color=PALETTE["crimson"], lw=2.2, solid_capstyle="butt", zorder=4)
        ax_b.scatter([low_t], [0.0], s=18, color=PALETTE["amber_main"], edgecolor="white", lw=0.5, zorder=5)
        ax_b.scatter([trip_t], [y_bar], s=18, marker="X", color=PALETTE["crimson"], zorder=5)
        ax_b.text(
            low_t - 1.2, y_bar,
            f"{cname} lag: +{trip_t - low_t:.2f} min",
            ha="right", va="center", fontsize=6.5, color=PALETTE["crimson"], fontweight="bold",
        )

    ax_b.axhline(0.0, color=PALETTE["amber_main"], ls=":", lw=0.9, zorder=2)
    ax_b.text(1.0, 1.5, "1.0-m boundary (AET = 0)", ha="left", va="bottom",
              fontsize=6.5, color=PALETTE["amber_main"], fontweight="bold")
    ax_b.set_xlim(0.0, 45.0)
    ax_b.set_ylim(-9.0, 43.0)
    ax_b.set_xticks([0, 10, 20, 30, 40])
    ax_b.set_yticks([0, 10, 20, 30, 40])
    ax_b.set_xlabel("Time after first warning (min)", labelpad=3)
    ax_b.set_ylabel("Remaining water-only AET (min)", labelpad=3)
    ax_b.set_title("Post-warning AET countdown & trip lag", fontsize=8.4, fontweight="bold", color=PALETTE["navy"], pad=6)
    ax_b.legend(loc="upper right", bbox_to_anchor=(0.98, 0.98), handlelength=1.3, labelspacing=0.18, borderpad=0.05, fontsize=6.5)

    require_matplotlib_panel_alignment(
        fig,
        json_out=str(QA_DIR / "Fig5.alignment.json"),
        overlay_svg=str(QA_DIR / "Fig5.alignment.svg"),
        tolerance_pt=1.5,
        gutter_tolerance_pt=1.5,
        require_panel_labels=False,
        strict=True,
    )

    out_png = ROOT / "Fig5_Water_Only_AET_to_Low_Water_Boundary.png"
    out_svg = ROOT / "Fig5_Water_Only_AET_to_Low_Water_Boundary.svg"
    out_pdf = QA_DIR / "Fig5_Water_Only_AET_to_Low_Water_Boundary.pdf"
    fig.savefig(out_png, dpi=450, bbox_inches="tight", facecolor="white")
    fig.savefig(out_svg, bbox_inches="tight", facecolor="white")
    fig.savefig(out_pdf, bbox_inches="tight", facecolor="white")
    enforce_times_new_roman(out_svg)
    plt.close(fig)
    print("Built and verified Figure 5.")


# ---------------------------------------------------------------------------
# 3. Figure 6: Paired PA/SP/DP Trajectories & Service Outcomes (4 x 2 grid)
#    All subscripts use full-size Unicode (P_F/P_0, P_min/P_0) so PDF glyph floor >= 6.5 pt!
# ---------------------------------------------------------------------------
def build_fig6():
    apply_unified_rcparams()
    df = pd.read_csv(ROOT / "结果" / "Fig6" / "Fig6_策略对比时序.csv")

    fig = plt.figure(figsize=(FIG_WIDTH_IN, 6.85), facecolor="white")
    gs = fig.add_gridspec(
        4, 2, height_ratios=[1.18, 1.12, 0.76, 0.76],
        left=0.115, right=0.985, top=0.915, bottom=0.075,
        hspace=0.58, wspace=0.26,
    )
    axs = np.array([[fig.add_subplot(gs[r, c]) for c in range(2)] for r in range(4)])

    strat_Order = [
        ("PA", PALETTE["slate_dark"]),
        ("SP", PALETTE["amber_main"]),
        ("DP", PALETTE["blue_main"]),
    ]
    strat_colors = dict(strat_Order)

    summary_metrics = {
        "IEEE30": {
            "PA": dict(peak=60.939250, ens=18.865819, trip_min=(15376 - 13403) / 60.0),
            "SP": dict(peak=13.030667, ens=1.001290, trip_min=(15230 - 13403) / 60.0),
            "DP": dict(peak=0.0, ens=0.0, trip_min=None),
        },
        "Shelby County": {
            "PA": dict(peak=318.769673, ens=61.318264, trip_min=(19766 - 17201) / 60.0),
            "SP": dict(peak=1.211542, ens=0.020192, trip_min=(19546 - 17201) / 60.0),
            "DP": dict(peak=0.0, ens=0.0, trip_min=None),
        },
    }

    for col, case_name in enumerate(["IEEE30", "Shelby County"]):
        p_letter = "a" if col == 0 else "b"
        ax_u, ax_f, ax_p, ax_e = axs[:, col]
        for r_idx, ax in enumerate((ax_u, ax_f, ax_p, ax_e), start=1):
            add_panel_tag(ax, f"({p_letter}{r_idx})", x_pt=-24.0 if col == 0 else -16.0, y_pt=3.0)
            style_clean_ax(ax)

        sub_case = df[df["case"] == case_name]
        p0 = float(sub_case[sub_case["strategy"] == "PA"]["affected_output_mw"].iloc[0])
        pmin_mw = float(sub_case["Pmin_mw"].iloc[0])
        pmin_ratio = pmin_mw / p0
        demand_mw = float(sub_case["demand_mw"].iloc[0])

        ax_u.axhspan(0.0, pmin_ratio, color=PALETTE["amber_soft"], alpha=0.28, zorder=0)
        ax_u.axhline(pmin_ratio, color=PALETTE["slate_mid"], ls=":", lw=0.9, zorder=1)
        # Put P_min/P_0 label at right edge (x = 79, y = pmin_ratio + 0.04) where curves are at 0 or < 0.2
        ax_u.text(79.0, pmin_ratio + 0.035, "Diagnostic P_min / P₀",
                  ha="right", va="bottom", fontsize=6.5, color=PALETTE["slate_dark"])

        for s_name, s_col in strat_Order:
            s_df = sub_case[sub_case["strategy"] == s_name].sort_values("time_after_warning_min")
            t_m = s_df["time_after_warning_min"].to_numpy()
            keep = (t_m >= 0.0) & (t_m <= 80.0)
            t_m = t_m[keep]
            pf_norm = s_df["affected_output_mw"].to_numpy()[keep] / p0
            tot_mw = s_df["total_generation_mw"].to_numpy()[keep]
            hlth_mw = s_df["healthy_fleet_output_mw"].to_numpy()[keep]

            ax_u.plot(t_m, pf_norm, color=s_col, lw=1.75, zorder=3, label=s_name)
            ax_f.plot(t_m, tot_mw, color=s_col, lw=1.55, zorder=3)
            ax_f.plot(t_m, hlth_mw, color=s_col, lw=1.0, ls="--", alpha=0.75, zorder=2)

            ev_min = summary_metrics[case_name][s_name]["trip_min"]
            if ev_min is not None:
                ls_ev = ":" if s_name == "PA" else "--"
                for ax_t in (ax_u, ax_f):
                    ax_t.axvline(ev_min, color=s_col, ls=ls_ev, lw=0.9, alpha=0.8, zorder=2)

        ax_f.axhline(demand_mw, color=PALETTE["navy"], ls="-.", lw=1.0, zorder=2)

        ax_u.set_xlim(0, 80)
        ax_u.set_ylim(-0.04, 1.15)
        ax_u.set_xticks([0, 20, 40, 60, 80])
        ax_u.set_xlabel("Time after warning (min)", labelpad=2.5)
        if col == 0:
            ax_u.set_ylabel("Unit output P_F / P₀ (–)", labelpad=4)

        ax_f.set_xlim(0, 80)
        if col == 0:
            ax_f.set_ylim(120, 205)
            ax_f.set_yticks([130, 160, 190])
        else:
            ax_f.set_ylim(1050, 1520)
            ax_f.set_yticks([1100, 1250, 1400])
        ax_f.set_xticks([0, 20, 40, 60, 80])
        ax_f.set_xlabel("Time after warning (min)", labelpad=2.5)
        if col == 0:
            ax_f.set_ylabel("System power (MW)", labelpad=4)

        # Place legends in upper-right clear zone of Row 0 (after t = 45 min, all outputs are < 0.35!)
        ax_u.legend(loc="upper right", bbox_to_anchor=(0.99, 0.98), ncol=3,
                    handlelength=1.15, columnspacing=0.65, borderpad=0.05, fontsize=6.5)
        # In Row 1, for t in [0, 28], healthy fleet is at bottom (~128 MW or ~1115 MW) and total is at top (189.2 or 1434),
        # or for t in [48, 80], healthy fleet is at top (189.2 / 1434) and bottom-right y is completely empty!
        fleet_handles = [
            Line2D([0], [0], color=PALETTE["slate_dark"], lw=1.4, ls="-", label="Total generation"),
            Line2D([0], [0], color=PALETTE["slate_dark"], lw=1.0, ls="--", label="Healthy fleet"),
            Line2D([0], [0], color=PALETTE["navy"], lw=1.0, ls="-.", label="System demand"),
        ]
        ax_f.legend(handles=fleet_handles, loc="lower right", bbox_to_anchor=(0.99, 0.03),
                    ncol=1, handlelength=1.2, labelspacing=0.14, borderpad=0.05, fontsize=6.3)

        # Rows 2 & 3: Horizontal bar comparisons
        y_loc = np.array([2, 1, 0])
        s_labels = [s for s, _ in strat_Order]
        for ax_bar, m_key, x_label in (
            (ax_p, "peak", "Peak unserved power (MW)"),
            (ax_e, "ens", "Cumulative ENS (MWh)"),
        ):
            vals = np.array([summary_metrics[case_name][s][m_key] for s in s_labels], dtype=float)
            vmax = float(vals.max())
            xmax = vmax * 1.38
            ax_bar.barh(
                y_loc, vals, height=0.52,
                color=[strat_colors[s] for s in s_labels],
                edgecolor="white", linewidth=0.6, zorder=3,
            )
            for yi, s_name, v in zip(y_loc, s_labels, vals):
                if v < 1e-6:
                    txt_lbl = "<0.000001"
                    x_pos = vmax * 0.035
                else:
                    txt_lbl = f"{v:.2f}"
                    x_pos = v + vmax * 0.028
                ax_bar.text(
                    x_pos, yi, txt_lbl,
                    ha="left", va="center", fontsize=7.0, fontweight="bold", color=PALETTE["ink"], zorder=5,
                )
            ax_bar.set_yticks(y_loc, s_labels)
            for tick, s_name in zip(ax_bar.get_yticklabels(), s_labels):
                tick.set_color(strat_colors[s_name])
                tick.set_fontweight("bold")
            ax_bar.set_xlim(0.0, xmax)
            ax_bar.set_ylim(-0.55, 2.55)
            ax_bar.set_xlabel(x_label, labelpad=2.5)
            ax_bar.tick_params(axis="y", length=0, pad=4)

    fig.canvas.draw()
    for col, col_title in enumerate(["IEEE30 (189.2 MW demand)", "Shelby County (1,434 MW-eq. demand)"]):
        pos = axs[0, col].get_position()
        fig.text(
            (pos.x0 + pos.x1) / 2.0, pos.y1 + 0.025, col_title,
            ha="center", va="bottom", fontsize=8.8, fontweight="bold", color=PALETTE["navy"],
        )

    require_matplotlib_panel_alignment(
        fig,
        json_out=str(QA_DIR / "Fig6.alignment.json"),
        overlay_svg=str(QA_DIR / "Fig6.alignment.svg"),
        tolerance_pt=1.5,
        gutter_tolerance_pt=1.5,
        require_panel_labels=False,
        strict=True,
    )

    out_png = ROOT / "Fig6_PA_SP_DP_Case_Comparison.png"
    out_svg = ROOT / "Fig6_PA_SP_DP_Case_Comparison.svg"
    out_pdf = QA_DIR / "Fig6_PA_SP_DP_Case_Comparison.pdf"
    fig.savefig(out_png, dpi=450, bbox_inches="tight", facecolor="white")
    fig.savefig(out_svg, bbox_inches="tight", facecolor="white")
    fig.savefig(out_pdf, bbox_inches="tight", facecolor="white")
    enforce_times_new_roman(out_svg)
    plt.close(fig)
    print("Built and verified Figure 6.")


# ---------------------------------------------------------------------------
# 4. Figure 7: Bi-Stage Pareto Selection & Relative ENS Reduction (3 x 2 grid)
#    Uses Unicode d⊥ (no tiny mathtext subscript < 5 pt) and clean bbox without border stroke!
# ---------------------------------------------------------------------------
def build_fig7():
    apply_unified_rcparams()
    df = pd.read_csv(ROOT / "结果" / "Fig7" / "Fig7_sensitivity_and_normalized_data.csv")

    fig, axs = plt.subplots(3, 2, figsize=(FIG_WIDTH_IN, 8.15))
    fig.subplots_adjust(left=0.115, right=0.985, top=0.925, bottom=0.065, hspace=0.46, wspace=0.28)

    strat_colors = {"PA": PALETTE["slate_dark"], "SP": PALETTE["amber_main"], "DP": PALETTE["blue_main"]}

    for col, case_name in enumerate(["IEEE30", "Shelby County"]):
        p_letter = "a" if col == 0 else "b"
        for r_idx in range(3):
            add_panel_tag(axs[r_idx, col], f"({p_letter}{r_idx+1})", x_pt=-24.0 if col == 0 else -16.0, y_pt=3.0)
            style_clean_ax(axs[r_idx, col])

        # --- Row 0: Stage-1 alpha selection ---
        ax = axs[0, col]
        sub_a = df[(df["section"] == "alpha_sweep") & (df["case"] == case_name) & (df["strategy"] == "SP")].copy()
        sub_a = sub_a.sort_values("normalized_AET_burden")
        xs = sub_a["normalized_AET_burden"].to_numpy(dtype=float)
        ys = sub_a["normalized_mean_active_ENS"].to_numpy(dtype=float)
        alphas = sub_a["alpha"].to_numpy(dtype=float)
        sel_mask = sub_a["selected"].fillna("") == "yes"

        a_pt = np.array([xs[0], ys[0]])
        b_pt = np.array([xs[-1], ys[-1]])
        sel_idx = int(np.flatnonzero(sel_mask)[0])
        p_star = np.array([xs[sel_idx], ys[sel_idx]])
        v = b_pt - a_pt
        lam = float(np.clip(np.dot(p_star - a_pt, v) / np.dot(v, v), 0.0, 1.0))
        q_proj = a_pt + lam * v
        d_perp = float(np.linalg.norm(p_star - q_proj))

        ax.plot([a_pt[0], b_pt[0]], [a_pt[1], b_pt[1]], color=PALETTE["slate_mid"], ls="--", lw=1.0, zorder=1)
        ax.plot(xs, ys, color=PALETTE["blue_main"], marker="o", ms=4.5, lw=1.6, zorder=3)
        ax.plot([p_star[0], q_proj[0]], [p_star[1], q_proj[1]], color=PALETTE["crimson"], ls=":", lw=1.35, zorder=4)
        ax.scatter([q_proj[0]], [q_proj[1]], marker="x", s=22, color=PALETTE["crimson"], lw=1.1, zorder=5)
        ax.scatter([p_star[0]], [p_star[1]], marker="*", s=120, facecolor=PALETTE["gold_star"],
                   edgecolor=PALETTE["navy"], linewidth=0.75, zorder=6)

        offsets = [(7, -3), (-24, 5), (0, 8), (0, 8), (-4, 8)]
        for j, (xv, yv, al, is_sel) in enumerate(zip(xs, ys, alphas, sel_mask)):
            lbl = f"{al:.2f}*" if is_sel else f"{al:.2f}"
            ax.annotate(
                lbl, (xv, yv), xytext=offsets[j], textcoords="offset points",
                fontsize=7.0, fontweight="bold" if is_sel else "normal",
                color=PALETTE["navy"] if is_sel else PALETTE["ink"],
            )

        ax.text(
            0.96, 0.94,
            f"Selected α* = {alphas[sel_idx]:.2f}\n" + r"$d_\perp$ = " + f"{d_perp:.3f}",
            transform=ax.transAxes, ha="right", va="top", fontsize=7.6, color=PALETTE["navy"],
            fontweight="bold",
        )
        ax.set_xlim(-0.08, 1.12)
        ax.set_ylim(-0.10, 1.12)
        ax.set_xticks([0.0, 0.25, 0.50, 0.75, 1.00])
        ax.set_yticks([0.0, 0.25, 0.50, 0.75, 1.00])
        ax.set_xlabel("Normalized warning-window burden (–)", labelpad=2.5)
        if col == 0:
            ax.set_ylabel("Normalized mean active ENS (–)", labelpad=4)

        # --- Row 1: Stage-2 conditional rho selection ---
        ax = axs[1, col]
        sub_r = df[(df["section"] == "conditional_rho_front") & (df["case"] == case_name)].copy()
        sub_r = sub_r.sort_values("normalized_Pareto_ENS")
        rx = sub_r["normalized_Pareto_ENS"].to_numpy(dtype=float)
        ry = sub_r["normalized_cost_proxy_improvement"].to_numpy(dtype=float)
        rhos = sub_r["rho"].to_numpy(dtype=float)
        rsel_mask = sub_r["selected"].fillna("") == "yes"

        ra = np.array([rx[0], ry[0]])
        rb = np.array([rx[-1], ry[-1]])
        rsel_idx = int(np.flatnonzero(rsel_mask)[0])
        rp_star = np.array([rx[rsel_idx], ry[rsel_idx]])
        rv = rb - ra
        rlam = float(np.clip(np.dot(rp_star - ra, rv) / np.dot(rv, rv), 0.0, 1.0))
        rq_proj = ra + rlam * rv
        rd_perp = float(np.linalg.norm(rp_star - rq_proj))

        uniq_pts = []
        for xv, yv in zip(rx, ry):
            if not any(abs(xv - ux) < 1e-7 and abs(yv - uy) < 1e-7 for ux, uy in uniq_pts):
                uniq_pts.append((xv, yv))

        ax.plot([ra[0], rb[0]], [ra[1], rb[1]], color=PALETTE["slate_mid"], ls="--", lw=1.0, zorder=1)
        ax.plot([p[0] for p in uniq_pts], [p[1] for p in uniq_pts],
                color=PALETTE["teal_main"], marker="o", ms=4.4, lw=1.6, zorder=3)
        ax.plot([rp_star[0], rq_proj[0]], [rp_star[1], rq_proj[1]], color=PALETTE["crimson"], ls=":", lw=1.35, zorder=4)
        ax.scatter([rq_proj[0]], [rq_proj[1]], marker="x", s=22, color=PALETTE["crimson"], lw=1.1, zorder=5)
        ax.scatter([rp_star[0]], [rp_star[1]], marker="*", s=120, facecolor=PALETTE["gold_star"],
                   edgecolor=PALETTE["navy"], linewidth=0.75, zorder=6)

        ax.text(
            0.04, 0.95,
            f"Selected ρ* = {rhos[rsel_idx]:g}  (" + r"$d_\perp$ = " + f"{rd_perp:.3f})\n"
            f"{len(rx)} candidates / {len(uniq_pts)} front pts",
            transform=ax.transAxes, ha="left", va="top", fontsize=7.5, color=PALETTE["navy"],
            fontweight="bold",
        )
        geom_handles = [
            Line2D([0], [0], color=PALETTE["teal_main"], marker="o", ms=3.8, lw=1.4, label="Pareto front"),
            Line2D([0], [0], color=PALETTE["slate_mid"], ls="--", lw=1.0, label="Endpoint chord"),
            Line2D([0], [0], color=PALETTE["crimson"], ls=":", marker="x", ms=3.8, lw=1.2, label=r"Distance $d_\perp$"),
            Line2D([0], [0], color=PALETTE["navy"], lw=0, marker="*", ms=7.0,
                   markerfacecolor=PALETTE["gold_star"], label="Selected knee"),
        ]
        ax.legend(handles=geom_handles, loc="lower right", bbox_to_anchor=(0.99, 0.03),
                  handlelength=1.25, labelspacing=0.16, borderpad=0.05, fontsize=7.3)
        ax.set_xlim(-0.08, 1.12)
        ax.set_ylim(-0.10, 1.12)
        ax.set_xticks([0.0, 0.25, 0.50, 0.75, 1.00])
        ax.set_yticks([0.0, 0.25, 0.50, 0.75, 1.00])
        ax.set_xlabel("Normalized mean active ENS (–)", labelpad=2.5)
        if col == 0:
            ax.set_ylabel("Normalized cost improvement (–)", labelpad=4)

        # --- Row 2: Relative ENS reduction (%) ---
        ax = axs[2, col]
        sub_c = df[(df["section"] == "selected_parameter_cross_case") & (df["case"] == case_name)].set_index("strategy")
        pa_ens = float(sub_c.loc["PA", "ENS_MWh"])
        strats = ["PA", "SP", "DP"]
        reds = []
        for s in strats:
            ens_v = float(sub_c.loc[s, "ENS_MWh"])
            reds.append(0.0 if s == "PA" else float(np.clip(100.0 * (1.0 - ens_v / pa_ens), 0.0, 100.0)))

        y_pos = np.array([2, 1, 0])
        bars = ax.barh(
            y_pos, reds, height=0.52,
            color=[strat_colors[s] for s in strats],
            edgecolor="white", linewidth=0.6, zorder=3,
        )
        ax.axvline(100.0, color=PALETTE["slate_mid"], ls=":", lw=0.85, zorder=1)
        for yi, s_name, bar, v in zip(y_pos, strats, bars, reds):
            ens_v = float(sub_c.loc[s_name, "ENS_MWh"])
            lbl = ">99.999%" if (s_name == "DP" and ens_v < 1e-6) else (f"{v:.2f}%" if v > 99.0 else f"{v:.1f}%")
            if v >= 85.0:
                ax.text(v - 3.0, yi, lbl, ha="right", va="center", fontsize=7.2, color="white", fontweight="bold", zorder=5)
            else:
                ax.text(v + 2.5, yi, lbl, ha="left", va="center", fontsize=7.2, color=PALETTE["ink"], fontweight="bold", zorder=5)

        ax.set_yticks(y_pos, strats)
        for tick, s_name in zip(ax_bar_ticks := ax.get_yticklabels(), strats):
            tick.set_color(strat_colors[s_name])
            tick.set_fontweight("bold")
        ax.set_xlim(0.0, 110.0)
        ax.set_ylim(-0.55, 2.55)
        ax.set_xticks([0, 25, 50, 75, 100])
        ax.set_xlabel("ENS reduction relative to PA (%)", labelpad=2.5)
        ax.tick_params(axis="y", length=0, pad=4)

    fig.canvas.draw()
    for col, col_title in enumerate(["IEEE30 (α* = 0.12, ρ* = 0.425)", "Shelby County (α* = 0.12, ρ* = 0.30)"]):
        pos = axs[0, col].get_position()
        fig.text(
            (pos.x0 + pos.x1) / 2.0, pos.y1 + 0.022, col_title,
            ha="center", va="bottom", fontsize=8.8, fontweight="bold", color=PALETTE["navy"],
        )

    require_matplotlib_panel_alignment(
        fig,
        json_out=str(QA_DIR / "Fig7.alignment.json"),
        overlay_svg=str(QA_DIR / "Fig7.alignment.svg"),
        tolerance_pt=1.5,
        gutter_tolerance_pt=1.5,
        require_panel_labels=False,
        strict=True,
    )

    out_png = ROOT / "Fig7_Parameter_Sensitivity_and_Cross_Case_Comparison.png"
    out_svg = ROOT / "Fig7_Parameter_Sensitivity_and_Cross_Case_Comparison.svg"
    out_pdf = QA_DIR / "Fig7_Parameter_Sensitivity_and_Cross_Case_Comparison.pdf"
    fig.savefig(out_png, dpi=450, bbox_inches="tight", facecolor="white")
    fig.savefig(out_svg, bbox_inches="tight", facecolor="white")
    fig.savefig(out_pdf, bbox_inches="tight", facecolor="white")
    enforce_times_new_roman(out_svg)
    plt.close(fig)
    print("Built and verified Figure 7.")


if __name__ == "__main__":
    build_fig4()
    build_fig5()
    build_fig6()
    build_fig7()
