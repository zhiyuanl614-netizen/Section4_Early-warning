from __future__ import annotations

"""Generate Figure 5: warning lead time and rolling AET for passive-reference runs.

The current model defines AET as time to the basin low-level threshold. The
unit trip is a later backpressure-protection event. The chart keeps these events
separate and stops AET at the low-level boundary. PA is used to retain an
observable failure boundary; 60 s marks are diagnostic AET updates, not control
execution events.
"""

import importlib.util
import sys
from pathlib import Path
from svg_font_utils import enforce_times_new_roman

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

ROOT = Path(__file__).resolve().parent.parent
OUT_DIR = ROOT / '结果' / 'Fig5'
OUT_DIR.mkdir(parents=True, exist_ok=True)
PNG_OUT = ROOT / 'Fig5_Water_Only_AET_to_Low_Water_Boundary.png'
SVG_OUT = ROOT / 'Fig5_Water_Only_AET_to_Low_Water_Boundary.svg'
CSV_OUT = OUT_DIR / 'Fig5_passive_warning_timeseries.csv'


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'Cannot load module: {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def prepare_case(label: str):
    base = load_module(f'_fig4_ieee_base_{label}', ROOT / '脚本' / 'IEEE30_冷却水仿真.py')
    if label == 'IEEE30':
        return base, 'ieee30', 0.425, 18_000, '#2868A8'
    wrapper = load_module(f'_fig4_shelby_wrapper_{label}', ROOT / '脚本' / 'Shelby_冷却水仿真.py')
    module, *_ = wrapper.build_test(base)
    return module, 'shelby59_aggregate', 0.30, 22_000, '#596579'


def build_case(label: str):
    module, case_name, rho, horizon_s, color = prepare_case(label)
    # Use the same warning settings and operational AET formula as the current
    # case scripts. Static planning is run only to preserve the common scenario
    # setup; this figure plots the passive reference trajectory.
    result = module.scenario(
        case_name, T=horizon_s, step=60, replan=60, mode='static',
        generator_cost_ratio=rho, warning_alpha=0.12,
    )
    sy, model, cold, engine, _pmin = module.case_data(case_name, generator_cost_ratio=rho)
    schedule = np.broadcast_to(sy.P0, (horizon_s + 1, sy.N)).copy()
    run = engine(
        model,
        power_schedule_mw=schedule[:, sy.F],
        planned_stop_s=horizon_s + 1,
        dt_s=0.25,
        sample_every_s=1.0,
        t_max_h=horizon_s / 3600.0,
        initial_load_frac=float(sy.P0[sy.F] / sy.PMAX[sy.F]),
    )
    t_s = np.asarray(run.t_s, dtype=float)
    level = np.asarray(run.level_m, dtype=float)
    volume = np.asarray(run.volume_m3, dtype=float)
    loss = np.asarray(run.loss_m3s, dtype=float)
    vmin, v0 = float(result['vmin']), float(result['v0'])
    warning = float(result['warning'])
    alpha = float(result['alpha'])
    alarm_s = float(result['alarm'])
    aet_s = float(result['aet'])
    trip_s = float(run.t_trip_h * 3600.0) if run.t_trip_h is not None else float(t_s[-1])

    trip_level = float(model.basin_level_trip_m)
    cross_indices = np.flatnonzero(level <= trip_level)
    if len(cross_indices) == 0:
        raise RuntimeError(f'{label}: low-level boundary not reached in the reference run')
    j = int(cross_indices[0])
    if j == 0:
        low_s = float(t_s[0])
    else:
        t0, t1 = t_s[j-1], t_s[j]
        h0, h1 = level[j-1], level[j]
        low_s = float(t0 + (trip_level-h0)*(t1-t0)/(h1-h0)) if h1 != h0 else float(t1)

    # Rolling AET at the 60 s observation cadence, up to the actual low-level
    # threshold. AET is undefined for this purpose once the threshold is reached.
    sample_s = np.r_[np.arange(alarm_s, low_s, 60.0), low_s]
    sample_s = np.unique(sample_s)
    v_sample = np.interp(sample_s, t_s, volume)
    qloss_sample = np.interp(sample_s, t_s, loss)
    aet_remaining_s = np.full(sample_s.shape, np.nan, dtype=float)
    valid = qloss_sample > 1e-10
    aet_remaining_s[valid] = np.maximum(0.0, v_sample[valid]-vmin) / qloss_sample[valid]
    actual_remaining_s = np.maximum(0.0, low_s-sample_s)
    trip_sample_s = np.unique(np.r_[np.arange(alarm_s, trip_s, 60.0), low_s, trip_s])
    actual_trip_x = (trip_sample_s-alarm_s)/60.0
    actual_trip_remaining_min = (trip_s-trip_sample_s)/60.0

    # Keep the stored run at 1-s cadence for an accurate low-water crossing,
    # while retaining a compact 10-s audit series plus event points in the CSV.
    indices = (t_s >= alarm_s) & (np.mod(t_s, 10.0) < 1e-8)
    plot_t_s = np.r_[alarm_s, t_s[indices], low_s, trip_s]
    plot_t_s = np.unique(plot_t_s[(plot_t_s >= alarm_s) & (plot_t_s <= trip_s)])
    plot_volume = np.interp(plot_t_s, t_s, volume)
    usable_fraction = np.clip((plot_volume-vmin) / max(v0-vmin, 1e-12), 0.0, 1.0)
    x_after_alert_min = (plot_t_s-alarm_s)/60.0
    low_after_alert_min = (low_s-alarm_s)/60.0
    trip_after_alert_min = (trip_s-alarm_s)/60.0
    aet_water_min = aet_s/60.0
    pressure_lag_min = (trip_s-low_s)/60.0
    aet_trip_forecast_min = aet_water_min+pressure_lag_min
    aet_error_min = low_after_alert_min-aet_water_min
    rolling_aet_trip_min = aet_remaining_s/60.0+pressure_lag_min

    return {
        'label': label, 'color': color, 'result': result, 'run': run,
        'model': model, 'vmin': vmin, 'v0': v0, 'warning': warning, 'alpha': alpha,
        'alarm_s': alarm_s, 'aet_s': aet_s, 'low_s': low_s, 'trip_s': trip_s,
        'low_min': low_after_alert_min, 'trip_min': trip_after_alert_min,
        'forecast_min': aet_water_min, 'pressure_lag_min': pressure_lag_min,
        'trip_forecast_min': aet_trip_forecast_min, 'aet_error_min': aet_error_min,
        'plot_x': x_after_alert_min, 'usable_fraction': usable_fraction,
        'roll_x': (sample_s-alarm_s)/60.0,
        'rolling_water_aet_min': aet_remaining_s/60.0,
        'rolling_trip_aet_min': rolling_aet_trip_min,
        'actual_remaining_min': actual_remaining_s/60.0,
        'actual_trip_x': actual_trip_x,
        'actual_trip_remaining_min': actual_trip_remaining_min,
        'trip_reason': run.mechanism,
    }


def main():
    cases = {label: build_case(label) for label in ('IEEE30', 'Shelby')}

    # Save auditable time series and event metadata for reproducing the figure.
    rows = []
    for label, d in cases.items():
        for i, x in enumerate(d['plot_x']):
            rows.append({
                'case': 'Shelby County' if label == 'Shelby' else label,
                'time_after_warning_min': x,
                'usable_water_fraction': d['usable_fraction'][i],
                'initial_water_AET_min': d['forecast_min'],
                'post_threshold_pressure_lag_min': d['pressure_lag_min'],
                'initial_total_AET_to_PB_trip_min': d['trip_forecast_min'],
                'simulated_low_water_time_min': d['low_min'],
                'simulated_backpressure_trip_time_min': d['trip_min'],
                'AET_error_to_low_level_min': d['aet_error_min'],
            })
        for i, x in enumerate(d['roll_x']):
            rows.append({
                'case': 'Shelby County' if label == 'Shelby' else label,
                'time_after_warning_min': x,
                'usable_water_fraction': np.nan,
                'initial_water_AET_min': d['forecast_min'],
                'post_threshold_pressure_lag_min': d['pressure_lag_min'],
                'initial_total_AET_to_PB_trip_min': d['trip_forecast_min'],
                'simulated_low_water_time_min': d['low_min'],
                'simulated_backpressure_trip_time_min': d['trip_min'],
                'AET_error_to_low_level_min': d['aet_error_min'],
                'rolling_water_AET_min_60s': d['rolling_water_aet_min'][i],
                'rolling_total_AET_to_PB_trip_min_60s': d['rolling_trip_aet_min'][i],
                'actual_remaining_to_low_water_min': d['actual_remaining_min'][i],
            })
    pd.DataFrame(rows).to_csv(CSV_OUT, index=False, float_format='%.8g')

    # Times New Roman is preferred for delivery; the local sandbox falls back
    # to DejaVu Serif because it does not ship the proprietary Times face.
    plt.rcParams.update({
        'font.family': 'serif', 'font.serif': ['Times New Roman', 'DejaVu Serif'],
        'mathtext.fontset': 'stix',
        'font.size': 8.5, 'axes.titlesize': 8.8, 'axes.labelsize': 8.5,
        'xtick.labelsize': 7.6, 'ytick.labelsize': 7.6,
        'legend.fontsize': 6.5, 'axes.spines.top': False,
        'axes.spines.right': False, 'svg.fonttype': 'none', 'axes.linewidth': .75,
    })
    # A two-case sequence diagram focuses on the three distinct clocks:
    # interruption-to-warning, warning-to-low-water AET, and low-water-to-trip
    # protection lag. Segment lengths are schematic, not proportional.
    fig, ax = plt.subplots(figsize=(9.0, 3.55))
    fig.subplots_adjust(left=.025, right=.985, top=.91, bottom=.12)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')
    x_nodes = [0.22, 0.46, 0.71, 0.96]
    y_rows = {'IEEE30': .70, 'Shelby': .38}
    colors = ['#596579', '#2868A8', '#B23A32']
    node_labels = ['Interruption', 'First warning', '1.0-m boundary', 'PB-protection trip']
    for label in ('IEEE30', 'Shelby'):
        d = cases[label]
        y = y_rows[label]
        display = 'Shelby County' if label == 'Shelby' else label
        ax.text(.005, y, display, ha='left', va='center', fontsize=9.0,
                fontweight='bold', color='#263547')
        interval_labels = [
            f"{d['alarm_s']/60.0:.2f} min",
            f"Water-only AET  {d['forecast_min']:.2f} min",
            f"Backpressure-protection lag  {d['pressure_lag_min']:.2f} min",
        ]
        for i, (x0, x1) in enumerate(zip(x_nodes[:-1], x_nodes[1:])):
            ax.annotate('', xy=(x1, y), xytext=(x0, y),
                        arrowprops=dict(arrowstyle='-|>', lw=1.6,
                                        color=colors[i], mutation_scale=10))
            ax.text((x0+x1)/2, y+.075, interval_labels[i], ha='center', va='bottom',
                    fontsize=8.0, color='#263547')
        for x in x_nodes:
            ax.scatter([x], [y], s=22, color='#263547', zorder=4)
    # Shared event labels clarify the origin and endpoint of every interval.
    for x, label in zip(x_nodes, node_labels):
        ax.text(x, .105, label, ha='center', va='bottom', fontsize=7.8,
                color='#263547')
    ax.text(.59, .015, 'Sequence schematic; interval widths are not to scale.',
            ha='center', va='bottom', fontsize=7.2, color='#596579')

    fig.savefig(PNG_OUT,dpi=400,bbox_inches='tight',facecolor='white')
    fig.savefig(SVG_OUT,bbox_inches='tight',facecolor='white')
    enforce_times_new_roman(SVG_OUT)
    print(f'Wrote {PNG_OUT}')
    print(f'Wrote {SVG_OUT}')
    print(f'Wrote {CSV_OUT}')
    for label, d in cases.items():
        print(label, {
            'alarm_s': d['alarm_s'], 'water_AET_s': d['aet_s'], 'pressure_lag_s': d['pressure_lag_min']*60,
            'total_AET_to_PB_trip_s': d['trip_forecast_min']*60,
            'low_level_time_s': d['low_s'], 'PB_trip_s': d['trip_s'],
            'water_AET_error_to_low_level_s': d['aet_error_min']*60,
            'trip_lag_after_low_level_min': d['trip_min']-d['low_min'],
        })




if __name__ == '__main__':
    main()
