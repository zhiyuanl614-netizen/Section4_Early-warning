#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Nature-style Figure 2: IEEE30 vs Shelby County topology comparison.

Reuses the existing topology artwork (not redrawn), but applies the unified
publication palette/typography from Figures 4–7:
  - double-column width 183 mm (7.20 in)
  - Times New Roman panel tags and case titles
  - semantic panel tinting (IEEE30 blue / Shelby teal)
  - clean open frames and shared legend strip
"""
from __future__ import annotations

from base64 import b64encode
from io import BytesIO
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parent.parent
IEEE_SRC = ROOT / "IEEE_30bus_original_clarity_enhanced.png"
SHELBY_SRC = ROOT / "Shelby_59_Node_Topology.png"
PNG_OUT = ROOT / "Fig2_IEEE30_Shelby_Topology_Comparison.png"
SVG_OUT = ROOT / "Fig2_IEEE30_Shelby_Topology_Comparison.svg"
QA_DIR = ROOT / "结果" / "QA"
QA_DIR.mkdir(parents=True, exist_ok=True)
PDF_OUT = QA_DIR / "Fig2_IEEE30_Shelby_Topology_Comparison.pdf"

# Unified semantic palette (match Figs 4–7)
NAVY = (27, 54, 93)          # #1B365D
BLUE_INK = (31, 90, 146)     # #1F5A92 IEEE30
TEAL_INK = (30, 127, 116)    # #1E7F74 Shelby
SLATE = (74, 88, 104)        # #4A5868
FRAME = (197, 211, 223)      # #C5D3DF
BG = (255, 255, 255)
SOFT_BLUE = (217, 230, 242)  # #D9E6F2
SOFT_TEAL = (215, 236, 233)  # #D7ECE9

# Final physical size: 183 mm wide ≈ 7.20 in at 450 dpi
DPI = 450
FIG_W_IN = 7.20
FIG_W_PX = int(round(FIG_W_IN * DPI))  # 3240


def crop_to_artwork(im: Image.Image, padding: int = 40) -> Image.Image:
    im = im.convert("RGB")
    diff = ImageChops.difference(im, Image.new("RGB", im.size, "white"))
    mask = diff.convert("L").point(lambda p: 255 if p > 18 else 0)
    box = mask.getbbox()
    if box is None:
        return im
    l, t, r, b = box
    return im.crop((max(0, l - padding), max(0, t - padding),
                    min(im.width, r + padding), min(im.height, b + padding)))


def remove_shelby_legend_border(im: Image.Image) -> Image.Image:
    draw = ImageDraw.Draw(im)
    draw.rectangle((1840, 2057, 2420, 2162), outline="white", width=12)
    return im


def tint_topology(im: Image.Image, ink: tuple[int, int, int]) -> Image.Image:
    """Map dark ink to the panel semantic color while keeping white background."""
    gray = im.convert("L")
    # Slight contrast boost before tinting for cleaner strokes
    gray = ImageEnhance.Contrast(gray).enhance(1.12)
    colored = ImageOps.colorize(gray, black=ink, white="#FFFFFF").convert("RGB")
    return colored


def enlarge_ieee_labels(im: Image.Image, ink: tuple[int, int, int]) -> Image.Image:
    im = im.convert("RGB")
    draw = ImageDraw.Draw(im)
    boxes = {
        1: (91, 2667, 105, 2700), 2: (646, 3072, 667, 3105), 3: (396, 2667, 414, 2700),
        4: (719, 2667, 742, 2700), 5: (1638, 3076, 1653, 3099), 6: (1741, 2667, 1762, 2700),
        7: (1814, 2860, 1835, 2893), 8: (2326, 2669, 2346, 2704), 9: (1427, 2340, 1450, 2373),
        10: (1521, 2068, 1561, 2101), 11: (1072, 2345, 1106, 2378), 12: (698, 2192, 737, 2225),
        13: (362, 2193, 400, 2225), 14: (460, 1875, 500, 1907), 15: (704, 1244, 742, 1276),
        16: (943, 1875, 982, 1907), 17: (1416, 1729, 1456, 1762), 18: (1238, 1244, 1277, 1276),
        19: (1699, 1244, 1737, 1276), 20: (1602, 1488, 1645, 1520), 21: (2051, 1648, 2092, 1681),
        22: (2177, 1868, 2221, 1901), 23: (1130, 872, 1172, 904), 24: (1970, 872, 2014, 904),
        25: (1689, 516, 1731, 548), 26: (1230, 516, 1274, 548), 27: (1166, 176, 1210, 208),
        28: (2315, 176, 2360, 208), 29: (98, 176, 142, 208), 30: (97, 596, 142, 628),
    }
    font = ImageFont.truetype(r"C:\Windows\Fonts\timesbd.ttf", 50)
    for number, (x0, y0, x1, y1) in boxes.items():
        pad = 6
        draw.rectangle((x0 - pad, y0 - pad, x1 + pad, y1 + pad), fill="white")
        text = str(number)
        bb = draw.textbbox((0, 0), text, font=font)
        tw, th = bb[2] - bb[0], bb[3] - bb[1]
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        draw.text((cx - tw / 2 - bb[0], cy - th / 2 - bb[1]), text, font=font, fill=ink)

    # Enlarge IEEE legend card and strip outer frame
    card_box = (1972, 3327, 2549, 3430)
    card = im.crop(card_box)
    scale = 1.70
    card = card.resize((round(card.width * scale), round(card.height * scale)), Image.Resampling.LANCZOS)
    ImageDraw.Draw(card).rectangle((0, 0, card.width - 1, card.height - 1), outline="white", width=12)
    ImageDraw.Draw(im).rectangle(card_box, fill="white")
    im.paste(card, (im.width - 55 - card.width, im.height - 22 - card.height))
    return im


def scale_to_height(im: Image.Image, h: int) -> Image.Image:
    w = max(1, round(im.width * h / im.height))
    return im.resize((w, h), Image.Resampling.LANCZOS)


def png_bytes(im: Image.Image) -> bytes:
    bio = BytesIO()
    im.save(bio, format="PNG", optimize=True)
    return bio.getvalue()


def draw_rounded_rect(draw: ImageDraw.ImageDraw, box, fill=None, outline=None, width=2, radius=18):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def main():
    # Prepare panels
    ieee = enlarge_ieee_labels(Image.open(IEEE_SRC).convert("RGB"), BLUE_INK)
    ieee = tint_topology(crop_to_artwork(ieee), BLUE_INK)

    shelby = remove_shelby_legend_border(Image.open(SHELBY_SRC).convert("RGB"))
    shelby = tint_topology(crop_to_artwork(shelby), TEAL_INK)

    # Equal panel height; keep native aspect ratios
    panel_h = 2100
    ieee_panel = scale_to_height(ieee, panel_h)
    shelby_panel = scale_to_height(shelby, panel_h)

    # Layout proportions for 183 mm final width
    # Internal composition canvas is then scaled to FIG_W_PX
    margin = 70
    gap = 90
    header_h = 150
    footer_h = 96
    x1 = margin
    x2 = x1 + ieee_panel.width + gap
    y_img = header_h
    canvas_w = x2 + shelby_panel.width + margin
    canvas_h = header_h + panel_h + footer_h

    canvas = Image.new("RGB", (canvas_w, canvas_h), BG)
    draw = ImageDraw.Draw(canvas)

    title_font = ImageFont.truetype(r"C:\Windows\Fonts\timesbd.ttf", 54)
    tag_font = ImageFont.truetype(r"C:\Windows\Fonts\timesbd.ttf", 58)
    footer_font = ImageFont.truetype(r"C:\Windows\Fonts\times.ttf", 36)

    panels = [
        (x1, ieee_panel, "(a)", "IEEE 30-bus benchmark", BLUE_INK, SOFT_BLUE),
        (x2, shelby_panel, "(b)", "Shelby County 59-node network", TEAL_INK, SOFT_TEAL),
    ]

    for x, panel, tag, title, ink, soft in panels:
        # Soft header band behind title
        draw_rounded_rect(
            draw,
            (x - 8, 28, x + panel.width + 8, 118),
            fill=soft, outline=None, radius=16,
        )
        # Panel tag + case title
        draw.text((x + 10, 42), tag, font=tag_font, fill=NAVY)
        # Title centered in remaining header width
        tb = draw.textbbox((0, 0), title, font=title_font)
        tw = tb[2] - tb[0]
        draw.text((x + (panel.width - tw) / 2, 52), title, font=title_font, fill=ink)

        # Topology panel with clean frame
        canvas.paste(panel, (x, y_img))
        draw.rectangle(
            (x, y_img, x + panel.width - 1, y_img + panel_h - 1),
            outline=FRAME, width=3,
        )

    # Shared footer note — topologies are contextual only
    footer_y0 = y_img + panel_h + 22
    draw_rounded_rect(
        draw,
        (margin, footer_y0, canvas_w - margin, canvas_h - 22),
        fill=(245, 248, 250), outline=FRAME, width=2, radius=14,
    )
    note = (
        "Network context only: dispatch uses aggregate power balance "
        "(no branch-flow, voltage, or frequency constraints)."
    )
    nb = draw.textbbox((0, 0), note, font=footer_font)
    nw = nb[2] - nb[0]
    nh = nb[3] - nb[1]
    footer_box_h = (canvas_h - 22) - footer_y0
    draw.text(
        ((canvas_w - nw) / 2, footer_y0 + (footer_box_h - nh) / 2 - nb[1]),
        note, font=footer_font, fill=SLATE,
    )

    # Scale entire composition to exact double-column pixel width
    scale = FIG_W_PX / canvas_w
    out_h = max(1, int(round(canvas_h * scale)))
    final = canvas.resize((FIG_W_PX, out_h), Image.Resampling.LANCZOS)

    final.save(PNG_OUT, dpi=(DPI, DPI), optimize=True)
    # Also save a PDF via Pillow for QA (raster page, same visual)
    final_rgb = final.convert("RGB")
    final_rgb.save(PDF_OUT, "PDF", resolution=float(DPI))

    # Self-contained SVG with vector labels + embedded raster panels
    # Rebuild SVG at the composition (pre-scale) coordinates for crisp text,
    # then set viewBox to composition and width/height to final inches.
    ieee_data = b64encode(png_bytes(ieee_panel)).decode("ascii")
    shelby_data = b64encode(png_bytes(shelby_panel)).decode("ascii")
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
 width="{FIG_W_IN}in" height="{FIG_W_IN * out_h / FIG_W_PX:.4f}in"
 viewBox="0 0 {canvas_w} {canvas_h}">
<title>IEEE30 and Shelby County topology comparison</title>
<desc>Two-panel topology context figure. Dispatch uses aggregate power balance only.</desc>
<rect width="100%" height="100%" fill="#FFFFFF"/>
<style>
  .tag {{font-family:'Times New Roman',serif;font-size:58px;font-weight:700;fill:#1B365D}}
  .title-a {{font-family:'Times New Roman',serif;font-size:54px;font-weight:700;fill:#1F5A92}}
  .title-b {{font-family:'Times New Roman',serif;font-size:54px;font-weight:700;fill:#1E7F74}}
  .note {{font-family:'Times New Roman',serif;font-size:36px;fill:#4A5868}}
</style>
<!-- Header bands -->
<rect x="{x1-8}" y="28" width="{ieee_panel.width+16}" height="90" rx="16" fill="#D9E6F2"/>
<rect x="{x2-8}" y="28" width="{shelby_panel.width+16}" height="90" rx="16" fill="#D7ECE9"/>
<text class="tag" x="{x1+10}" y="88">(a)</text>
<text class="tag" x="{x2+10}" y="88">(b)</text>
<text class="title-a" x="{x1 + ieee_panel.width/2}" y="92" text-anchor="middle">IEEE 30-bus benchmark</text>
<text class="title-b" x="{x2 + shelby_panel.width/2}" y="92" text-anchor="middle">Shelby County 59-node network</text>
<!-- Topology panels -->
<image x="{x1}" y="{y_img}" width="{ieee_panel.width}" height="{panel_h}" href="data:image/png;base64,{ieee_data}"/>
<image x="{x2}" y="{y_img}" width="{shelby_panel.width}" height="{panel_h}" href="data:image/png;base64,{shelby_data}"/>
<rect x="{x1}" y="{y_img}" width="{ieee_panel.width}" height="{panel_h}" fill="none" stroke="#C5D3DF" stroke-width="3"/>
<rect x="{x2}" y="{y_img}" width="{shelby_panel.width}" height="{panel_h}" fill="none" stroke="#C5D3DF" stroke-width="3"/>
<!-- Footer -->
<rect x="{margin}" y="{footer_y0}" width="{canvas_w - 2*margin}" height="{canvas_h - footer_y0 - 22}" rx="14" fill="#F5F8FA" stroke="#C5D3DF" stroke-width="2"/>
<text class="note" x="{canvas_w/2}" y="{footer_y0 + (canvas_h - footer_y0 - 22)/2 + 12}" text-anchor="middle">{note}</text>
</svg>
'''
    SVG_OUT.write_text(svg, encoding="utf-8")

    print(f"Wrote {PNG_OUT} ({final.size[0]}x{final.size[1]} @ {DPI} dpi)")
    print(f"Wrote {SVG_OUT}")
    print(f"Wrote {PDF_OUT}")
    print(f"Panels: IEEE30 {ieee_panel.size}; Shelby {shelby_panel.size}")


if __name__ == "__main__":
    main()
