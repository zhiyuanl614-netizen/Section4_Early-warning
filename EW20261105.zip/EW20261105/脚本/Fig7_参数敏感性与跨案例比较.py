#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Figure 7: finite-grid alpha/rho selection and cross-case ENS outcomes."""
from __future__ import annotations
import csv
import re
import zipfile
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib import font_manager
from svg_font_utils import enforce_times_new_roman
import numpy as np

class _XlsxSheet:
    def __init__(self, rows):
        self._rows = rows
    def iter_rows(self, min_row=1, values_only=True):
        return self._rows[min_row - 1:]

class _XlsxWorkbook:
    def __init__(self, path):
        self._sheets = {}
        ns_main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
        ns_rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
        with zipfile.ZipFile(path, "r") as z:
            shared = []
            if "xl/sharedStrings.xml" in z.namelist():
                ss_root = ET.fromstring(z.read("xl/sharedStrings.xml"))
                for si in ss_root.findall(f"{{{ns_main}}}si"):
                    shared.append("".join(t.text or "" for t in si.findall(f".//{{{ns_main}}}t")))
            wb_root = ET.fromstring(z.read("xl/workbook.xml"))
            rels_root = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
            rmap = {r.attrib["Id"]: r.attrib["Target"] for r in rels_root}
            for sh in wb_root.findall(f".//{{{ns_main}}}sheet"):
                name = sh.attrib["name"]
                rid = sh.attrib[f"{{{ns_rel}}}id"]
                target = rmap[rid].lstrip("/")
                if not target.startswith("xl/"):
                    target = "xl/" + target
                sh_root = ET.fromstring(z.read(target))
                rows_out = []
                for row_el in sh_root.findall(f".//{{{ns_main}}}row"):
                    vals = []
                    for c_el in row_el.findall(f"{{{ns_main}}}c"):
                        ref = c_el.attrib.get("r", "")
                        col_letters = re.match(r"([A-Z]+)", ref).group(1) if ref else ""
                        col_idx = 0
                        for ch in col_letters:
                            col_idx = col_idx * 26 + (ord(ch) - 64)
                        while len(vals) < col_idx - 1:
                            vals.append(None)
                        t_attr = c_el.attrib.get("t", "")
                        v_el = c_el.find(f"{{{ns_main}}}v")
                        is_el = c_el.find(f"{{{ns_main}}}is")
                        if t_attr == "s" and v_el is not None and v_el.text is not None:
                            val = shared[int(v_el.text)]
                        elif t_attr == "inlineStr" and is_el is not None:
                            val = "".join(t.text or "" for t in is_el.findall(f".//{{{ns_main}}}t"))
                        elif v_el is not None and v_el.text is not None:
                            txt = v_el.text
                            try:
                                val = int(txt) if "." not in txt and "e" not in txt.lower() else float(txt)
                            except ValueError:
                                val = txt
                        else:
                            val = None
                        vals.append(val)
                    while len(vals) < 16:
                        vals.append(None)
                    rows_out.append(tuple(vals))
                self._sheets[name] = _XlsxSheet(rows_out)
    def __getitem__(self, name):
        return self._sheets[name]
    def close(self):
        pass

def load_workbook(path, data_only=True, read_only=True):
    return _XlsxWorkbook(path)

ROOT = Path(__file__).resolve().parent.parent
OUT_DIR = ROOT / '结果' / 'Fig7'
OUT_DIR.mkdir(parents=True, exist_ok=True)
OUT_PNG = ROOT / 'Fig7_Parameter_Sensitivity_and_Cross_Case_Comparison.png'
OUT_SVG = ROOT / 'Fig7_Parameter_Sensitivity_and_Cross_Case_Comparison.svg'
OUT_CSV = OUT_DIR / 'Fig7_sensitivity_and_normalized_data.csv'

CASES = [
    dict(name='IEEE30', book=ROOT/'结果'/'IEEE30'/'IEEE30_两阶段Pareto自动复算.xlsx',
         passive_lag_s=144.58161073804513),
    dict(name='Shelby County', book=ROOT/'结果'/'Shelby'/'Shelby_α与ρ_Pareto选参.xlsx',
         passive_lag_s=218.7831406108453),
]
FIG6_CSV = ROOT / '结果' / 'Fig6' / 'Fig6_策略对比时序.csv'
COLORS = {'PA':'#596579', 'SP':'#D17835', 'DP':'#2D70A8'}


def rows_as_dicts(ws):
    rows = list(ws.iter_rows(values_only=True))
    headers = [str(x).strip() if x is not None else '' for x in rows[0]]
    return [dict(zip(headers, r)) for r in rows[1:] if any(x is not None for x in r)]


def read_summary_selection(wb):
    ws = wb['顺序选参摘要']
    alpha = rho = None
    for r in ws.iter_rows(min_row=1, values_only=True):
        key = str(r[0] or '')
        value = r[1]
        if (key.strip() == '选定α') or key.startswith('先选α'):
            try: alpha = float(str(value).split()[0])
            except (TypeError, ValueError): pass
        if ('条件ρ' in key) or ('再选条件ρ' in key):
            try: rho = float(str(value).split()[0])
            except (TypeError, ValueError): pass
    if alpha is None or rho is None:
        raise RuntimeError('Cannot parse selected alpha/rho from Pareto workbook summary')
    return alpha, rho


def read_case_pareto(spec):
    wb = load_workbook(spec['book'], data_only=True, read_only=True)
    selected_alpha, selected_rho = read_summary_selection(wb)
    alpha_sheet = wb['阶段1 α候选']
    alpha_dicts = rows_as_dicts(alpha_sheet)
    alpha_data = []
    for r in alpha_dicts:
        alpha = float(r['α'])
        aet_s = next(float(v) for k, v in r.items() if 'AET' in k and '(s)' in k)
        static_ens = next(float(v) for k, v in r.items() if k.startswith('静态ENS'))
        dynamic_ens = next(float(v) for k, v in r.items() if k.startswith('动态ENS'))
        norm_x = next(float(v) for k,v in r.items() if ('归一AET' in k or '归一化AET负担' in k))
        norm_y = next(float(v) for k,v in r.items() if ('归一ENS' in k or '归一化ENS' in k))
        chord_d = next(float(v) for k,v in r.items() if '弦距' in k)
        alpha_data.append(dict(alpha=alpha, water_aet_s=aet_s,
                               total_aet_min=(aet_s+spec['passive_lag_s'])/60,
                               static_ens=static_ens, dynamic_ens=dynamic_ens,
                               norm_x=norm_x, norm_y=norm_y, chord_d=chord_d,
                               selected=abs(alpha-selected_alpha)<1e-10))

    rho_sheet = wb['阶段2 ρ候选']
    rho_dicts = rows_as_dicts(rho_sheet)
    rho_data = []
    for r in rho_dicts:
        rho_key = next(k for k in r if k.startswith('ρ'))
        rho = float(r[rho_key])
        pareto_key = next(k for k in r if 'Pareto非支配' in k)
        if str(r[pareto_key] or '') != '是':
            continue
        x_key = next(k for k in r if ('归一ENS' in k or '归一化ENS' in k))
        y_key = next(k for k in r if ('归一成本改善' in k or '归一化成本改善' in k))
        selected_key = next(k for k in r if k == '选中')
        chord_key = next(k for k in r if '弦距' in k)
        rho_data.append(dict(rho=rho, x=float(r[x_key]), y=float(r[y_key]),
                             chord_d=float(r[chord_key]),
                             selected=(str(r[selected_key] or '')=='是')))
    wb.close()
    return selected_alpha, selected_rho, alpha_data, rho_data


def read_fig5_metrics():
    grouped = defaultdict(lambda: dict(ens_mwh=0.0, demand_mw=None, duration_s=0))
    with FIG6_CSV.open(newline='', encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            case_id = 'Shelby County' if r['case'] == 'Shelby County' else r['case']
            k=(case_id,r['strategy'])
            g=grouped[k]
            if r.get('load_shed_mw','') not in ('',None):
                g['ens_mwh'] += float(r['load_shed_mw'])/3600.0
            g['demand_mw'] = float(r['demand_mw'])
            g['duration_s'] = max(g['duration_s'], int(float(r['time_from_outage_s'])))
    metrics={}
    for spec in CASES:
        case=spec['name']
        metrics[case]={}
        for strategy in ('PA','SP','DP'):
            g=grouped[(case,strategy)]
            den=g['demand_mw']*g['duration_s']/3600.0
            ens = 0.0 if g['ens_mwh'] < 1e-9 else g['ens_mwh']
            metrics[case][strategy]={**g,'ens_mwh':ens,
                                     'normalized_ens_pct':100*ens/den if den else 0.0}
    return metrics


def group_duplicate_front_points(points, tol=1e-8):
    groups=[]
    for p in points:
        found=None
        for g in groups:
            if abs(g['x']-p['x'])<=tol and abs(g['y']-p['y'])<=tol:
                found=g; break
        if found is None:
            groups.append(dict(x=p['x'],y=p['y'],rhos=[p['rho']],selected=p['selected']))
        else:
            found['rhos'].append(p['rho'])
            found['selected']=found['selected'] or p['selected']
    return groups


def chord_projection(points, x_key, y_key, selected):
    ordered = sorted(points, key=lambda p: p[x_key])
    a = np.array([ordered[0][x_key], ordered[0][y_key]], dtype=float)
    b = np.array([ordered[-1][x_key], ordered[-1][y_key]], dtype=float)
    p = np.array([selected[x_key], selected[y_key]], dtype=float)
    v = b-a
    t = float(np.clip(np.dot(p-a,v)/np.dot(v,v),0,1))
    q = a+t*v
    return a,b,p,q,float(np.linalg.norm(p-q))


def write_data_csv(case_data, metrics):
    with OUT_CSV.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f)
        w.writerow(['section','case','alpha','rho','water_AET_min','passive_pressure_lag_min',
                    'total_AET_to_PB_trip_min','strategy','ENS_MWh','ENS_over_demand_energy_pct',
                    'normalized_AET_burden','normalized_mean_active_ENS','chord_distance',
                    'normalized_Pareto_ENS','normalized_cost_proxy_improvement','selected'])
        for d in case_data:
            name=d['spec']['name']; lag=d['spec']['passive_lag_s']/60
            for p in d['alpha_data']:
                for strat in ('SP','DP'):
                    w.writerow(['alpha_sweep',name,p['alpha'],'',p['water_aet_s']/60,lag,
                                p['total_aet_min'],strat,p['static_ens'] if strat=='SP' else p['dynamic_ens'],
                                '',p['norm_x'],p['norm_y'],p['chord_d'],'','',
                                'yes' if p['selected'] else ''])
            for p in d['rho_data']:
                w.writerow(['conditional_rho_front',name,d['selected_alpha'],p['rho'],'',lag,'','','',
                            '', '', '', p['chord_d'], p['x'], p['y'],
                            'yes' if p['selected'] else ''])
            for strat in ('PA','SP','DP'):
                m=metrics[name][strat]
                w.writerow(['selected_parameter_cross_case',name,d['selected_alpha'],d['selected_rho'],
                            '',lag,'',strat,m['ens_mwh'],m['normalized_ens_pct'],
                            '', '', '', '', '', ''])


def make_figure(case_data, metrics):
    """Three-stage, two-case layout with orthogonal chord distances shown to scale."""
    # SVG text is normalized to declare Times New Roman; PNG rendering uses the
    # installed DejaVu Serif fallback because Times New Roman is not bundled.
    FIG_FONT='Times New Roman'
    plt.rcParams.update({
        'font.family':FIG_FONT,'font.serif':[FIG_FONT],
        'mathtext.fontset':'stix','font.size':8.6,
        'axes.titlesize':9.0, 'axes.labelsize':8.4,
        'xtick.labelsize':7.6, 'ytick.labelsize':7.6,
        'legend.fontsize':6.7, 'axes.spines.top':False,
        'axes.spines.right':False, 'svg.fonttype':'none',
        'axes.linewidth':.8,
    })
    # Three rows are the sequential stages; columns are the two study cases.
    # The first two rows use equal data aspect so d_perp is visually orthogonal.
    fig,axs=plt.subplots(3,2,figsize=(8.2,10.25))
    fig.subplots_adjust(left=.12,right=.985,top=.91,bottom=.105,
                        hspace=.46,wspace=.31)
    alpha_color='#2868A8'
    rho_color='#2A8177'
    chord_color='#7A838D'
    select_color='#F1C453'
    distance_color='#B23A32'
    for col,d in enumerate(case_data):
        name=d['spec']['name']
        case_title='IEEE30' if name=='IEEE30' else 'Shelby County'
        selected_alpha=d['selected_alpha']
        selected_rho=d['selected_rho']
        alpha_data=d['alpha_data']
        rho_data=d['rho_data']
        panel_letter='a' if col==0 else 'b'

        # Stage 1: discrete alpha candidates in the normalized coordinates
        # used by the endpoint-chord selection rule.
        ax=axs[0,col]
        alpha_sorted=sorted(alpha_data,key=lambda p:p['norm_x'])
        ax.plot([p['norm_x'] for p in alpha_sorted],[p['norm_y'] for p in alpha_sorted],
                color=alpha_color,marker='o',lw=1.65,ms=4.8,zorder=2)
        chosen=next(p for p in alpha_sorted if p['selected'])
        a,b,pstar,q,dcalc=chord_projection(alpha_sorted,'norm_x','norm_y',chosen)
        stored=max(p['chord_d'] for p in alpha_sorted)
        if abs(dcalc-stored)>1e-6:
            raise RuntimeError(f'{name} alpha chord mismatch: {dcalc} vs {stored}')
        ax.plot([a[0],b[0]],[a[1],b[1]],color=chord_color,lw=1.0,ls=(0,(4,2)),zorder=1)
        ax.plot([pstar[0],q[0]],[pstar[1],q[1]],color=distance_color,lw=1.2,
                ls=(0,(2,2)),zorder=4)
        ax.scatter([pstar[0]],[pstar[1]],marker='*',s=125,facecolor=select_color,
                   edgecolor='#303944',linewidth=.7,zorder=6)
        ax.scatter([q[0]],[q[1]],marker='x',s=24,color=distance_color,linewidth=1.1,zorder=6)
        offsets=[(5,7),(7,9),(5,7),(5,7),(-30,-14)]
        for j,pt in enumerate(alpha_sorted):
            label=f"{pt['alpha']:.2f}" + (' *' if pt['selected'] else '')
            ax.annotate(label,(pt['norm_x'],pt['norm_y']),xytext=offsets[j],
                        textcoords='offset points',fontsize=7.5,color='#354252',
                        fontweight='bold' if pt['selected'] else 'normal')
        ax.text(.98,.96,
                f"selected α = {selected_alpha:g}\n" + r"$d_\perp$ = " + f"{dcalc:.3f}",
                transform=ax.transAxes,ha='right',va='top',fontsize=7.6,color='#354252',
                bbox=dict(boxstyle='round,pad=.25',facecolor='white',edgecolor='#D9DEE4',alpha=.96))
        ax.set_xlabel('Normalized warning-window burden (–)')
        ax.set_ylabel('Normalized mean active ENS (–)')
        ax.set_xlim(-.08,1.13);ax.set_ylim(-.08,1.13)
        ax.set_aspect('equal',adjustable='box')
        ax.grid(True,color='#E2E8EC',lw=.65);ax.set_axisbelow(True)
        ax.set_title(f'({panel_letter}1)', loc='left',fontweight='bold',pad=6)

        # Stage 2: group coincident objective-space points. The callout records
        # both the number of discrete Pareto candidates and plotted locations.
        ax=axs[1,col]
        groups=group_duplicate_front_points(rho_data)
        groups.sort(key=lambda q:(q['x'],q['y']))
        ax.plot([g['x'] for g in groups],[g['y'] for g in groups],
                color=rho_color,lw=1.5,alpha=.95,zorder=2)
        selected_pt=next(p for p in rho_data if p['selected'])
        ra,rb,rp,rq,rdcalc=chord_projection(rho_data,'x','y',selected_pt)
        rstored=max(p['chord_d'] for p in rho_data)
        if abs(rdcalc-rstored)>1e-6:
            raise RuntimeError(f'{name} rho chord mismatch: {rdcalc} vs {rstored}')
        ax.plot([ra[0],rb[0]],[ra[1],rb[1]],color=chord_color,lw=1.0,ls=(0,(4,2)),zorder=1)
        ax.plot([rp[0],rq[0]],[rp[1],rq[1]],color=distance_color,lw=1.2,
                ls=(0,(2,2)),zorder=4)
        for g in groups:
            ax.scatter([g['x']],[g['y']],s=34,color=rho_color,zorder=3)
            if g['selected']:
                ax.scatter([g['x']],[g['y']],marker='*',s=132,facecolor=select_color,
                           edgecolor='#303944',linewidth=.7,zorder=7)
        ax.scatter([rq[0]],[rq[1]],marker='x',s=24,color=distance_color,linewidth=1.1,zorder=6)
        ax.text(.035,.96,
                f"selected ρ = {selected_rho:g}\n" + r"$d_\perp$ = " + f"{rdcalc:.3f}\n"
                f"{len(rho_data)} candidates / {len(groups)} points",
                transform=ax.transAxes,ha='left',va='top',fontsize=7.6,color='#354252',
                bbox=dict(boxstyle='round,pad=.25',facecolor='white',edgecolor='#D9DEE4',alpha=.96))
        ax.set_xlabel('Normalized mean active ENS (–)')
        ax.set_ylabel('Normalized cost-proxy improvement (–)')
        ax.set_xlim(-.08,1.13);ax.set_ylim(-.08,1.13)
        ax.set_aspect('equal',adjustable='box')
        ax.grid(True,color='#E3E8ED',lw=.65);ax.set_axisbelow(True)
        ax.set_title(f'({panel_letter}2)', loc='left',fontweight='bold',pad=6)

        # Stage 3: common-scale reduction relative to the passive baseline.
        # Exact ENS values remain in Table 4; non-zero near-100% reductions are
        # labeled with enough precision not to imply an exact zero.
        ax=axs[2,col]
        strategies=('PA','SP','DP')
        pa_ens=metrics[name]['PA']['ens_mwh']
        reductions=[]
        for strategy in strategies:
            ens=metrics[name][strategy]['ens_mwh']
            if strategy=='PA':
                reductions.append(0.0)
            elif pa_ens > 0:
                reductions.append(float(np.clip(100.0*(1.0-ens/pa_ens),0.0,100.0)))
            else:
                reductions.append(0.0)
        yloc=np.arange(len(strategies))
        bars=ax.barh(yloc,reductions,height=.57,
                     color=[COLORS[s] for s in strategies],edgecolor='white',linewidth=.7)
        ax.set_yticks(yloc,strategies)
        ax.invert_yaxis()
        ax.set_xlim(0,112)
        ax.set_xticks([0,25,50,75,100])
        ax.set_xlabel('ENS reduction relative to PA (%)')
        ax.axvline(100,color='#C0C9CF',lw=.8,ls=':',zorder=0)
        for strategy,bar,v in zip(strategies,bars,reductions):
            y=bar.get_y()+bar.get_height()/2
            ens=metrics[name][strategy]['ens_mwh']
            label='>99.999%' if strategy=='DP' and ens<1e-6 else (f'{v:.2f}%' if 99.9 < v < 100.0 else f'{v:.1f}%')
            if v>=88:
                ax.text(v-2.0,y,label,ha='right',va='center',fontsize=7.8,
                        color='white',fontweight='bold')
            else:
                ax.text(max(v+2.0,2.0),y,label,ha='left',va='center',fontsize=7.8,
                        color='#303944',fontweight='bold')
        ax.grid(axis='x',color='#E3E8ED',lw=.65);ax.set_axisbelow(True)
        ax.set_title(f'({panel_letter}3)', loc='left',fontweight='bold',pad=6)

    geometry_handles=[
        Line2D([0],[0],color=alpha_color,lw=1.5,marker='o',ms=3.8,label='Candidates / front'),
        Line2D([0],[0],color=chord_color,lw=1.0,ls=(0,(4,2)),label='Endpoint chord'),
        Line2D([0],[0],color=distance_color,lw=1.15,ls=(0,(2,2)),marker='x',ms=3.5,
               label=r'$d_{\perp}$ to chord'),
        Line2D([0],[0],color='#303944',lw=0,marker='*',markersize=8,
               markerfacecolor=select_color,label='Selected point'),
    ]
    # The common geometric key is repeated inside each case's Stage-2 panel;
    # no figure-level legend or descriptive panel titles are used.
    fig.canvas.draw()
    for col,d in enumerate(case_data):
        axs[1,col].legend(handles=geometry_handles,loc='lower right',ncol=1,
                          frameon=False,borderpad=.15,labelspacing=.25,
                          handlelength=1.4,fontsize=6.3)
        pos=axs[0,col].get_position()
        case_title=d['spec']['name']
        fig.text((pos.x0+pos.x1)/2,pos.y1+.018,case_title,
                 ha='center',va='bottom',fontsize=9.0,fontweight='bold',
                 family=FIG_FONT)
    fig.savefig(OUT_PNG,dpi=360,bbox_inches='tight',facecolor='white')
    fig.savefig(OUT_SVG,bbox_inches='tight',facecolor='white')
    enforce_times_new_roman(OUT_SVG)
    plt.close(fig)


def main():
    metrics=read_fig5_metrics()
    case_data=[]
    for spec in CASES:
        a,r,alpha_rows,rho_rows=read_case_pareto(spec)
        case_data.append(dict(spec=spec,selected_alpha=a,selected_rho=r,
                              alpha_data=alpha_rows,rho_data=rho_rows))
    write_data_csv(case_data,metrics)
    make_figure(case_data,metrics)
    for d in case_data:
        alpha_d=max(p['chord_d'] for p in d['alpha_data'])
        rho_d=max(p['chord_d'] for p in d['rho_data'])
        print(d['spec']['name'],f"selected alpha={d['selected_alpha']:.3f} (d⊥max={alpha_d:.6f}); "
              f"selected rho={d['selected_rho']:.3f} (d⊥max={rho_d:.6f}); "
              f"alpha candidates={len(d['alpha_data'])}; rho Pareto candidates={len(d['rho_data'])}")
        for strategy in ('PA','SP','DP'):
            m=metrics[d['spec']['name']][strategy]
            print(f"  {strategy}: ENS={m['ens_mwh']:.6f} MWh; normalized={m['normalized_ens_pct']:.6f}% of demand-energy")
    print('Wrote',OUT_PNG);print('Wrote',OUT_SVG);print('Wrote',OUT_CSV)

if __name__=='__main__':
    main()
