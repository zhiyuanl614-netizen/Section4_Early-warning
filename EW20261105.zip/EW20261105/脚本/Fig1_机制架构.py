#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Nature/Elsevier Figure 1 — mechanism architecture (editable SVG + manuscript PNG).

Choices (research-assistant defaults):
  - stacked (a) over (b), double-column 183 mm
  - cleaned component icons from 图件/组件图标 (black bg → transparent)
  - palette aligned with Figures 2/4–7
  - replace manuscript PNG after QA
"""
from __future__ import annotations

import base64
import io
import math
import subprocess
import sys
from dataclasses import dataclass
from html import escape
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
ICON_DIR = ROOT / "图件" / "组件图标"
ICON_CACHE = ROOT / "图件" / "组件图标_transparent"
QA_DIR = ROOT / "结果" / "QA"
PNG_OUT = ROOT / "Fig1_Cooling_Water_Mechanism_Architecture_v2.2.png"
SVG_OUT = ROOT / "Fig1_Editable_Vector.svg"
PDF_OUT = QA_DIR / "Fig1_Cooling_Water_Mechanism_Architecture.pdf"

# Canvas in user units; mapped to 183 mm wide (1 uu ≈ 0.288 pt)
# Taller canvas: icon-above-label cards need vertical room (Elsevier double-column OK)
W, H = 1800, 1280
WIDTH_MM = 183.0
HEIGHT_MM = WIDTH_MM * H / W
UU_TO_PT = (WIDTH_MM * 72.0 / 25.4) / W  # ≈ 0.288

# Target print sizes → user units
def uu(pt: float) -> float:
    return pt / UU_TO_PT


# Unified semantic palette (match Figs 2/4–7)
C = {
    "navy": "#1B365D",
    "blue": "#1F5A92",
    "blue_light": "#E8F0F7",
    "teal": "#1E7F74",
    "teal_light": "#E6F4F2",
    "amber": "#C47A2C",
    "amber_light": "#F8EFE4",
    "green": "#2F6B3A",
    "purple": "#5B4B8A",
    "purple_light": "#F0EDF6",
    "red": "#B33A3A",
    "grey": "#4A5868",
    "grey_light": "#F3F5F7",
    "ink": "#1B365D",
    "muted": "#4A5868",
    "white": "#FFFFFF",
    "black": "#1B365D",
}

ASSETS = {
    "water": "01_Water_Source.png",
    "basin": "02_Cooling_Basin.png",
    "pump": "03_Circulating_Pump.png",
    "coil": "04_Condenser.png",
    "tower": "05_Cooling_Tower.png",
    "generator": "06_Turbine_Generator.png",
    "grid": "07_Transmission_Tower.png",
    "clipboard": "08_Measurement_Checklist.png",
    "controller": "09_Field_IO_Controller.png",
    "monitor": "10_Plant_HMI.png",
    "calculator": "11_AET_Calculator.png",
    "person": "12_Plant_Operator.png",
    "sliders": "13_Control_Logic_Panel.png",
    "valves": "14_Control_Valve.png",
    "fan": "15_Cooling_Tower_Fan.png",
    "chart": "16_Unit_Capability_Chart.png",
    "building": "17_Balancing_Authority_Control_Center.png",
    "gauge": "18_Analog_Gauge.png",
}


@dataclass
class Item:
    kind: str
    args: dict


class Scene:
    def __init__(self, name: str, width: int = W, height: int = H):
        self.name = name
        self.width = width
        self.height = height
        self.items: list[Item] = []
        self._n = 0

    def _id(self, prefix: str) -> str:
        self._n += 1
        return f"{self.name}_{prefix}_{self._n:03d}"

    def rect(self, x, y, w, h, *, fill="white", stroke="navy", sw=2,
             radius=12, dash=None, name=None):
        self.items.append(Item("rect", dict(
            x=x, y=y, w=w, h=h, fill=fill, stroke=stroke, sw=sw,
            radius=radius, dash=dash, id=name or self._id("rect"))))

    def image(self, x, y, w, h, path, *, name=None):
        self.items.append(Item("image", dict(
            x=x, y=y, w=w, h=h, path=str(path), id=name or self._id("image"))))

    def line(self, pts, *, color="navy", sw=3, dash=None, arrow=False, name=None):
        self.items.append(Item("line", dict(
            pts=pts, color=color, sw=sw, dash=dash, arrow=arrow,
            id=name or self._id("line"))))

    def text(self, x, y, w, h, lines: str | Iterable[str], *, size=6.0,
             color="ink", bold=False, italic=False, align="left", valign="top",
             family="Times New Roman", name=None, margin=0):
        """size is final print size in points."""
        if isinstance(lines, str):
            lines = lines.split("\n")
        self.items.append(Item("text", dict(
            x=x, y=y, w=w, h=h, lines=list(lines), size=size, color=color,
            bold=bold, italic=italic, align=align, valign=valign,
            family=family, id=name or self._id("text"), margin=margin)))

    def panel_title(self, x, y, tag: str, title: str, w: float = 1720,
                    name: str = "panel_title"):
        """Top-left (a)/(b) + full panel title (not tag-only)."""
        self.text(x, y, 48, 30, tag, size=8.5, color="navy", bold=True,
                  align="left", valign="middle", name=f"{name}_tag")
        self.text(x + 48, y, w - 48, 30, title, size=7.5, color="navy",
                  bold=True, align="left", valign="middle", name=f"{name}_text")


def svg_color(color: str) -> str:
    return C.get(color, color)


def hex_rgb(color: str) -> tuple[int, int, int]:
    h = svg_color(color).lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def clean_icon(src: Path, dst: Path) -> Path:
    """Remove near-black backdrop and crop to content."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() and dst.stat().st_mtime >= src.stat().st_mtime:
        return dst
    im = Image.open(src).convert("RGBA")
    px = im.load()
    w, h = im.size
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if a == 0:
                continue
            # Near-black studio backdrop → transparent
            if r < 28 and g < 28 and b < 28:
                px[x, y] = (0, 0, 0, 0)
            # Near-white fringe cleanup optional — keep pale icon fills
    # Crop to non-transparent content
    alpha = im.split()[-1]
    bbox = alpha.getbbox()
    if bbox:
        pad = 6
        l, t, r, b = bbox
        im = im.crop((max(0, l - pad), max(0, t - pad),
                      min(w, r + pad), min(h, b + pad)))
    im.save(dst, "PNG", optimize=True)
    return dst


def icon_path(kind: str) -> Path:
    if kind not in ASSETS:
        raise KeyError(kind)
    src = ICON_DIR / ASSETS[kind]
    dst = ICON_CACHE / ASSETS[kind]
    return clean_icon(src, dst)


def add_icon(s: Scene, kind: str, x: float, y: float, w: float, h: float, name: str):
    s.image(x, y, w, h, icon_path(kind), name=name)


def add_card(
    s: Scene,
    x: float,
    y: float,
    w: float,
    h: float,
    title: str,
    icon: str,
    *,
    fill: str,
    stroke: str,
    name: str,
    icon_px: float = 58,
    title_size: float = 6.0,
    title_color: str | None = None,
    sw: float = 2.0,
    extra_icons: list[tuple[str, float, float, float, float]] | None = None,
):
    # Icon-above-label card — large pictogram, title in a clear band below.
    s.rect(x, y, w, h, fill=fill, stroke=stroke, sw=sw, radius=12, name=f"{name}_box")
    ix = x + (w - icon_px) / 2
    iy = y + 10
    add_icon(s, icon, ix, iy, icon_px, icon_px, f"{name}_icon")
    if extra_icons:
        for ek, ex, ey, ew, eh in extra_icons:
            add_icon(s, ek, x + ex, y + ey, ew, eh, f"{name}_x_{ek}")
    ty = iy + icon_px + 4
    s.text(
        x + 6, ty, w - 12, max(28.0, y + h - ty - 6), title,
        size=title_size, color=title_color or "navy", bold=True,
        align="center", valign="middle", name=f"{name}_title",
    )


def make_fig1() -> Scene:
    # Roomy icon-above-label architecture; narrative notes live in the caption.
    s = Scene("Figure_1")

    # ---- Panel (a) ----
    s.panel_title(
        20, 10, "(a)",
        "Physical cooling-water loop and performance coupling",
        name="f1_panel_a",
    )

    n = 7
    margin_l, margin_r, gap = 48, 48, 22
    usable = W - margin_l - margin_r - gap * (n - 1)
    card_w = usable / n
    node_y, node_h = 64, 168
    kinds = [
        ("Make-up water\nsource", "water", "blue_light", "navy"),
        ("Cooling-tower\nbasin", "basin", "blue_light", "navy"),
        ("Circulating-\nwater pump", "pump", "blue_light", "navy"),
        ("Condenser", "coil", "blue_light", "navy"),
        ("Cooling tower", "tower", "blue_light", "navy"),
        ("Turbine–\ngenerator", "generator", "amber_light", "amber"),
        ("Electrical\ngrid", "grid", "blue_light", "navy"),
    ]
    xs = [margin_l + i * (card_w + gap) for i in range(n)]
    for (title, kind, fill, stroke), x in zip(kinds, xs):
        add_card(
            s, x, node_y, card_w, node_h, title, kind,
            fill=fill, stroke=stroke, name=f"f1a_{kind}",
            icon_px=78, title_size=6.2,
        )

    # Connectors run in the title band BELOW icons (never through pictograms)
    gap_y = node_y + 10 + 78 + 22

    def edge_right(i):
        return xs[i] + card_w

    def edge_left(i):
        return xs[i]

    m0, m1 = edge_right(0), edge_left(1)
    mid = (m0 + m1) / 2
    s.line([(m0, gap_y), (mid - 8, gap_y)], color="blue", sw=3.4, name="f1a_mu_l")
    s.line([(mid + 8, gap_y), (m1, gap_y)], color="blue", sw=3.4, arrow=True, name="f1a_mu_r")
    s.line([(mid - 7, gap_y - 12), (mid, gap_y), (mid - 7, gap_y + 12),
            (mid + 7, gap_y - 12), (mid, gap_y), (mid + 7, gap_y + 12)],
           color="red", sw=3.2, name="f1a_interrupt_z")

    for i, nm in [(1, "basin_pump"), (2, "pump_cond"), (3, "cond_tower")]:
        s.line([(edge_right(i), gap_y), (edge_left(i + 1), gap_y)],
               color="blue", sw=3.4, arrow=True, name=f"f1a_flow_{nm}")

    # E/B/D in the strip between panel title (~y40) and tower card top
    tower_cx = xs[4] + card_w / 2
    for dx, lab in [(-30, "E"), (0, "B"), (30, "D")]:
        x = tower_cx + dx
        s.text(x - 10, 42, 20, 16, lab, size=5.6, color="grey", bold=True,
               align="center", valign="middle", name=f"f1a_loss_label_{lab}")
        s.line([(x, node_y), (x, 58)], color="grey", sw=2.0, arrow=True,
               name=f"f1a_loss_{lab}")

    ret_y = node_y + node_h + 36
    basin_cx = xs[1] + card_w / 2
    tower_bot_x = xs[4] + card_w / 2
    s.line([(tower_bot_x, node_y + node_h), (tower_bot_x, ret_y),
            (basin_cx, ret_y), (basin_cx, node_y + node_h)],
           color="blue", sw=3.2, arrow=True, name="f1a_return")

    bp_y = ret_y + 38
    cond_cx = xs[3] + card_w / 2
    gen_cx = xs[5] + card_w / 2
    s.line([(cond_cx, node_y + node_h), (cond_cx, bp_y),
            (gen_cx, bp_y), (gen_cx, node_y + node_h)],
           color="amber", sw=2.8, dash="8 6", arrow=True, name="f1a_backpressure")

    s.line([(edge_right(5), gap_y), (edge_left(6), gap_y)],
           color="green", sw=3.4, arrow=True, name="f1a_pg")

    causal = [
        "Usable basin\nwater ↓",
        "Pump flow ↓",
        "Heat rejection ↓",
        "Backpressure ↑",
        "Available unit\noutput ↓",
    ]
    cy = bp_y + 34
    c_gap = 28
    c_w = (W - margin_l - margin_r - c_gap * 4) / 5
    cxs = [margin_l + i * (c_w + c_gap) for i in range(5)]
    for i, (x, txt) in enumerate(zip(cxs, causal)):
        s.rect(x, cy, c_w, 58, fill="white", stroke="navy", sw=1.8, radius=9,
               name=f"f1a_causal_{i}")
        s.text(x + 8, cy + 6, c_w - 16, 46, txt, size=6.1, color="ink", bold=True,
               align="center", valign="middle", name=f"f1a_causal_t_{i}")
        if i < 4:
            s.line([(x + c_w, cy + 29), (cxs[i + 1], cy + 29)], color="navy",
                   sw=2.2, arrow=True, name=f"f1a_causal_a_{i}")

    div_y = cy + 84
    s.line([(40, div_y), (1760, div_y)], color="grey", sw=1.3, name="f1_divider")

    # ---- Panel (b) ----
    s.panel_title(
        20, div_y + 14, "(b)",
        "Conceptual sensing, warning and control pathway",
        name="f1_panel_b",
    )

    row_y = div_y + 56
    sense_n = 5
    s_gap = 26
    s_usable = W - margin_l - margin_r - s_gap * (sense_n - 1)
    s_w = s_usable / sense_n
    s_h = 168
    sense = [
        ("Candidate\nmeasurements", "clipboard"),
        ("Field I/O /\nlocal controller", "controller"),
        ("Plant automation\n& operator HMI", "monitor"),
        ("AET estimator", "calculator"),
        ("Plant operator /\ndecision", "person"),
    ]
    sxs = [margin_l + i * (s_w + s_gap) for i in range(sense_n)]
    for i, ((title, icon), x) in enumerate(zip(sense, sxs)):
        add_card(
            s, x, row_y, s_w, s_h, title, icon,
            fill="teal_light", stroke="teal",
            name=f"f1b_sense_{i}",
            icon_px=76, title_size=6.2,
            title_color="teal" if icon == "calculator" else "navy",
            sw=2.6 if icon == "calculator" else 2.0,
        )
    sig_y = row_y + 10 + 76 + 22
    for i, nm in enumerate(["m_io", "io_hmi", "hmi_aet", "aet_op"]):
        s.line([(sxs[i] + s_w, sig_y), (sxs[i + 1], sig_y)],
               color="teal", sw=2.6, dash="6 5", arrow=True, name=f"f1b_sig_{nm}")

    hdr_y = row_y + s_h + 24
    box_top = hdr_y + 30
    s.text(margin_l, hdr_y, 520, 24, "Local cooling-water action", size=6.6,
           color="purple", bold=True, align="left", valign="middle",
           name="f1b_local_h")
    s.text(700, hdr_y, 700, 24, "Proposed plant–grid interface", size=6.6,
           color="purple", bold=True, align="left", valign="middle",
           name="f1b_proposed_h")

    op_cx = sxs[4] + s_w / 2
    s.line([(op_cx, row_y + s_h), (op_cx, box_top)], color="purple", sw=2.4,
           arrow=True, name="f1b_op_drop")

    local = [
        ("Operator-authorized\ninstruction", "person"),
        ("Existing plant\ncontrol logic", "sliders"),
        ("Valves / pumps /\ntower fans", "valves"),
    ]
    loc_n = 3
    loc_gap = 22
    loc_span = 640
    loc_w = (loc_span - loc_gap * (loc_n - 1)) / loc_n
    loc_h = 168
    lxs = [margin_l + i * (loc_w + loc_gap) for i in range(loc_n)]
    for i, ((title, icon), x) in enumerate(zip(local, lxs)):
        add_card(
            s, x, box_top, loc_w, loc_h, title, icon,
            fill="purple_light", stroke="purple", name=f"f1b_loc_{i}",
            icon_px=72, title_size=5.9,
        )
    loc_conn_y = box_top + 10 + 72 + 22
    for i, nm in enumerate(["loc_a1", "loc_a2"]):
        s.line([(lxs[i] + loc_w, loc_conn_y), (lxs[i + 1], loc_conn_y)],
               color="purple", sw=2.6, arrow=True, name=f"f1b_{nm}")

    prop_x = 720
    prop_w = W - margin_r - prop_x
    prop_pad = 16
    s.rect(prop_x, box_top, prop_w, loc_h + 2 * prop_pad, fill="white",
           stroke="purple", sw=2.4, radius=12, dash="9 7", name="f1b_proposed")

    lane = [
        ("Plant capability\nreport", "chart"),
        ("Balancing Authority\n/ ISO–RTO", "building"),
        ("Unit load\ncontroller", "gauge"),
        ("Turbine–\ngenerator", "generator"),
        ("Electrical\ngrid", "grid"),
    ]
    g_n = 5
    g_gap = 14
    g_inner = prop_w - 2 * prop_pad - g_gap * (g_n - 1)
    g_w = g_inner / g_n
    g_h = loc_h
    gy = box_top + prop_pad
    gxs = [prop_x + prop_pad + i * (g_w + g_gap) for i in range(g_n)]
    for i, ((title, icon), x) in enumerate(zip(lane, gxs)):
        fill = "blue_light" if i == 4 else "purple_light"
        stroke = "navy" if i == 4 else "purple"
        add_card(
            s, x, gy, g_w, g_h, title, icon,
            fill=fill, stroke=stroke, name=f"f1b_grid_{i}",
            icon_px=68, title_size=5.7,
        )
    gmid = gy + 10 + 68 + 22
    for i, nm in enumerate(["c_ba", "ba_ld", "ld_tg", "tg_g"]):
        s.line([(gxs[i] + g_w, gmid), (gxs[i + 1], gmid)],
               color="purple", sw=2.4, arrow=True, name=f"f1b_disp_{nm}")

    tele_y = box_top + 7
    gen_top = gxs[3] + g_w / 2
    ba_top = gxs[1] + g_w / 2
    s.line([(gen_top, gy), (gen_top, tele_y), (ba_top, tele_y), (ba_top, gy)],
           color="teal", sw=2.0, dash="6 5", arrow=True, name="f1b_telemetry")

    leg_y = box_top + loc_h + 2 * prop_pad + 30
    leg1 = [
        (48, "blue", None, "Physical water flow"),
        (360, "amber", "8 6", "Backpressure effect"),
        (680, "green", None, "Electrical output"),
        (980, "teal", "6 5", "Telemetry"),
        (1240, "purple", None, "Warning / set-point"),
    ]
    for i, (x, col, dash, lab) in enumerate(leg1):
        s.line([(x, leg_y + 10), (x + 44, leg_y + 10)], color=col, sw=2.6,
               dash=dash, arrow=True, name=f"f1_leg1_{i}")
        s.text(x + 54, leg_y, 240, 22, lab, size=5.4, color="ink",
               valign="middle", name=f"f1_leg1_t_{i}")

    leg2_y = leg_y + 36
    s.line([(48, leg2_y + 2), (56, leg2_y + 12), (48, leg2_y + 22),
            (60, leg2_y + 2), (56, leg2_y + 12), (60, leg2_y + 22)],
           color="red", sw=2.6, name="f1_leg_z")
    s.text(74, leg2_y, 280, 22, "Make-up interruption", size=5.4, color="ink",
           valign="middle", name="f1_leg_z_t")
    s.rect(380, leg2_y + 2, 48, 16, fill="white", stroke="purple", sw=1.8,
           radius=3, dash="6 4", name="f1_leg_box")
    s.text(440, leg2_y, 520, 22, "Proposed interface (not simulated)",
           size=5.4, color="ink", valign="middle", name="f1_leg_box_t")
    s.text(1000, leg2_y, 360, 22, "E / B / D: evap. / blowdown / drift",
           size=5.3, color="muted", valign="middle", name="f1_leg_ebd")

    return s

def svg_text(item: Item) -> str:
    a = item.args
    lines = a["lines"]
    size_uu = uu(a["size"])
    align = {"left": "start", "center": "middle", "right": "end"}[a["align"]]
    if align == "start":
        tx = a["x"] + a["margin"]
    elif align == "end":
        tx = a["x"] + a["w"] - a["margin"]
    else:
        tx = a["x"] + a["w"] / 2
    line_h = size_uu * 1.25
    if a["valign"] == "middle":
        total_h = len(lines) * line_h
        first = a["y"] + max(size_uu, (a["h"] - total_h) / 2 + size_uu * 0.85)
    else:
        first = a["y"] + size_uu
    spans = []
    for i, line in enumerate(lines):
        spans.append(
            f'<tspan x="{tx:g}" y="{first + i * line_h:g}">{escape(str(line))}</tspan>'
        )
    weight = "700" if a["bold"] else "400"
    style = "italic" if a["italic"] else "normal"
    return (
        f'<text id="{a["id"]}" x="{tx:g}" y="{first:g}" text-anchor="{align}" '
        f'font-family="{escape(a["family"])}" font-size="{size_uu:g}" '
        f'font-weight="{weight}" font-style="{style}" '
        f'fill="{svg_color(a["color"])}">{"".join(spans)}</text>'
    )


def scene_to_svg(scene: Scene, path: Path) -> None:
    markers = []
    for name, col in [("blue", "blue"), ("amber", "amber"), ("teal", "teal"),
                      ("green", "green"), ("purple", "purple"), ("navy", "navy"),
                      ("grey", "grey"), ("red", "red"), ("black", "navy")]:
        markers.append(
            f'<marker id="arrow-{name}" viewBox="0 0 10 10" refX="8" refY="5" '
            f'markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
            f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{C[col]}"/></marker>'
        )
    parts = [f'''<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
 width="{WIDTH_MM:.3f}mm" height="{HEIGHT_MM:.3f}mm"
 viewBox="0 0 {scene.width} {scene.height}">
<title>Figure 1 — cooling-water mechanism architecture</title>
<desc>Physical cooling-water loop and conceptual sensing–AET–plant–grid pathway. Editable vector schematic.</desc>
<defs>
{chr(10).join(markers)}
</defs>
<rect id="canvas-background" width="100%" height="100%" fill="#FFFFFF"/>
''']
    marker = {k: f"arrow-{k}" for k in
              ("blue", "amber", "teal", "green", "purple", "navy", "grey", "red", "black")}
    for item in scene.items:
        a = item.args
        if item.kind == "rect":
            dash = f' stroke-dasharray="{a["dash"]}"' if a["dash"] else ""
            parts.append(
                f'<rect id="{a["id"]}" x="{a["x"]}" y="{a["y"]}" width="{a["w"]}" '
                f'height="{a["h"]}" rx="{a["radius"]}" fill="{svg_color(a["fill"])}" '
                f'stroke="{svg_color(a["stroke"])}" stroke-width="{a["sw"]}"{dash}/>'
            )
        elif item.kind == "image":
            b64 = base64.b64encode(Path(a["path"]).read_bytes()).decode("ascii")
            parts.append(
                f'<image id="{a["id"]}" x="{a["x"]}" y="{a["y"]}" width="{a["w"]}" '
                f'height="{a["h"]}" preserveAspectRatio="xMidYMid meet" '
                f'href="data:image/png;base64,{b64}"/>'
            )
        elif item.kind == "line":
            points = " ".join(f"{x},{y}" for x, y in a["pts"])
            dash = f' stroke-dasharray="{a["dash"]}"' if a["dash"] else ""
            end = f' marker-end="url(#{marker[a["color"]]})"' if a["arrow"] else ""
            parts.append(
                f'<polyline id="{a["id"]}" points="{points}" fill="none" '
                f'stroke="{svg_color(a["color"])}" stroke-width="{a["sw"]}" '
                f'stroke-linecap="round" stroke-linejoin="round"{dash}{end}/>'
            )
        else:
            parts.append(svg_text(item))
    parts.append("</svg>")
    path.write_text("\n".join(parts), encoding="utf-8")


def _font(size_pt: float, bold: bool = False, italic: bool = False):
    # PIL pixel size at export DPI: size_pt * dpi/72
    dpi = 450
    px = max(8, int(round(size_pt * dpi / 72)))
    candidates = []
    if bold and italic:
        candidates = [r"C:\Windows\Fonts\timesbi.ttf"]
    elif bold:
        candidates = [r"C:\Windows\Fonts\timesbd.ttf"]
    elif italic:
        candidates = [r"C:\Windows\Fonts\timesi.ttf"]
    else:
        candidates = [r"C:\Windows\Fonts\times.ttf"]
    for p in candidates:
        if Path(p).exists():
            return ImageFont.truetype(p, px)
    return ImageFont.load_default()


def scene_to_png(scene: Scene, path: Path, dpi: int = 450) -> None:
    """Rasterize scene at final physical size for manuscript embedding."""
    px_w = int(round(WIDTH_MM / 25.4 * dpi))
    px_h = int(round(HEIGHT_MM / 25.4 * dpi))
    sx = px_w / scene.width
    sy = px_h / scene.height
    im = Image.new("RGB", (px_w, px_h), "white")
    draw = ImageDraw.Draw(im)

    def X(x): return x * sx
    def Y(y): return y * sy

    for item in scene.items:
        a = item.args
        if item.kind == "rect":
            box = [X(a["x"]), Y(a["y"]), X(a["x"] + a["w"]), Y(a["y"] + a["h"])]
            r = max(1, int(a["radius"] * sx))
            fill = hex_rgb(a["fill"])
            stroke = hex_rgb(a["stroke"])
            sw = max(1, int(round(a["sw"] * sx)))
            if a["dash"]:
                # approximate dashed border: fill then outline segments
                draw.rounded_rectangle(box, radius=r, fill=fill, outline=stroke, width=sw)
            else:
                draw.rounded_rectangle(box, radius=r, fill=fill, outline=stroke, width=sw)
        elif item.kind == "image":
            icon = Image.open(a["path"]).convert("RGBA")
            tw, th = max(1, int(a["w"] * sx)), max(1, int(a["h"] * sy))
            icon = icon.resize((tw, th), Image.Resampling.LANCZOS)
            im.paste(icon, (int(X(a["x"])), int(Y(a["y"]))), icon)
        elif item.kind == "line":
            pts = [(X(x), Y(y)) for x, y in a["pts"]]
            col = hex_rgb(a["color"])
            sw = max(1, int(round(a["sw"] * sx)))
            if a["dash"]:
                # dashed polyline approximation
                for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
                    _dashed_line(draw, x1, y1, x2, y2, col, sw)
            else:
                draw.line(pts, fill=col, width=sw, joint="curve")
            if a["arrow"] and len(pts) >= 2:
                _arrowhead(draw, pts[-2], pts[-1], col, max(6, sw * 2))
        else:
            font = _font(a["size"], a["bold"], a["italic"])
            lines = a["lines"]
            # measure
            bbs = [draw.textbbox((0, 0), str(ln), font=font) for ln in lines]
            heights = [b[3] - b[1] for b in bbs]
            widths = [b[2] - b[0] for b in bbs]
            line_gap = max(2, int(a["size"] * dpi / 72 * 0.25))
            total_h = sum(heights) + line_gap * (len(lines) - 1)
            if a["valign"] == "middle":
                y0 = Y(a["y"]) + (a["h"] * sy - total_h) / 2
            else:
                y0 = Y(a["y"])
            for i, (ln, bw, bh, bb) in enumerate(zip(lines, widths, heights, bbs)):
                if a["align"] == "center":
                    x0 = X(a["x"]) + (a["w"] * sx - bw) / 2 - bb[0]
                elif a["align"] == "right":
                    x0 = X(a["x"] + a["w"]) - bw - bb[0]
                else:
                    x0 = X(a["x"]) + a["margin"] * sx - bb[0]
                draw.text((x0, y0 - bb[1]), str(ln), font=font, fill=hex_rgb(a["color"]))
                y0 += bh + line_gap

    path.parent.mkdir(parents=True, exist_ok=True)
    im.save(path, dpi=(dpi, dpi), optimize=True)
    # PDF snapshot for QA folder
    QA_DIR.mkdir(parents=True, exist_ok=True)
    im.save(PDF_OUT, "PDF", resolution=float(dpi))


def _dashed_line(draw, x1, y1, x2, y2, col, sw, on=10, off=7):
    dx, dy = x2 - x1, y2 - y1
    length = math.hypot(dx, dy) or 1.0
    ux, uy = dx / length, dy / length
    t = 0.0
    draw_on = True
    while t < length:
        seg = on if draw_on else off
        t2 = min(length, t + seg)
        if draw_on:
            draw.line([(x1 + ux * t, y1 + uy * t), (x1 + ux * t2, y1 + uy * t2)],
                      fill=col, width=sw)
        t = t2
        draw_on = not draw_on


def _arrowhead(draw, p0, p1, col, size):
    x0, y0 = p0
    x1, y1 = p1
    ang = math.atan2(y1 - y0, x1 - x0)
    left = (x1 - size * math.cos(ang - 0.4), y1 - size * math.sin(ang - 0.4))
    right = (x1 - size * math.cos(ang + 0.4), y1 - size * math.sin(ang + 0.4))
    draw.polygon([p1, left, right], fill=col)


def run_audit(svg_path: Path) -> int:
    audit = Path(
        r"C:\Users\995599\AppData\Local\Cursor\AgentStores"
        r"\cursor_agent_stores\u476440236\files\skills\nature-figure"
        r"\scripts\audit_svg_schematic.py"
    )
    # Elsevier double-column: allow headings slightly above 7 pt
    cmd = [sys.executable, str(audit), str(svg_path),
           "--min-pt", "5.0", "--max-pt", "8.0", "--max-width-mm", "183"]
    print("Running:", " ".join(cmd))
    return subprocess.call(cmd)


def main() -> int:
    ICON_CACHE.mkdir(parents=True, exist_ok=True)
    QA_DIR.mkdir(parents=True, exist_ok=True)
    # Pre-clean all icons used
    for kind in ASSETS:
        icon_path(kind)

    scene = make_fig1()
    scene_to_svg(scene, SVG_OUT)
    scene_to_png(scene, PNG_OUT, dpi=450)
    print(f"Wrote {SVG_OUT} ({SVG_OUT.stat().st_size:,} bytes)")
    print(f"Wrote {PNG_OUT} ({PNG_OUT.stat().st_size:,} bytes)")
    print(f"Wrote {PDF_OUT}")
    print(f"Print size: {WIDTH_MM:.1f} × {HEIGHT_MM:.1f} mm")
    return run_audit(SVG_OUT)


if __name__ == "__main__":
    raise SystemExit(main())
