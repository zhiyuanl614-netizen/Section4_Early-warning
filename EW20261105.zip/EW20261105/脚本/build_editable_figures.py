from __future__ import annotations

from dataclasses import dataclass
from html import escape
from pathlib import Path
from typing import Iterable
import base64
from PIL import Image

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT
W, H = 1800, 1200
SCALE = 120  # source canvas pixels per PowerPoint inch; 1800x1200 -> 15x10 in

# Prefer 脚本/Fig1_机制架构.py for the manuscript Figure 1 rebuild (Nature-unified).
# This module remains available for Figure 3 / PPTX editable exports.
C = {
    'navy': '#1B365D', 'blue': '#1F5A92', 'blue_light': '#E8F0F7',
    'teal': '#1E7F74', 'teal_light': '#E6F4F2', 'amber': '#C47A2C',
    'amber_light': '#F8EFE4', 'green': '#2F6B3A', 'purple': '#5B4B8A',
    'purple_light': '#F0EDF6', 'red': '#B33A3A', 'grey': '#4A5868',
    'grey_light': '#F3F5F7', 'ink': '#1B365D', 'muted': '#4A5868',
    'white': '#FFFFFF', 'black': '#1B365D',
}


def hx(v: str) -> str:
    return v.lstrip('#')


@dataclass
class Item:
    kind: str
    args: dict


class Scene:
    def __init__(self, name: str, width: int = W, height: int = H):
        self.name = name
        self.width = width
        self.height = height
        self.items: list[Item] = []
        self._n = 0

    def _id(self, prefix: str) -> str:
        self._n += 1
        return f'{self.name}_{prefix}_{self._n:03d}'

    def rect(self, x, y, w, h, *, fill='white', stroke='navy', sw=2,
             radius=14, dash=None, name=None):
        self.items.append(Item('rect', dict(x=x, y=y, w=w, h=h, fill=fill,
            stroke=stroke, sw=sw, radius=radius, dash=dash,
            id=name or self._id('rect'))))

    def ellipse(self, x, y, w, h, *, fill='white', stroke='navy', sw=2, name=None):
        self.items.append(Item('ellipse', dict(x=x,y=y,w=w,h=h,fill=fill,stroke=stroke,sw=sw,
            id=name or self._id('ellipse'))))

    def image(self, x, y, w, h, path, *, name=None):
        self.items.append(Item('image', dict(x=x,y=y,w=w,h=h,path=str(path),
            id=name or self._id('image'))))

    def line(self, pts, *, color='navy', sw=3, dash=None, arrow=False, name=None):
        self.items.append(Item('line', dict(pts=pts, color=color, sw=sw,
            dash=dash, arrow=arrow, id=name or self._id('line'))))

    def text(self, x, y, w, h, lines: str | Iterable[str], *, size=20,
             color='ink', bold=False, italic=False, align='left', valign='top',
             family='Times New Roman', name=None, margin=0):
        if isinstance(lines, str):
            lines = lines.split('\n')
        self.items.append(Item('text', dict(x=x, y=y, w=w, h=h,
            lines=list(lines), size=size, color=color, bold=bold, italic=italic,
            align=align, valign=valign, family=family,
            id=name or self._id('text'), margin=margin)))

    def box(self, x, y, w, h, title: str, body: str | Iterable[str] = (), *,
            fill='blue_light', stroke='navy', title_size=21, body_size=17,
            title_color='navy', body_color='ink', align='center', radius=15,
            title_h=34, body_y=37, name=None):
        ident = name or self._id('box')
        self.rect(x, y, w, h, fill=fill, stroke=stroke, sw=2, radius=radius,
                  name=ident + '_shape')
        self.text(x+10, y+7, w-20, title_h, title, size=title_size,
                  color=title_color, bold=True, align=align, valign='middle',
                  name=ident + '_title')
        if body:
            if isinstance(body, str):
                body = body.split('\n')
            self.text(x+12, y+body_y, w-24, h-body_y-7, body,
                      size=body_size, color=body_color, align=align,
                      valign='top', name=ident + '_body')

    def panel_heading(self, x, y, text, w=1700, name='heading'):
        self.text(x, y, w, 32, text, size=25, color='navy', bold=True,
                  align='center', valign='middle', name=name)


def svg_color(color: str) -> str:
    return C.get(color, color)


def svg_text(item: Item) -> str:
    a = item.args
    lines = a['lines']
    size = a['size']
    align = {'left': 'start', 'center': 'middle', 'right': 'end'}[a['align']]
    if align == 'start':
        tx = a['x'] + a['margin']
    elif align == 'end':
        tx = a['x'] + a['w'] - a['margin']
    else:
        tx = a['x'] + a['w']/2
    line_h = size * 1.22
    if a['valign'] == 'middle':
        total_h = len(lines) * line_h
        first_baseline = a['y'] + max(size, (a['h'] - total_h)/2 + size)
    else:
        first_baseline = a['y'] + size
    spans = []
    for i, line in enumerate(lines):
        spans.append(f'<tspan x="{tx:g}" y="{first_baseline+i*line_h:g}">{escape(str(line))}</tspan>')
    weight = '700' if a['bold'] else '400'
    style = 'italic' if a['italic'] else 'normal'
    return (f'<text id="{a["id"]}" x="{tx:g}" y="{first_baseline:g}" '
            f'text-anchor="{align}" font-family="{escape(a["family"])}" '
            f'font-size="{size}px" font-weight="{weight}" font-style="{style}" '
            f'fill="{svg_color(a["color"])}">{"".join(spans)}</text>')


def scene_to_svg(scene: Scene, path: Path):
    parts = [f'''<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
 width="{scene.width}" height="{scene.height}" viewBox="0 0 {scene.width} {scene.height}">
<title>{escape(scene.name.replace('_',' '))} — editable vector diagram</title>
<desc>Structured vector redraw with individually editable boxes, labels, arrows and connectors.</desc>
<defs>
 <marker id="arrow-blue" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="{C['blue']}"/></marker>
 <marker id="arrow-amber" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="{C['amber']}"/></marker>
 <marker id="arrow-teal" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="{C['teal']}"/></marker>
 <marker id="arrow-green" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="{C['green']}"/></marker>
 <marker id="arrow-purple" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="{C['purple']}"/></marker>
 <marker id="arrow-black" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="{C['black']}"/></marker>
 <marker id="arrow-grey" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="{C['grey']}"/></marker>
</defs>
<rect id="canvas-background" width="100%" height="100%" fill="#FFFFFF"/>
''']
    marker = {'blue':'arrow-blue','amber':'arrow-amber','teal':'arrow-teal',
              'green':'arrow-green','purple':'arrow-purple','black':'arrow-black',
              'grey':'arrow-grey'}
    for item in scene.items:
        a = item.args
        if item.kind == 'rect':
            dash = f' stroke-dasharray="{a["dash"]}"' if a['dash'] else ''
            parts.append(f'<rect id="{a["id"]}" x="{a["x"]}" y="{a["y"]}" width="{a["w"]}" height="{a["h"]}" rx="{a["radius"]}" fill="{svg_color(a["fill"])}" stroke="{svg_color(a["stroke"])}" stroke-width="{a["sw"]}"{dash}/>')
        elif item.kind == 'ellipse':
            parts.append(f'<ellipse id="{a["id"]}" cx="{a["x"]+a["w"]/2}" cy="{a["y"]+a["h"]/2}" rx="{a["w"]/2}" ry="{a["h"]/2}" fill="{svg_color(a["fill"])}" stroke="{svg_color(a["stroke"])}" stroke-width="{a["sw"]}"/>')
        elif item.kind == 'image':
            b64=base64.b64encode(Path(a['path']).read_bytes()).decode('ascii')
            parts.append(f'<image id="{a["id"]}" x="{a["x"]}" y="{a["y"]}" width="{a["w"]}" height="{a["h"]}" preserveAspectRatio="xMidYMid meet" href="data:image/png;base64,{b64}"/>')
        elif item.kind == 'line':
            points = ' '.join(f'{x},{y}' for x,y in a['pts'])
            dash = f' stroke-dasharray="{a["dash"]}"' if a['dash'] else ''
            end = f' marker-end="url(#{marker[a["color"]]})"' if a['arrow'] else ''
            parts.append(f'<polyline id="{a["id"]}" points="{points}" fill="none" stroke="{svg_color(a["color"])}" stroke-width="{a["sw"]}" stroke-linecap="round" stroke-linejoin="round"{dash}{end}/>')
        else:
            parts.append(svg_text(item))
    parts.append('</svg>')
    path.write_text('\n'.join(parts), encoding='utf-8')


def add_pptx_text(slide, a):
    shape = slide.shapes.add_textbox(Inches(a['x']/SCALE), Inches(a['y']/SCALE),
                                    Inches(a['w']/SCALE), Inches(a['h']/SCALE))
    shape.name = a['id'][:60]
    tf = shape.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.margin_left = Inches(a['margin']/SCALE)
    tf.margin_right = Inches(a['margin']/SCALE)
    tf.margin_top = Inches(0.01)
    tf.margin_bottom = Inches(0.01)
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE if a['valign'] == 'middle' else MSO_ANCHOR.TOP
    lines = a['lines']
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = str(line)
        p.alignment = {'left':PP_ALIGN.LEFT,'center':PP_ALIGN.CENTER,'right':PP_ALIGN.RIGHT}[a['align']]
        p.space_before = Pt(0)
        p.space_after = Pt(0)
        p.font.name = a['family']
        p.font.size = Pt(a['size'] * 72 / SCALE)
        p.font.bold = a['bold']
        p.font.italic = a['italic']
        p.font.color.rgb = RGBColor.from_string(hx(svg_color(a['color'])))
    return shape


def pptx_line(slide, x1, y1, x2, y2, color, sw, dash):
    sh = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,
        Inches(x1/SCALE), Inches(y1/SCALE), Inches(x2/SCALE), Inches(y2/SCALE))
    sh.line.color.rgb = RGBColor.from_string(hx(svg_color(color)))
    sh.line.width = Pt(sw * 72 / SCALE)
    if dash:
        sh.line.dash_style = MSO_LINE_DASH_STYLE.DASH
    return sh


def add_arrowhead(slide, x, y, dx, dy, color, size=12):
    tri = slide.shapes.add_shape(MSO_SHAPE.ISOSCELES_TRIANGLE,
        Inches((x-size)/SCALE), Inches((y-size)/SCALE),
        Inches((2*size)/SCALE), Inches((2*size)/SCALE))
    angle = 0 if (dx,dy)==(0,-1) else 180 if (dx,dy)==(0,1) else 90 if (dx,dy)==(1,0) else 270
    tri.rotation = angle
    tri.fill.solid()
    tri.fill.fore_color.rgb = RGBColor.from_string(hx(svg_color(color)))
    tri.line.fill.background()
    return tri


def add_pptx_scene(prs: Presentation, scene: Scene):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = RGBColor(255,255,255)
    for item in scene.items:
        a = item.args
        if item.kind == 'rect':
            sh = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE,
                Inches(a['x']/SCALE), Inches(a['y']/SCALE),
                Inches(a['w']/SCALE), Inches(a['h']/SCALE))
            sh.name = a['id'][:60]
            sh.fill.solid()
            sh.fill.fore_color.rgb = RGBColor.from_string(hx(svg_color(a['fill'])))
            sh.line.color.rgb = RGBColor.from_string(hx(svg_color(a['stroke'])))
            sh.line.width = Pt(a['sw']*72/SCALE)
            if a['dash']:
                sh.line.dash_style = MSO_LINE_DASH_STYLE.DASH
        elif item.kind == 'image':
            with Image.open(a['path']) as im:
                iw,ih=im.size
            scale=min(a['w']/iw,a['h']/ih)
            pw,ph=iw*scale,ih*scale
            left=a['x']+(a['w']-pw)/2
            top=a['y']+(a['h']-ph)/2
            sh=slide.shapes.add_picture(a['path'], Inches(left/SCALE), Inches(top/SCALE),
                                        width=Inches(pw/SCALE), height=Inches(ph/SCALE))
            sh.name=a['id'][:60]
        elif item.kind == 'ellipse':
            sh = slide.shapes.add_shape(MSO_SHAPE.OVAL,
                Inches(a['x']/SCALE), Inches(a['y']/SCALE),
                Inches(a['w']/SCALE), Inches(a['h']/SCALE))
            sh.name = a['id'][:60]
            sh.fill.solid()
            sh.fill.fore_color.rgb = RGBColor.from_string(hx(svg_color(a['fill'])))
            sh.line.color.rgb = RGBColor.from_string(hx(svg_color(a['stroke'])))
            sh.line.width = Pt(a['sw']*72/SCALE)
        elif item.kind == 'line':
            pts = a['pts']
            for (x1,y1),(x2,y2) in zip(pts,pts[1:]):
                pptx_line(slide,x1,y1,x2,y2,a['color'],a['sw'],a['dash'])
            if a['arrow'] and len(pts)>1:
                x1,y1=pts[-2]; x2,y2=pts[-1]
                dx=0 if x2==x1 else (1 if x2>x1 else -1)
                dy=0 if y2==y1 else (1 if y2>y1 else -1)
                add_arrowhead(slide,x2,y2,dx,dy,a['color'],size=max(8,a['sw']*3))
        else:
            add_pptx_text(slide,a)
    return slide


def add_icon(s: Scene, kind: str, x: float, y: float, w: float, h: float, name: str,
             color: str = 'navy'):
    """Insert one separately editable AI-drawn transparent PNG component."""
    assets={
        'water':'01_Water_Source.png','basin':'02_Cooling_Basin.png',
        'pump':'03_Circulating_Pump.png','coil':'04_Condenser.png',
        'tower':'05_Cooling_Tower.png','generator':'06_Turbine_Generator.png',
        'grid':'07_Transmission_Tower.png','clipboard':'08_Measurement_Checklist.png',
        'controller':'09_Field_IO_Controller.png','monitor':'10_Plant_HMI.png',
        'calculator':'11_AET_Calculator.png','person':'12_Plant_Operator.png',
        'sliders':'13_Control_Logic_Panel.png','valves':'14_Control_Valve.png',
        'fan':'15_Cooling_Tower_Fan.png','chart':'16_Unit_Capability_Chart.png',
        'building':'17_Balancing_Authority_Control_Center.png','gauge':'18_Analog_Gauge.png',
    }
    if kind not in assets:
        raise KeyError(f'Unknown component icon: {kind}')
    path=ROOT/'图件'/'组件图标'/assets[kind]
    if not path.exists():
        raise FileNotFoundError(path)
    s.image(x,y,w,h,path,name=name)

def make_fig1() -> Scene:
    s = Scene('Figure_1_editable')
    # Panel (a): physical loop and performance coupling.
    s.panel_heading(40, 18, '(a) Physical cooling-water loop and performance coupling', 1720, 'f1_panel_a_heading')
    node_y, node_h = 105, 92
    nodes = [
        (40,180,'Make-up water\nsource','water'), (280,190,'Cooling-tower\nbasin','basin'),
        (530,190,'Circulating-water\npump','pump'), (780,190,'Condenser','coil'),
        (1030,190,'Cooling tower','tower'), (1280,220,'Turbine–generator','generator'),
        (1550,200,'Electrical grid','grid')]
    # Component titles stay text-only; each pictogram is built from separate editable vector primitives.
    for x,w,title,kind in nodes:
        s.rect(x,node_y,w,node_h,fill='blue_light',stroke='navy',sw=2,radius=14,name=f'f1a_node_{x}')
        add_icon(s,kind,x+8,node_y+22,38,48,f'f1a_icon_{kind}')
        s.text(x+51,node_y+8,w-59,node_h-16,title,size=17,color='navy',bold=True,
               align='center',valign='middle',name=f'f1a_node_label_{x}')
    # Make-up interruption and physical flow across the loop.
    s.line([(220,151),(245,151)],color='blue',sw=4,name='f1a_makeup_inlet_1')
    s.line([(257,151),(280,151)],color='blue',sw=4,arrow=True,name='f1a_makeup_inlet_2')
    s.line([(245,141),(250,151),(245,161),(255,141),(250,151),(255,161)],color='red',sw=4,name='f1a_interruption_symbol')
    s.text(210,198,145,26,'Make-up interruption',size=15,color='red',bold=True,align='center',name='f1a_interruption_label')
    for x1,x2,name in [(470,530,'basin_pump'),(720,780,'pump_condenser'),(970,1030,'condenser_tower')]:
        s.line([(x1,node_y+46),(x2,node_y+46)],color='blue',sw=4,arrow=True,name='f1a_flow_'+name)
    # Tower water losses (grey, separate arrows).
    for x,label in [(1060,'E'),(1125,'B'),(1190,'D')]:
        s.line([(x,node_y),(x,70)],color='grey',sw=2.5,arrow=True,name=f'f1a_loss_{label}')
        s.text(x-18,43,36,24,label,size=17,color='grey',bold=True,align='center',name=f'f1a_loss_label_{label}')
    # Cooled-water return to basin (separate lower lane).
    s.line([(1125,node_y+node_h),(1125,232),(375,232),(375,node_y+node_h)],color='blue',sw=4,arrow=True,name='f1a_return_to_basin')
    s.text(615,210,300,23,'Cooled-water return to basin',size=15,color='blue',align='center',name='f1a_return_label')
    # Backpressure-mediated performance relation; no steam/fluid path is drawn.
    s.line([(875,node_y+node_h),(875,267),(1390,267),(1390,node_y+node_h)],color='amber',sw=3,dash='10 8',arrow=True,name='f1a_backpressure_effect')
    s.text(930,238,430,24,'Backpressure-mediated performance effect — not a fluid path',size=15,color='amber',align='center',name='f1a_performance_label')
    # Generator electrical output only.
    s.line([(1500,node_y+46),(1550,node_y+46)],color='green',sw=4,arrow=True,name='f1a_electrical_output')
    s.text(1498,118,55,23,'P_g / MW',size=15,color='green',bold=True,align='center',name='f1a_output_label')
    # Compact causal sequence.
    causal = ['Usable basin\nwater ↓','Pump flow ↓','Heat rejection ↓','Backpressure ↑','Available unit\noutput ↓']
    xs=[100,435,770,1105,1440]
    for i,(x,txt) in enumerate(zip(xs,causal)):
        s.rect(x,300,260,55,fill='white',stroke='navy',sw=1.8,radius=9,name=f'f1a_causal_box_{i}')
        s.text(x+7,306,246,43,txt,size=17,color='ink',bold=True,align='center',valign='middle',name=f'f1a_causal_text_{i}')
        if i<4:
            s.line([(x+260,327),(xs[i+1],327)],color='black',sw=2,arrow=True,name=f'f1a_causal_arrow_{i}')
    s.text(55,370,1690,35,
        'The 1.0-m low-water reference is not a unit-trip command; modeled protection trips at the first resolved step with p_b ≥ 15 kPa(a), with no added persistence delay.',
        size=16,color='muted',align='center',valign='middle',name='f1a_protection_note')
    s.line([(30,420),(1770,420)],color='grey',sw=1.5,name='f1_panel_divider')

    # Panel (b): conceptual sensing, warning, local action and plant-grid pathway.
    s.panel_heading(40, 430, '(b) Conceptual sensing, warning and control pathway', 1720, 'f1_panel_b_heading')
    s.text(200,462,1400,25,'(conceptual / not implemented in either simulated case)',size=17,color='muted',italic=True,align='center',name='f1b_conceptual_status')
    # Sensing and warning lane.
    s.rect(40,505,335,185,fill='teal_light',stroke='teal',sw=2,radius=14,name='f1b_measurements_box')
    s.text(55,515,305,28,'Candidate measurements',size=20,color='navy',bold=True,align='center',name='f1b_measurements_title')
    add_icon(s,'clipboard',48,562,42,48,'f1b_icon_measurements','teal')
    s.text(98,548,265,130,[
        'Basin level; make-up flow;', 'circulating-water flow; pump',
        'discharge pressure; condenser', 'inlet/outlet temperature;',
        'backpressure; unit MW and', 'operating limits.'
    ],size=15,color='ink',name='f1b_measurements_body')
    s.rect(420,542,165,112,fill='white',stroke='teal',sw=2,radius=14,name='f1b_fieldio_box')
    add_icon(s,'controller',427,575,38,46,'f1b_icon_fieldio','teal')
    s.text(468,555,110,86,['Field I/O /','local controller'],size=15,color='navy',bold=True,align='center',valign='middle',name='f1b_fieldio_label')
    s.rect(630,505,260,185,fill='teal_light',stroke='teal',sw=2,radius=14,name='f1b_automation_box')
    s.text(643,515,234,50,['Plant automation &','operator HMI'],size=19,color='navy',bold=True,align='center',valign='middle',name='f1b_automation_title')
    add_icon(s,'monitor',642,578,42,46,'f1b_icon_automation','teal')
    s.text(690,570,188,105,['DCS / PLC / RTU / IED /',
        'SCADA as configured;', 'alarms, trends and', 'operator display.'],size=14,color='ink',align='center',name='f1b_automation_body')
    s.rect(935,505,285,185,fill='teal_light',stroke='teal',sw=2,radius=14,name='f1b_aet_box')
    s.text(950,515,255,30,'AET estimator',size=20,color='navy',bold=True,align='center',name='f1b_aet_title')
    add_icon(s,'calculator',946,563,42,53,'f1b_icon_aet','teal')
    s.text(994,553,210,120,['Estimated remaining', 'usable-water time = reserve',
        '÷ estimated net water-loss', 'rate.'],
        size=15,color='ink',align='center',valign='middle',name='f1b_aet_body')
    s.rect(1260,542,200,112,fill='white',stroke='teal',sw=2,radius=14,name='f1b_operator_box')
    add_icon(s,'person',1265,572,40,48,'f1b_icon_operator','teal')
    s.text(1308,553,140,90,['Plant operator /','decision'],size=16,color='navy',bold=True,align='center',valign='middle',name='f1b_operator_label')
    for x1,x2,y1,y2,n in [(375,420,597,597,'measure_io'),(585,630,598,598,'io_automation'),(890,935,598,598,'automation_aet'),(1220,1260,598,598,'aet_operator')]:
        s.line([(x1,y1),(x2,y2)],color='teal',sw=3,dash='7 6',arrow=True,name='f1b_signal_'+n)
    s.text(260,700,1270,34,'AET warning is advisory for operator review; it is not an automatic trip or a direct pump/valve command.',
        size=16,color='muted',italic=True,align='center',valign='middle',name='f1b_advisory_note')

    # Local cooling-water action lane.
    s.text(35,744,500,28,'LOCAL COOLING-WATER ACTION',size=18,color='purple',bold=True,align='center',name='f1b_local_heading')
    s.rect(40,780,130,130,fill='purple_light',stroke='purple',sw=2,radius=13,name='f1b_local_operator_box')
    add_icon(s,'person',45,820,34,48,'f1b_icon_local_operator','purple')
    s.text(80,792,84,105,['Operator-', 'authorized', 'instruction'],size=14,color='navy',bold=True,align='center',valign='middle',name='f1b_local_operator_text')
    s.rect(205,780,145,130,fill='purple_light',stroke='purple',sw=2,radius=13,name='f1b_local_logic_box')
    add_icon(s,'sliders',211,817,36,48,'f1b_icon_local_logic','purple')
    s.text(250,792,92,105,['Existing plant', 'control logic'],size=14,color='navy',bold=True,align='center',valign='middle',name='f1b_local_logic_text')
    s.rect(385,780,170,130,fill='purple_light',stroke='purple',sw=2,radius=13,name='f1b_local_equipment_box')
    add_icon(s,'valves',390,790,36,36,'f1b_icon_local_valve','purple')
    add_icon(s,'pump',390,832,36,36,'f1b_icon_local_pumps','purple')
    add_icon(s,'fan',390,874,36,30,'f1b_icon_local_fans','purple')
    s.text(433,788,112,114,['Make-up valve / pump;', 'circulating-water', 'pumps; cooling-tower', 'fans / valves'],size=13,color='navy',bold=True,align='center',valign='middle',name='f1b_local_equipment_text')
    s.line([(170,845),(205,845)],color='purple',sw=3,arrow=True,name='f1b_local_arrow_1')
    s.line([(350,845),(385,845)],color='purple',sw=3,arrow=True,name='f1b_local_arrow_2')
    s.text(35,915,525,48,['Local response follows plant-specific control', 'logic and operating procedures.'],
        size=15,color='muted',align='center',valign='middle',name='f1b_local_note')

    # Proposed plant-grid coordination boundary and five distinct nodes.
    s.rect(590,780,1180,200,fill='white',stroke='purple',sw=2.5,radius=14,dash='10 8',name='f1b_proposed_boundary')
    s.text(770,744,820,30,'PROPOSED INTERFACE — not represented in the simulations.',size=17,color='purple',bold=True,align='center',valign='middle',name='f1b_proposed_label')
    lane_nodes=[
        (610,815,200,125,'Plant capability',['report'],['Available MW / expected','derating / warning'],'chart'),
        (845,815,235,125,'Balancing Authority or',[''],['ISO/RTO control centre;','EMS / SCADA; AGC or','operator dispatch'],'building'),
        (1110,815,195,125,'Unit load',['controller /'],['turbine governor'],'gauge'),
        (1335,815,190,125,'Turbine–',['generator'],['MW set-point /','response'],'generator'),
        (1555,815,180,125,'Electrical grid',[],[],'grid'),
    ]
    for i,(x,y,w,h,title,extra,body,icon) in enumerate(lane_nodes):
        s.rect(x,y,w,h,fill='purple_light' if i<4 else 'blue_light',stroke='purple' if i<4 else 'navy',sw=2,radius=12,name=f'f1b_grid_node_{i}')
        add_icon(s,icon,x+7,y+38,38,46,f'f1b_grid_icon_{i}','purple' if i<4 else 'navy')
        title_lines=(title if isinstance(title,list) else [title])+[v for v in extra if v]
        s.text(x+48,y+7,w-55,52,title_lines,size=14,color='navy',bold=True,align='center',valign='middle',name=f'f1b_grid_title_{i}')
        if body:
            s.text(x+48,y+61,w-55,58,body,size=12.5,color='ink',align='center',valign='middle',name=f'f1b_grid_body_{i}')
    for (x1,x2,n) in [(810,845,'cap_ba'),(1080,1110,'ba_load'),(1305,1335,'load_tg'),(1525,1555,'tg_grid')]:
        s.line([(x1,877),(x2,877)],color='purple',sw=3,arrow=True,name='f1b_dispatch_'+n)
    # Telemetry return path from the generator to the control centre.
    s.line([(1430,815),(1430,790),(965,790),(965,815)],color='teal',sw=2.5,dash='7 6',arrow=True,name='f1b_telemetry_return')
    s.text(1060,789,300,20,'MW / status telemetry',size=13,color='teal',align='center',name='f1b_telemetry_label')
    s.text(610,944,1140,28,'Dispatch changes the generator MW set-point; it does not directly operate cooling-water equipment.',
        size=15,color='muted',italic=True,align='center',valign='middle',name='f1b_dispatch_note')

    # Study-scope note and legend footer.
    s.text(48,990,1704,42,['Neither simulated case specifies plant instruments, control platforms, communications protocols,',
        'EMS/AGC connectivity or end-to-end communication / actuation latency.'],
        size=16,color='muted',align='center',valign='middle',name='f1_scope_note')
    # Legend arranged in two rows for legibility.
    leg1=[(55,1060,'blue','Physical cooling-water flow'),(470,1060,'amber','Backpressure effect; not fluid/steam flow'),
          (1010,1060,'green','Electrical output'),(1335,1060,'teal','Sensor telemetry')]
    for i,(x,y,col,lab) in enumerate(leg1):
        s.line([(x,y+12),(x+60,y+12)],color=col,sw=3,dash='8 6' if col=='teal' else '9 7' if col=='amber' else None,arrow=True,name=f'f1_legend1_line_{i}')
        s.text(x+70,y,330,26,lab,size=14,color='ink',valign='middle',name=f'f1_legend1_text_{i}')
    leg2=[(55,1105,'purple','Warning / plant-grid exchange / generator set-point'),
          (650,1105,'red','Make-up-water interruption'),
          (1050,1105,'purple','Dashed boundary: proposed, not simulated interface')]
    for i,(x,y,col,lab) in enumerate(leg2):
        if i==2:
            s.rect(x,y+3,56,18,fill='white',stroke='purple',sw=2,radius=4,dash='7 5',name='f1_legend_boundary')
        else:
            s.line([(x,y+12),(x+60,y+12)],color=col,sw=3,arrow=True if col=='purple' else False,name=f'f1_legend2_line_{i}')
        s.text(x+70,y,540,28,lab,size=14,color='ink',valign='middle',name=f'f1_legend2_text_{i}')
    return s


def make_fig3() -> Scene:
    s = Scene('Figure_3_editable')
    # Four model blocks arranged around an unambiguous blue physical-water loop.
    # Basin inventory.
    s.rect(60,105,500,350,fill='blue_light',stroke='navy',sw=2.5,radius=18,name='f3_basin_box')
    s.text(85,123,450,36,'Basin inventory',size=25,color='navy',bold=True,align='center',valign='middle',name='f3_basin_title')
    s.text(96,175,428,52,['V(t), h(t), fixed A'],size=20,color='ink',align='center',valign='middle',name='f3_basin_state')
    s.text(92,230,436,74,['dV/dt = Q_makeup − E − B − D'],size=20,color='ink',align='center',valign='middle',name='f3_basin_balance')
    add_icon(s,'basin',80,330,58,55,'f3_basin_icon','blue')
    s.text(150,330,370,55,['Q_makeup = 0 after interruption'],size=17,color='ink',align='center',valign='middle',name='f3_basin_makeup')
    # Red make-up inlet interruption stub.
    s.line([(15,385),(44,385)],color='blue',sw=4,name='f3_makeup_stub_left')
    s.line([(51,385),(60,385)],color='blue',sw=4,arrow=True,name='f3_makeup_stub_right')
    s.line([(41,375),(47,385),(41,395),(53,375),(47,385),(53,395)],color='red',sw=4,name='f3_makeup_break')
    s.text(108,405,320,28,'Make-up interruption',size=14,color='red',bold=True,align='center',name='f3_makeup_label')
    # Loss terms grouped at the basin balance.
    for x,lab in [(165,'E'),(300,'B'),(435,'D')]:
        s.line([(x,105),(x,66)],color='grey',sw=2.5,arrow=True,name=f'f3_loss_{lab}')
        s.text(x-20,40,40,24,lab,size=17,color='grey',bold=True,align='center',name=f'f3_loss_label_{lab}')

    # Unit operating point, amber coupling to condenser.
    s.rect(650,115,450,165,fill='amber_light',stroke='amber',sw=2.5,radius=16,name='f3_unit_operating_box')
    s.text(670,133,410,40,'Unit operating point',size=22,color='navy',bold=True,align='center',valign='middle',name='f3_unit_operating_title')
    s.text(670,183,410,60,['P, η(P) → Q_cond,in'],size=22,color='ink',align='center',valign='middle',name='f3_unit_operating_formula')

    # Cooling tower state/model.
    s.rect(1240,105,500,315,fill='blue_light',stroke='navy',sw=2.5,radius=18,name='f3_tower_box')
    s.text(1265,123,450,36,'Cooling-tower model',size=25,color='navy',bold=True,align='center',valign='middle',name='f3_tower_title')
    s.text(1280,188,420,58,['Target: T_target'],size=21,color='ink',align='center',valign='middle',name='f3_tower_target')
    add_icon(s,'tower',1295,220,145,175,'f3_tower_icon','blue')
    s.text(1448,270,250,72,['Effectiveness–NTU', 'relationship'],size=19,color='ink',align='center',valign='middle',name='f3_tower_relation')

    # Pump hydraulics.
    s.rect(60,650,500,275,fill='blue_light',stroke='navy',sw=2.5,radius=18,name='f3_pump_box')
    s.text(85,667,450,36,'Pump hydraulics',size=25,color='navy',bold=True,align='center',valign='middle',name='f3_pump_title')
    add_icon(s,'pump',82,765,64,64,'f3_pump_icon','navy')
    s.text(158,715,370,48,['x(t),  Q_cw = Q_design x'],size=19,color='ink',align='center',valign='middle',name='f3_pump_flow')
    s.text(158,770,370,55,['x_hyd = min(x_head, x_NPSH)'],size=18,color='ink',align='center',valign='middle',name='f3_pump_hyd')
    s.text(158,830,370,55,['τ_p dx/dt = x_hyd − x'],size=19,color='ink',align='center',valign='middle',name='f3_pump_lag')

    # Condenser thermal state.
    s.rect(680,620,640,330,fill='blue_light',stroke='navy',sw=2.5,radius=18,name='f3_condenser_box')
    s.text(705,637,590,38,'Condenser thermal state',size=25,color='navy',bold=True,align='center',valign='middle',name='f3_condenser_title')
    add_icon(s,'coil',1228,700,62,68,'f3_condenser_icon','navy')
    s.text(705,690,480,53,['T_in, T_out, Q_water'],size=19,color='ink',align='center',valign='middle',name='f3_condenser_flowvars')
    s.text(705,746,480,53,['T_sat(t), p_b'],size=19,color='ink',align='center',valign='middle',name='f3_condenser_states')
    s.text(705,807,480,55,['p_b = p_sat(T_sat) + p_air'],size=18,color='ink',align='center',valign='middle',name='f3_condenser_pressure')
    s.text(705,866,480,48,['T_sat,ss = T_out + TTD'],size=17,color='muted',align='center',valign='middle',name='f3_condenser_ss')

    # Unit capability block.
    s.rect(1380,665,360,230,fill='amber_light',stroke='amber',sw=2.5,radius=16,name='f3_capability_box')
    s.text(1395,690,330,55,['Unit capability'],size=22,color='navy',bold=True,align='center',valign='middle',name='f3_capability_title')
    add_icon(s,'chart',1393,775,48,52,'f3_capability_icon','amber')
    s.text(1448,755,270,96,['P_avail = P_rated', 'f_PB(p_b)'],size=18,color='ink',align='center',valign='middle',name='f3_capability_formula')

    # Solid-blue physical cooling-water loop: basin -> pump -> condenser -> tower -> basin.
    s.line([(300,455),(300,620)],color='blue',sw=4,arrow=True,name='f3_water_basin_pump')
    s.line([(560,785),(680,785)],color='blue',sw=4,arrow=True,name='f3_water_pump_condenser')
    s.text(565,752,120,25,'Q_cw',size=16,color='blue',bold=True,align='center',name='f3_flow_label_qcw')
    s.line([(1120,620),(1120,555),(1500,555),(1500,420)],color='blue',sw=4,arrow=True,name='f3_water_condenser_tower')
    s.text(1230,520,205,24,'Hot-water path',size=15,color='blue',align='center',name='f3_hotwater_label')
    s.line([(1740,260),(1770,260),(1770,25),(585,25),(585,280),(560,280)],color='blue',sw=4,arrow=True,name='f3_water_tower_basin')
    s.text(820,35,360,24,'Cooled-water return to basin',size=15,color='blue',align='center',name='f3_return_label')

    # Amber dashed model/performance couplings, explicitly not water/steam paths.
    s.line([(1100,220),(1145,220),(1145,500),(1000,500),(1000,620)],color='amber',sw=3,dash='10 8',arrow=True,name='f3_heat_coupling')
    s.text(1080,455,290,42,['Q_cond,in (lumped heat input)'],size=15,color='amber',align='center',name='f3_heat_coupling_label')
    s.line([(1320,805),(1380,805)],color='amber',sw=3,dash='10 8',arrow=True,name='f3_capability_coupling')
    s.text(1310,772,85,24,'p_b',size=16,color='amber',bold=True,align='center',name='f3_pb_label')
    return s


def main():
    f1 = make_fig1()
    f3 = make_fig3()
    scene_to_svg(f1, OUT/'Fig1_Editable_Vector.svg')
    scene_to_svg(f3, OUT/'Fig3_Editable_Vector.svg')
    prs = Presentation()
    prs.slide_width = Inches(15)
    prs.slide_height = Inches(10)
    prs.core_properties.title = 'Editable vector redraws: Figures 1 and 3'
    prs.core_properties.subject = 'Native editable PowerPoint shapes, connectors and text for Figures 1 and 3'
    add_pptx_scene(prs, f1)
    add_pptx_scene(prs, f3)
    prs.save(OUT/'Fig1_Fig3_Editable.pptx')
    print('Created:')
    for n in ['Fig1_Editable_Vector.svg','Fig3_Editable_Vector.svg','Fig1_Fig3_Editable.pptx']:
        p=OUT/n
        print(f'  {p} ({p.stat().st_size:,} bytes)')

if __name__ == '__main__':
    main()
