from pathlib import Path


def enforce_times_new_roman(svg_path):
    """Declare Times New Roman throughout SVG text while allowing local raster fallback."""
    path = Path(svg_path)
    text = path.read_text(encoding='utf-8')
    for old in (
        "'Times New Roman', 'DejaVu Serif', serif",
        "'DejaVu Serif'",
        "'Liberation Serif'",
        "'STIXGeneral'",
        'font-family: serif',
    ):
        text = text.replace(old, "'Times New Roman'")
    path.write_text(text, encoding='utf-8')
