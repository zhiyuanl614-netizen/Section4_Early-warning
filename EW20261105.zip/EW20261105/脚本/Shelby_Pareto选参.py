#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shelby two-stage alpha/rho selection using the project's Pareto procedure."""
import importlib.util
from pathlib import Path
import math
import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

ROOT=Path(__file__).resolve().parent.parent
BASE=ROOT/'脚本'/'Shelby_冷却水仿真.py'
RHO_GRID=[0.001,0.01,0.1,0.2,0.3,0.35,0.375,0.4,0.425,0.45,0.5,0.6,1.0,2.0]
ALPHA_CANDIDATES=[0.04,0.12,0.20,0.28,0.36]
REPLAN_S=60
T=22000  # Shelby-only extended window after independently scaling the basin.
STEP=60


def load_wrapper():
    spec=importlib.util.spec_from_file_location('shelby_wrapper',BASE)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    return m


def pareto_mask(x,y):
    out=[]
    for i in range(len(x)):
        dominated=any(j!=i and x[j]<=x[i]+1e-12 and y[j]<=y[i]+1e-12 and
                      (x[j]<x[i]-1e-12 or y[j]<y[i]-1e-12)
                      for j in range(len(x)))
        out.append(not dominated)
    return np.asarray(out,dtype=bool)


def chord_distances(x,y):
    x=np.asarray(x,float);y=np.asarray(y,float)
    if len(x)<3:return np.zeros(len(x))
    a=np.array([x[0],y[0]]);b=np.array([x[-1],y[-1]])
    d=b-a
    norm=np.linalg.norm(d)
    if norm==0:return np.zeros(len(x))
    return np.abs(d[0]*(a[1]-y)- (a[0]-x)*d[1])/norm


def get_scenario(mod,alpha,rho):
    return mod.scenario('Shelby59_aggregate',T=T,step=STEP,replan=REPLAN_S,
                        mode='both',warning_alpha=float(alpha),
                        generator_cost_ratio=float(rho))


def main():
    wrap=load_wrapper();mod=wrap.load_model_module()
    mod,buses,gens,L,rawsum,scale,p0,pmax,norm_mc,affected=wrap.build_test(mod)
    # Stage 1: rho=0; trade off longer AET (burden proxy) vs mean active ENS.
    alpha_rows=[];details=[]
    for alpha in ALPHA_CANDIDATES:
        res=get_scenario(mod,alpha,0.0)
        ens=(res['static']['ens']+res['dynamic']['ens'])/2
        peak=max(res['static']['peak'],res['dynamic']['peak'])
        alpha_rows.append({'alpha':alpha,'warning_volume_m3':res['warning'],'aet_s':res['aet'],
                           'static_ens':res['static']['ens'],'dynamic_ens':res['dynamic']['ens'],
                           'mean_active_ens':ens,'max_active_peak':peak,
                           'alarm_s':res['alarm'],'deadline_s':res['deadline']})
        for key,label in [('static','静态主动'),('dynamic','动态主动')]:
            z=res[key]
            details.append({'阶段':'阶段1 rho=0','alpha':alpha,'预警水量(m³)':res['warning'],'rho':0.0,
                            '策略':label,'ENS(MWh)':z['ens'],'最大功率缺供(MW)':z['peak'],
                            '未加权机组成本指数':z.get('generation_cost_index'),
                            '成功重规划次数':sum(1 for u in res['updates'] if u[1]=='重规划') if key=='dynamic' else None})
    ax=np.array([r['aet_s'] for r in alpha_rows],float)
    ay=np.array([r['mean_active_ens'] for r in alpha_rows],float)
    axn=(ax-ax.min())/(ax.max()-ax.min()) if ax.max()>ax.min() else np.zeros_like(ax)
    ayn=(ay-ay.min())/(ay.max()-ay.min()) if ay.max()>ay.min() else np.zeros_like(ay)
    # The project procedure uses the line joining the extreme alpha endpoints.
    ad=chord_distances(axn,ayn)
    aidx=int(np.argmax(ad));selected_alpha=float(alpha_rows[aidx]['alpha'])
    selected_warning_volume=float(alpha_rows[aidx]['warning_volume_m3'])
    for i,r in enumerate(alpha_rows):
        r.update({'norm_aet_burden':float(axn[i]),'norm_ens':float(ayn[i]),
                  'chord_distance':float(ad[i]),'selected':i==aidx})

    # Stage 2: fix selected alpha; evaluate the same project rho grid.
    rho_rows=[]
    for rho in RHO_GRID:
        res=get_scenario(mod,selected_alpha,rho)
        zs=[res['static'],res['dynamic']]
        ens=float(np.mean([z['ens'] for z in zs]))
        peaks=float(max(z['peak'] for z in zs))
        # Since gen cost is rho times the unweighted proxy, divide back by rho.
        g=float(np.mean([z['generation_cost']/rho for z in zs]))
        rho_rows.append({'rho':rho,'mean_active_ens':ens,'unweighted_cost_index':g,
                         'max_active_peak':peaks,'static_ens':res['static']['ens'],
                         'dynamic_ens':res['dynamic']['ens'],
                         'static_peak':res['static']['peak'],'dynamic_peak':res['dynamic']['peak'],
                         'static_weighted_cost':res['static']['generation_cost'],
                         'dynamic_weighted_cost':res['dynamic']['generation_cost'],
                         'alarm_s':res['alarm'],'aet_s':res['aet'],'deadline_s':res['deadline'],
                         'replans':sum(1 for u in res['updates'] if u[1]=='重规划'),
                         'failures':sum(1 for u in res['updates'] if u[1]=='无候选，保留原计划')})
        for key,label in [('static','静态主动'),('dynamic','动态主动')]:
            z=res[key]
            details.append({'阶段':'阶段2 固定α','alpha':selected_alpha,'预警水量(m³)':res['warning'],'rho':rho,
                            '策略':label,'ENS(MWh)':z['ens'],'最大功率缺供(MW)':z['peak'],
                            '未加权机组成本指数':z['generation_cost']/rho,
                            '成功重规划次数':sum(1 for u in res['updates'] if u[1]=='重规划') if key=='dynamic' else None})
    # same Pareto filtering/normalization: minimize ENS and unweighted cost,
    # only 0<rho<=0.5 points; normalize on non-dominated front and take max chord.
    eligible=[r for r in rho_rows if 0<r['rho']<=0.5]
    ex=np.array([r['mean_active_ens'] for r in eligible],float)
    ey=np.array([r['unweighted_cost_index'] for r in eligible],float)
    mask=pareto_mask(ex,ey)
    front=[r for r,m in zip(eligible,mask) if m]
    front.sort(key=lambda r:(r['mean_active_ens'],r['unweighted_cost_index'],r['rho']))
    fx=np.array([r['mean_active_ens'] for r in front],float)
    fy=np.array([r['unweighted_cost_index'] for r in front],float)
    if len(front)>1:
        fxn=(fx-fx.min())/(fx.max()-fx.min()) if fx.max()>fx.min() else np.zeros_like(fx)
        fyn=(fy.max()-fy)/(fy.max()-fy.min()) if fy.max()>fy.min() else np.zeros_like(fy)
        fd=chord_distances(fxn,fyn)
        # Tie-break to the lower rho, matching conservative selection.
        best=max(fd);ixs=[i for i,v in enumerate(fd) if abs(v-best)<=1e-12]
        fi=min(ixs,key=lambda i:front[i]['rho'])
        selected_rho=float(front[fi]['rho'])
    elif len(front)==1:
        fxn=np.array([0.]);fyn=np.array([0.]);fd=np.array([0.]);fi=0;selected_rho=float(front[0]['rho'])
    else:
        raise RuntimeError('rho范围内没有可用Pareto点')
    front_lookup={r['rho']:(float(fxn[i]),float(fyn[i]),float(fd[i])) for i,r in enumerate(front)}
    for r in rho_rows:
        r['eligible_0_to_0.5']=0<r['rho']<=0.5
        r['pareto_nondominated']=bool(r in eligible and mask[eligible.index(r)])
        coords=front_lookup.get(r['rho'])
        r['norm_ens']=coords[0] if coords else None
        r['norm_cost_improvement']=coords[1] if coords else None
        r['chord_distance']=coords[2] if coords else None
        r['selected']=abs(r['rho']-selected_rho)<1e-12

    outdir=ROOT/'结果'/'Shelby';outdir.mkdir(parents=True,exist_ok=True)
    out=outdir/'Shelby_α与ρ_Pareto选参.xlsx'
    write_workbook(out,alpha_rows,rho_rows,details,selected_alpha,selected_warning_volume,selected_rho,
                   p0,pmax,norm_mc,L,1600.0*pmax[affected]/500.0)
    make_plot(outdir/'Shelby_两阶段Pareto.png',alpha_rows,rho_rows,selected_alpha,selected_rho)
    print('=== Shelby two-stage Pareto selection ===')
    print(f'α candidates: {[(round(r["alpha"],3),round(r["mean_active_ens"],6),round(r["aet_s"],3),round(r["chord_distance"],6)) for r in alpha_rows]}')
    print(f'Selected alpha={selected_alpha:.3f}, warning volume={selected_warning_volume:.3f} m3 (water-volume threshold; AET burden proxy only).')
    print(f'ρ Pareto front: {[(r["rho"],round(r["mean_active_ens"],6),round(r["unweighted_cost_index"],6),round(r["chord_distance"] or 0,6)) for r in front]}')
    print(f'Selected conditional rho={selected_rho:.3f}; based on Shelby aggregate scenario results, not copied from IEEE30 selection.')
    print('Saved:',out)
    print('Saved:',outdir/'Shelby_两阶段Pareto.png')
    print('Full scenario detail rows:',len(details))


def write_workbook(path,alpha_rows,rho_rows,details,a,warn,r,p0,pmax,mc,L,basin_area):
    wb=Workbook();ws=wb.active;ws.title='顺序选参摘要'
    ws.merge_cells('A1:H1');ws['A1']='Shelby 8机聚合模型｜两阶段Pareto顺序选参'
    ws['A1'].font=Font(name='微软雅黑',size=15,bold=True,color='FFFFFF');ws['A1'].fill=PatternFill('solid',fgColor='17365D');ws['A1'].alignment=Alignment(horizontal='center')
    summary=[('先选α',f'{a:.3f}'),('对应预警水量',f'{warn:.3f} m³'),('再选条件ρ',f'{r:.3f}'),('聚合需求L',f'{L:.3f}=Σ原始门站P0'),('机组P0','、'.join(f'{x:.3f}' for x in p0)),('合成Pmax','、'.join(f'{x:.3f}' for x in pmax)),('模型内部池几何（审计）',f'{basin_area:.3f} m² = 1600×Pmax_G2/500；仅作参考模型缩放审计，不是Pareto输入'),('归一化成本代理','IEEE30归一化边际成本按Shelby机组P0排序后插值映射；ρ候选由Shelby Pareto计算'),('重要边界','P0直接取Shelby gate_stations flow；不使用其他母线负荷或外送代理；无线路约束。ENS相对于L=ΣP0，不是现场用户ENS。')]
    for i,(k,v) in enumerate(summary,3):ws.cell(i,1,k).font=Font(bold=True,color='17365D');ws.cell(i,2,v);ws.merge_cells(start_row=i,start_column=2,end_row=i,end_column=8);ws.cell(i,2).alignment=Alignment(wrap_text=True,vertical='top');ws.row_dimensions[i].height=30 if len(v)<100 else 48
    ws.column_dimensions['A'].width=23
    for c in range(2,9):ws.column_dimensions[get_column_letter(c)].width=18
    sheet=wb.create_sheet('阶段1 α候选')
    headers=['α','预警水量(m³)','AET估计(s)','AET(min)','静态ENS(MWh)','动态ENS(MWh)','主动ENS均值(MWh)','主动峰值缺供(MW)','归一化AET负担','归一化ENS','端点弦距','选中']
    add_table(sheet,headers,[[x['alpha'],x['warning_volume_m3'],x['aet_s'],x['aet_s']/60,x['static_ens'],x['dynamic_ens'],x['mean_active_ens'],x['max_active_peak'],x['norm_aet_burden'],x['norm_ens'],x['chord_distance'],'是' if x['selected'] else ''] for x in alpha_rows])
    sheet=wb.create_sheet('阶段2 ρ候选')
    headers=['ρ','主动ENS均值(MWh)','未加权机组成本指数均值','最大缺供峰值(MW)','静态ENS','动态ENS','静态最大缺供','动态最大缺供','Pareto非支配','归一化ENS','归一化成本改善','端点弦距','动态成功重规划','失败回退','选中']
    add_table(sheet,headers,[[x['rho'],x['mean_active_ens'],x['unweighted_cost_index'],x['max_active_peak'],x['static_ens'],x['dynamic_ens'],x['static_peak'],x['dynamic_peak'],'是' if x['pareto_nondominated'] else '',x['norm_ens'],x['norm_cost_improvement'],x['chord_distance'],x['replans'],x['failures'],'是' if x['selected'] else ''] for x in rho_rows])
    sheet=wb.create_sheet('逐情景结果')
    headers=['阶段','α','预警水量(m³)','ρ','策略','ENS(MWh)','最大功率缺供(MW)','未加权机组成本指数','成功重规划次数']
    add_table(sheet,headers,[[d['阶段'],d['alpha'],d['预警水量(m³)'],d['rho'],d['策略'],d['ENS(MWh)'],d['最大功率缺供(MW)'],d['未加权机组成本指数'],d['成功重规划次数']] for d in details])
    sheet=wb.create_sheet('假设与方法')
    notes=[('顺序','阶段1先确定α；固定所选α后，阶段2再选条件ρ。'),('阶段1目标','ρ=0；以AET估计提前量作负担代理（非货币化成本、非保证预警时长），与静态/动态主动方案平均ENS进行Pareto折中。对五个α点min–max归一化，端点连线并选最大弦距。'),('阶段1候选α',', '.join(f'{x:.2f}' for x in ALPHA_CANDIDATES)),('阶段2目标','固定所选α，对ρ候选计算静态/动态主动方案均值；最小化ENS和未加权成本代理G。仅在0<ρ≤0.5的非支配点上min–max归一化并选最大端点弦距。'),('ρ扫描',', '.join(map(str,RHO_GRID))),('成本含义','Shelby没有可用的机组成本曲线。为使ρ敏感性可辨，使用IEEE30归一化边际成本序列作为显式合成代理，按Shelby机组P0从小到大排序并线性插值到8台机组；成本结构不是Shelby实测，也不是文献原系数。ρ候选及最终选择由Shelby输出重新计算。'),('Pmax','Pmax=P0/(IEEE30全机组平均P0/Pmax=189.2/335)。'),('冷端/水量阈值',f'冷端按500 MW参考模板以G2 Pmax缩放；池几何={basin_area:.3f} m²仅是物理模型内部按容量缩放的量，不作Pareto候选。Pareto直接按Vwarn=Vprotect+α(Vnormal−Vprotect)设水量阈值，不输入面积/水位候选；CoC=4为项目假设，非Shelby现场标定。'),('爬坡','RU=0.007/60×Pmax；项目假设，MATPOWER IEEE30 ramps字段为0。'),('聚合边界','L=ΣShelby gate_stations flow=1434；不读取非机组母线负荷，不建外送代理/网络潮流/电压约束。'),('ENS解释','ENS和最大缺供相对于合成聚合L，不等同于本地用户实际缺供。'),('其他','G2受冷却水事件影响；动态重规划固定60秒；Shelby独立仿真窗口延长至22000秒以覆盖五档α对应的水量阈值；冷端/池体参数为参考模板缩放，未现场校准。')]
    add_table(sheet,['项目','说明'],notes)
    wb.save(path)


def add_table(ws,headers,rows):
    ws.append(headers)
    for c in ws[1]:
        c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='4472C4');c.alignment=Alignment(horizontal='center',wrap_text=True)
    for row in rows:ws.append(row)
    ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
    for c in range(1,len(headers)+1):
        ws.column_dimensions[get_column_letter(c)].width=min(32,max(15,max(len(str(ws.cell(r,c).value or '')) for r in range(1,ws.max_row+1))+2))
    for row in ws.iter_rows(min_row=2):
        for cell in row:cell.alignment=Alignment(vertical='center',wrap_text=True)


def make_plot(path,alpha_rows,rho_rows,a,r):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    fonts=['/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc','/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc']
    for f in fonts:
        if Path(f).exists():plt.rcParams['font.family']=font_manager.FontProperties(fname=f).get_name();break
    plt.rcParams['axes.unicode_minus']=False
    fig,axs=plt.subplots(1,2,figsize=(13,5.1),dpi=180)
    x=np.array([d['norm_aet_burden'] for d in alpha_rows],float)
    y=np.array([d['norm_ens'] for d in alpha_rows],float)
    axs[0].plot(x,y,'o-',color='#3478A5',label='Pareto前沿')
    axs[0].plot([x[0],x[-1]],[y[0],y[-1]],'--',color='#777777',label='端点连线')
    for d,xx,yy in zip(alpha_rows,x,y):axs[0].annotate(f"α={d['alpha']:.2f}",(xx,yy),xytext=(5,6),textcoords='offset points',fontsize=8)
    chosen=next(d for d in alpha_rows if d['selected'])
    axs[0].scatter([chosen['norm_aet_burden']],[chosen['norm_ens']],s=115,marker='*',color='#D35400',label='拐点候选',zorder=4)
    axs[0].set_title('阶段1：选择α｜min–max归一化')
    axs[0].set_xlabel('AET负担代理（0=最短，1=最长）')
    axs[0].set_ylabel('静/动态平均ENS（0=最低，1=最高）')
    axs[0].grid(alpha=.25);axs[0].legend(fontsize=8)
    fr=[d for d in rho_rows if d['pareto_nondominated'] and d['norm_ens'] is not None]
    fr.sort(key=lambda d:d['norm_ens'])
    fx=np.array([d['norm_ens'] for d in fr],float);fy=np.array([d['norm_cost_improvement'] for d in fr],float)
    axs[1].plot(fx,fy,'o-',color='#3478A5',label='Pareto前沿')
    if len(fr)>1:axs[1].plot([fx[0],fx[-1]],[fy[0],fy[-1]],'--',color='#777777',label='端点连线')
    for d in fr:axs[1].annotate(f"ρ={d['rho']:.3g}",(d['norm_ens'],d['norm_cost_improvement']),xytext=(4,5),textcoords='offset points',fontsize=7)
    chosen2=next(d for d in rho_rows if d['selected'])
    axs[1].scatter([chosen2['norm_ens']],[chosen2['norm_cost_improvement']],s=115,marker='*',color='#D35400',label='拐点候选',zorder=4)
    axs[1].set_title(f'阶段2：固定α={a:.2f}选择ρ｜min–max归一化')
    axs[1].set_xlabel('ENS（0=最低，1=最高）')
    axs[1].set_ylabel('未加权成本改善（0=最差，1=最好）')
    axs[1].grid(alpha=.25);axs[1].legend(fontsize=8)
    fig.tight_layout();fig.savefig(path,bbox_inches='tight');plt.close(fig)

if __name__=='__main__':main()
